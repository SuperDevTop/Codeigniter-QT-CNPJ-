<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . 'libraries/Ecac/Ecac.php');


class Parcelamento_lei_12996 extends Ecac
{
    public function __construct($params = array(), $conectar = true)
    {
        parent::__construct($params, $conectar);
    }

    function extrato_e_demonstrativos($cnpj)
    {
        $demonstrativos = array();

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: application/json, text/javascript, */*; q=0.01",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: empty",
            "Referer: https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/public/css/lei11941.css",
            "Accept-Language: pt-BR,pt;q=0.9",
            "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With: XMLHttpRequest",
            "Origin: https://www4.cav.receita.fazenda.gov.br",
        );

        $page = $this->obter_pagina(false, 'https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/MenuLei12996.aspx', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/MenuLei12996.aspx",
            "Accept-Language: pt-BR,pt;q=0.9",
        );
        $page = $this->obter_pagina(false, 'https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Demonstrativo/Demonstrativo.aspx', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);
        if ( $html->find('label[id=lblNi]', 0) ){
            $cnpj_formatado = $html->find('label[id=lblNi]', 0)->plaintext;
            $nome_empresarial = $html->find('label[id=lblNiNome]', 0)->plaintext;

            $headers = array(
                "Connection: keep-alive",
                'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                "Accept: application/json, text/javascript, */*; q=0.01",
                "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With: XMLHttpRequest",
                "sec-ch-ua-mobile: ?0",
                'sec-ch-ua-platform: "Windows"',
                "Origin: https://www4.cav.receita.fazenda.gov.br",
                "Sec-Fetch-Site: same-origin",
                "Sec-Fetch-Mode: cors",
                "Sec-Fetch-Dest: empty",
                "Referer: https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Demonstrativo/Demonstrativo.aspx",
                "Accept-Language: pt-BR,pt;q=0.9",
            );
            $page = $this->obter_pagina(true, 'https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Ajaj.aspx', http_build_query(['act' => 'InfoNiModalidades', 'dt' => '{"TipoNi":"1","Ni":"' . $cnpj . '"}']), $headers);
            $html = new Simple_html_dom();
            $html->load($page);

            $response = json_decode($html);

            $municipio = $response->Contribuinte->NomeMunicipio;

            foreach ($response->Modalidades as $modalidade) {
                if ($modalidade->NomeSituacao == 'Em Parcelamento') {

                    $demonstrativo = array(
                        'cnpj_formatado' => $cnpj_formatado,
                        'nome_empresarial' => $nome_empresarial,
                        'municipio' => $municipio,
                        'data_adesao' => $modalidade->DataAdesao,
                        'data_validacao' => $modalidade->DataValidacao,
                        'data_negociacao' => $modalidade->DataNegociacao,
                        'data_efeito_exclusao' => $modalidade->DataEfeitoExclusao,
                        'data_ciencia' => $modalidade->DataCiencia,
                        'data_encerramento' => $modalidade->DataEncerramento,
                        'data_liquidacao_divida' => $modalidade->DataLiquidacaoDivida,
                        'data_exclusao' => $modalidade->DataExclusao,
                        'codigo_motivo_exclusao' => $modalidade->CodigoMotivoExclusao,
                        'in_solicitacao_reativacao' => $modalidade->InSolicitacaoReativacao,
                        'cod_fase' => $modalidade->CodFase,
                        'cod_modalidade' => $modalidade->CodModalidade,
                        'cod_situacao' => $modalidade->CodSituacao,
                        'nome_modalidade' => $modalidade->NomeModalidade,
                        'nome_situacao' => $modalidade->NomeSituacao,
                    );

                    $headers = array(
                        "Connection: keep-alive",
                        'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                        "Accept: application/json, text/javascript, */*; q=0.01",
                        "Content-Type: application/x-www-form-urlencoded; charset=UTF-8",
                        "X-Requested-With: XMLHttpRequest",
                        "sec-ch-ua-mobile: ?0",
                        'sec-ch-ua-platform: "Windows"',
                        "Origin: https://www4.cav.receita.fazenda.gov.br",
                        "Sec-Fetch-Site: same-origin",
                        "Sec-Fetch-Mode: cors",
                        "Sec-Fetch-Dest: empty",
                        "Referer: https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Demonstrativo/Demonstrativo.aspx",
                        "Accept-Language: pt-BR,pt;q=0.9",
                    );
                    $page = $this->obter_pagina(true, 'https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/AjajNegociacaoLei12996.aspx', http_build_query(['act' => 'DemonstrativoPrestacoes', 'dt' => '{"Tipo":"1","Ni":"' . $cnpj . '","Parcelamento":"' . $modalidade->CodModalidade . '","Msg":"","Operacao":""}']), $headers);
                    $html = new Simple_html_dom();
                    $html->load($page);

                    $prestacoes = json_decode($html);

                    $parcelas = array();
                    foreach ($prestacoes->Parcelas as $parcela) {
                        if (!empty($parcela->Indicador_Parcela_Devida)) {
                            $parcelas[] = array(
                                'parcela_id' => $parcela->Parcela_Id,
                                'data_parcela' => $parcela->Data_Parcela,
                                'valor_parc_minima' => $parcela->Valor_Parc_Minima,
                                'valor_parcela_divida' => $parcela->Valor_Parcela_Divida,
                                'valor_parc_calculada' => $parcela->Valor_Parc_Calculada,
                                'saldo_parc_devedora' => $parcela->Saldo_Parc_Devedora,
                                'juros_parc_deverdora' => $parcela->Juros_Parc_Deverdora,
                                'indicador_parcela_devida' => $parcela->Indicador_Parcela_Devida,
                                'indicador_situacao_parcela' => $parcela->Indicador_Situacao_Parcela,
                                'indicador_reducao' => $parcela->Indicador_Reducao,
                                'valor_total_arrecadacao' => $parcela->Valor_Total_Arrecadacao,
                                'valor_reducao_mes' => $parcela->Valor_Reducao_Mes,
                                'valor_antecipacao_mes' => $parcela->Valor_Antecipacao_Mes,
                                'quantidade_parc_red' => $parcela->Quantidade_Parc_Red,
                            );
                        }
                        $prestacoes = json_decode($html);

                        $demonstrativo['cod_receita'] = $prestacoes->Divida->Codigo_receita;
                        $demonstrativo['proximo_dia_util'] = $prestacoes->Proximo_Dia_Util;

                        $parcelas = array();
                        foreach ($prestacoes->Parcelas as $parcela) {
                            if (!empty($parcela->Indicador_Parcela_Devida)) {
                                $parcelas[] = array(
                                    'parcela_id' => $parcela->Parcela_Id,
                                    'data_parcela' => $parcela->Data_Parcela,
                                    'valor_parc_minima' => $parcela->Valor_Parc_Minima,
                                    'valor_parcela_divida' => $parcela->Valor_Parcela_Divida,
                                    'valor_parc_calculada' => $parcela->Valor_Parc_Calculada,
                                    'saldo_parc_devedora' => $parcela->Saldo_Parc_Devedora,
                                    'juros_parc_deverdora' => $parcela->Juros_Parc_Deverdora,
                                    'indicador_parcela_devida' => $parcela->Indicador_Parcela_Devida,
                                    'indicador_situacao_parcela' => $parcela->Indicador_Situacao_Parcela,
                                    'indicador_reducao' => $parcela->Indicador_Reducao,
                                    'valor_total_arrecadacao' => $parcela->Valor_Total_Arrecadacao,
                                    'valor_reducao_mes' => $parcela->Valor_Reducao_Mes,
                                    'valor_antecipacao_mes' => $parcela->Valor_Antecipacao_Mes,
                                    'quantidade_parc_red' => $parcela->Quantidade_Parc_Red,
                                );
                            }
                            $demonstrativo['parcelas'] = $parcelas;
                            $demonstrativos[] = $demonstrativo;
                        }
                    }
                }
            }
        return $demonstrativos;
    }

    //GERAR PARCELA
    function gerar_parcela_lei_12996($dados){
        $headers = array(
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Content-Type: application/x-www-form-urlencoded",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
        );

        $page = $this->obter_pagina(
            true,
            'https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Darf/ImpressaoDarf.aspx',
            http_build_query([
                'strCPFCNPJ' => $dados['strCPFCNPJ'], 
                'strCodReceita' => $dados['strCodReceita'], 
                'strDataLimitePagamento' => $dados['strDataLimitePagamento'], 
                'strDataVencimentoImposto' => $dados['strDataVencimentoImposto'], 
                'strManualAutomatico' => 'A', 
                'strMunicipio' => $dados['strMunicipio'],
                'strNome' => $dados['strNome'],
                'strPeriodoApuracao' => $dados['strPeriodoApuracao'],
                'strProgramaChamador' => 'Lei Nº 12.996 de 2014 – Parcelamento',
                'strValorJuros' => $dados['strValorJuros'],
                'strValorPrincipal' => $dados['strValorPrincipal'],
                'strValorTotal' => $dados['strValorTotal'],
                'tipo' => '9',
            ]), 
            $headers
        );

        $html = new Simple_html_dom();
        $html->load($page);

        $tipo = $html->find('input[name=tipo]', 0)->value;
        $darfs = $html->find('input[name=darfs]', 0)->value;
        
        return $this->baixar_pdf_lei_12996($tipo, $darfs);
    }

    function baixar_pdf_lei_12996($tipo, $darfs){
        date_default_timezone_set('America/Bahia');
        $data_atual = date('Ymdhis');

        $post_str = http_build_query(
            array(
                'tipo' => $tipo,
                'darfs' => $darfs
            )
        );

        $headers = array(
            "Connection: keep-alive",
            "Cache-Control: max-age=0",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Origin: https://www4.cav.receita.fazenda.gov.br",
            "Content-Type: application/x-www-form-urlencoded",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: document",
            "Referer: https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Darf/ImpressaoDarf.aspx",
            "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,la;q=0.6",
         );
        curl_setopt($this->curl, CURLOPT_URL , "https://www4.cav.receita.fazenda.gov.br/Servicos/ATSPO/paexlei12996.app/Lei12996/Darf/ImpressaoDarf.aspx" );
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->curl, CURLOPT_COOKIESESSION, 1);
        curl_setopt($this->curl, CURLOPT_FRESH_CONNECT, 1);
        curl_setopt($this->curl, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie_path);
        curl_setopt($this->curl, CURLOPT_POST, 1);
        curl_setopt($this->curl, CURLOPT_POSTFIELDS, $post_str);
        
        $content = curl_exec($this->curl);

        $caminho_local = $this->caminho_da_pasta_pdfs."/DARF-{$data_atual}.pdf";

        $aux_dir_ext = str_replace(FCPATH, "",$caminho_local);
        $aux_dir_ext = str_replace("//", "/", $aux_dir_ext);
        if ( $this->verifica_pdf_valido($content)){
            upload_google_source($content, $aux_dir_ext);
            $retorno = "https://storage.googleapis.com/cron-veri-files-br/".$aux_dir_ext;
        }

        if(curl_errno($this->curl))
        {
            echo curl_error($this->curl);
            return false;
        }
        return $retorno;
    }

    function verifica_pdf_valido($content){
        if (preg_match("/^%PDF-1./", $content)) {
            return true;
        } else {
            return false;
        }
    }
}
