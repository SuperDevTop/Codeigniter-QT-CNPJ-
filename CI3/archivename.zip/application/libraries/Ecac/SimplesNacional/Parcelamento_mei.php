<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'libraries/Ecac/Ecac.php');


class Parcelamento_mei extends Ecac
{

    public function __construct($params = array(), $conectar = true)
    {
        parent::__construct($params, $conectar);
    }

    function obter_parcelamentos(){
        $page = $this->obter_pagina(false, 'https://cav.receita.fazenda.gov.br/ecac/Aplicacao.aspx?id=134&origem=menu');
        $html = new Simple_html_dom();
        $html->load($page);

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-site",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $page = $this->obter_pagina(false, 'https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/atspo/parcmei.app/Default.aspx', $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $__EVENTTARGET = 'ctl00$contentPlaceH$linkButtonConsulta';
        $__EVENTARGUMENT = '';
        $nodes = $html->find("input[type=hidden]");
        $vals = array();
        foreach ($nodes as $node) {
            $val = $node->value;
            if(!empty($val) && !is_null($val))
                $vals[] = $val;
        }

        $__VIEWSTATE = $vals[0];
        $__VIEWSTATEGENERATOR = $vals[1];

        $post_fields = array(
            '__EVENTTARGET' => $__EVENTTARGET,
            '__EVENTARGUMENT' => $__EVENTARGUMENT,
            '__VIEWSTATE' => $__VIEWSTATE ,
            '__VIEWSTATEGENERATOR' => $__VIEWSTATEGENERATOR
        );

        $page = $this->post($post_fields);

        $html = new Simple_html_dom();
        $html->load($page);

        $pedidos = array();

        $table = $html->find('table[id=ctl00_contentPlaceH_wcParc_gdv]',0);

        if ($table){
            $trs = $table->find('tr');
            $posicao  = 0;
            foreach ($trs as $tr){
                if ($posicao > 0){
                    $status = trim($tr->find('td', 2)->plaintext);
                    if ($status == 'Em parcelamento'){
                        $__EVENTTARGET = 'ctl00$contentPlaceH$wcParc$gdv';
                        $__EVENTARGUMENT = 'Select$'. ($posicao-1);
                        $nodes = $html->find("input[type=hidden]");
                        $vals = array();
                        foreach ($nodes as $node) {
                            $val = $node->value;
                            if(!empty($val) && !is_null($val))
                                $vals[] = $val;
                        }

                        $__VIEWSTATE = $vals[0];
                        $__VIEWSTATEGENERATOR = $vals[1];

                        $post_fields = array(
                            '__EVENTTARGET' => $__EVENTTARGET,
                            '__EVENTARGUMENT' => $__EVENTARGUMENT,
                            '__VIEWSTATE' => $__VIEWSTATE ,
                            '__VIEWSTATEGENERATOR' => $__VIEWSTATEGENERATOR,
                            '__VIEWSTATEENCRYPTED' => '');
                        $html =  $this->post2($post_fields);
                        $pedido = $this->obter_informacao_pedido($html);
                        $pedido['consolidacao_original'] = $this->obter_consolidacao_original($html);
                        $pedido['demonstrativo_pagamento'] = $this->obter_demonstrativo($html);
                        $pedidos[] = $pedido;
                    }
                }
                $posicao++;
            }
        }

        return $pedidos;
    }

    private function obter_informacao_pedido($page){
        $html = new Simple_html_dom();
        $html->load($page);
        $table = $html->find('table[id=ctl00_contentPlaceH_wcParc_gdv]', 0);
        $trs = $table->find('tr');
        $i = 0;

        $pedido_contribuinte = array();
        foreach ($trs as $tr){
            if ( $i > 0){
                $pedido_contribuinte = array(
                    'numero' => trim($tr->find('td')[0]->plaintext),
                    'data_pedido' => trim($tr->find('td')[1]->plaintext),
                    'situacao' =>trim($tr->find('td')[2]->plaintext),
                    'data_situacao' => trim($tr->find('td')[3]->plaintext),
                );
                break;
            }
            $i++;
        }
        $table = $html->find('table[id=ctl00_contentPlaceH_wcConsol_gdv]', 0);
        $trs = $table->find('tr');
        $i = 0;

        foreach ($trs as $tr){
            if ( $i > 0){
                $pedido = array_merge($pedido_contribuinte , array(
                    'valor_total_consolidado' => trim($tr->find('td')[0]->plaintext),
                    'qtd_parcelas' => trim($tr->find('td')[1]->plaintext),
                    'parcela_basica' => trim($tr->find('td')[2]->plaintext),
                    'data_consolidacao' => trim($tr->find('td')[3]->plaintext)
                ));

                break;
            }
            $i++;
        }
        return $pedido;
    }

    private function obter_consolidacao_original($page){
        $html = new Simple_html_dom();
        $html->load($page);
        $__EVENTTARGET = 'ctl00$contentPlaceH$wcConsol$gdv';
        $__EVENTARGUMENT = 'Select$0';
        $nodes = $html->find("input[type=hidden]");
        $vals = array();
        foreach ($nodes as $node) {
            $val = $node->value;
            if(!empty($val) && !is_null($val))
                $vals[] = $val;
        }

        $__VIEWSTATE = $vals[0];
        $__VIEWSTATEGENERATOR = $vals[1];

        $post_fields = array(
            '__EVENTTARGET' => $__EVENTTARGET,
            '__EVENTARGUMENT' => $__EVENTARGUMENT,
            '__VIEWSTATE' => $__VIEWSTATE ,
            '__VIEWSTATEGENERATOR' => $__VIEWSTATEGENERATOR,
            '__VIEWSTATEENCRYPTED' => ''
        );

        $page = $this->post3($post_fields);
        $html = new Simple_html_dom();
        $html->load($page);

        $table = $html->find("table[id=ctl00_contentPlaceH_wcConsol_wcListaDeb_gdv]", 0);
        $trs = $table->find('tr');
        $i = 0;
        $relacao_debitos_parcelas = array();
        foreach ($trs as $tr){
            if ( $i > 0 ){
                $relacao_debitos_parcelas[] = array(
                    'periodo_apurcao' => trim($tr->find('td')[0]->plaintext),
                    'vencimento' => trim($tr->find('td')[1]->plaintext),
                    'numero_processo' => trim($tr->find('td')[2]->plaintext),
                    'saldo_devedor_original' => trim($tr->find('td')[3]->plaintext),
                    'valor_atualizado' => trim($tr->find('td')[4]->plaintext),
                );
            }
            $i++;
        }

        return $relacao_debitos_parcelas;
    }

    private function obter_demonstrativo($page){
        $html = new Simple_html_dom();
        $html->load($page);
        $table = $html->find('table[id=ctl00_contentPlaceH_wcPagto_gdv]', 0);
        $trs = $table->find('tr');
        $i = 0;
        $demonstrativos = array();
        foreach ($trs as $tr){
            if ( $i > 0){
                $mes_parcela = trim($tr->find('td')[0]->plaintext);
                $vencimento_das = trim($tr->find('td')[1]->plaintext);
                $data_arrecadacao = trim($tr->find('td')[2]->plaintext);
                $valor_pago = trim($tr->find('td')[3]->plaintext);

                $demonstrativos[] = array(
                    'mes_parcela' => $mes_parcela,
                    'vencimento_das' => $vencimento_das,
                    'data_arrecadacao' => $data_arrecadacao,
                    'valor_pago' => $valor_pago,
                );
            }
            $i++;

        }
        return $demonstrativos;
    }

    private function post($post_fields){

        $url = "https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/atspo/parcmei.app/Default.aspx";

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_POST, true);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie_path);

        $headers = array(
            "Connection: keep-alive",
            "Cache-Control: max-age=0",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Origin: https://sinac.cav.receita.fazenda.gov.br",
            "Content-Type: application/x-www-form-urlencoded",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/atspo/parcmei.app/Default.aspx",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);

        $data = http_build_query($post_fields);

        curl_setopt($this->curl, CURLOPT_POSTFIELDS, $data);

        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

        $resp = curl_exec($this->curl);
        return $resp;
    }

    private function post2($post_fields){
        $url = "https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/atspo/parcmei.app/ConsultaPedido.aspx";

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_POST, true);   
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie_path);

        $headers = array(
            "Connection: keep-alive",
            "Cache-Control: max-age=0",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Origin: https://sinac.cav.receita.fazenda.gov.br",
            "Content-Type: application/x-www-form-urlencoded",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/atspo/parcmei.app/Default.aspx",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);

        $data = http_build_query($post_fields);

        curl_setopt($this->curl, CURLOPT_POSTFIELDS, $data);

        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

        $resp = curl_exec($this->curl);
        return $resp;
    }

    private function post3($post_fields){
        $url = "https://sinac.cav.receita.fazenda.gov.br/simplesnacional/Aplicacoes/atspo/parcmei.app/ConsultaPedidoDetalhes.aspx";

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_POST, true);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            "Connection: keep-alive",
            "Cache-Control: max-age=0",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Origin: https://sinac.cav.receita.fazenda.gov.br",
            "Content-Type: application/x-www-form-urlencoded",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://sinac.cav.receita.fazenda.gov.br/simplesnacional/Aplicacoes/atspo/parcmei.app/ConsultaPedidoDetalhes.aspx",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
        $data = http_build_query($post_fields);
        curl_setopt($this->curl, CURLOPT_POSTFIELDS, $data);

        //for debug only!
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

        $resp = curl_exec($this->curl);
        return $resp;
    }
}