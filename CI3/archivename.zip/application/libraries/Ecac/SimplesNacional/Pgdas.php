<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'libraries/Ecac/Ecac.php');


class Pgdas extends Ecac
{

    public function __construct($params = array(), $conectar = true)
    {
        parent::__construct($params, $conectar);
    }
    
    public function obter_pgdas(){

        $url = "https://sinac.cav.receita.fazenda.gov.br/simplesnacional/aplicacoes/atspo/pgdasd2018.app/";
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Google Chrome";v="95", "Chromium";v="95", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-site",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/",
            "Accept-Language: pt-BR,pt;q=0.9",            
        );
         
        $this->exec($url, $headers);
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Google Chrome";v="95", "Chromium";v="95", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://sinac.cav.receita.fazenda.gov.br/simplesnacional/aplicacoes/atspo/pgdasd2018.app/",
            "Accept-Language: pt-BR,pt;q=0.9",

        );

        $pagina = $this->exec('https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/ATSPO/pgdasd2018.app/Consulta', $headers);

        $html = new Simple_html_dom();
        $html->load($pagina);

        $tbDas = $html->find('table[class=table consulta]', 0);

        $resultado = array();
        $competencia = '';
        $dados = array();
        if ($tbDas){
            $tbDasTr = $tbDas->find('tr');
            foreach($tbDasTr as $tr){
                if (isset($tr->style)){
                    if($tr->style == 'background-color:#DEF0C1'){
                        $competencia = $tr->plaintext;
                    }
                    $dados['compentencia'] = trim($competencia);
                    $dados['numero_das'] = '';
                    $dados['data_hora_emissao'] = '';
                    $dados['pago'] = '';
                    $dados['numero_declaracao'] = '';
                    $dados['data_hora_transmissao'] = '';
                    continue;
                }

                $texttr = $tr->plaintext;
                if (preg_match("/Declaração/",  $texttr)){
                    $dados['numero_declaracao'] = trim($tr->find('td', 1)->plaintext);
                    $dados['data_hora_transmissao'] = trim($tr->find('td', 2)->plaintext);
                }

                if (preg_match("/DAS/",  $texttr)){
                    $dados['numero_das'] = trim($tr->find('td', 7)->plaintext);
                    $dados['data_hora_emissao'] = trim($tr->find('td', 8)->plaintext);
                    $dados['pago'] = trim($tr->find('td', 10)->plaintext);
                    $resultado[] = $dados;
                }
            }
            foreach($tbDasTr as $tr){
                if (isset($tr->style)){
                    if($tr->style == 'background-color:#DEF0C1'){
                        $competencia = $tr->plaintext;
                    }
                    $dados['compentencia'] = trim($competencia);
                    $dados['numero_das'] = '';
                    $dados['data_hora_emissao'] = '';
                    $dados['pago'] = '';
                    $dados['numero_declaracao'] = '';
                    $dados['data_hora_transmissao'] = '';
                    continue;
                }

                $texttr = $tr->plaintext;
                if (preg_match("/Declaração/",  $texttr)){
                    $dados['numero_declaracao'] = trim($tr->find('td', 1)->plaintext);
                    $dados['data_hora_transmissao'] = trim($tr->find('td', 2)->plaintext);
                    if($this->nao_existe_declaracao($resultado, $dados['numero_declaracao']))
                        $resultado[] = $dados;
                }
            }
        }
        return $resultado;
    }

    function nao_existe_declaracao($resultado, $numero_declaracao){
        foreach ($resultado as $r)
            if($numero_declaracao == $r['numero_declaracao'])
                return false;
        return true;
    }

    function baixar_declaracao_das($numero_declaracao,  $ano){
        $url="https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/ATSPO/pgdasd2018.app/Consulta/Declaracao?idDeclaracao={$numero_declaracao}&ano={$ano}";
        $headers = array(
           "Connection: keep-alive",
           'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
           "sec-ch-ua-mobile: ?0",
           'sec-ch-ua-platform: "Windows"',
           "Upgrade-Insecure-Requests: 1",
           "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36",
           "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
           "Sec-Fetch-Site: same-origin",
           "Sec-Fetch-Mode: navigate",
           "Sec-Fetch-User: ?1",
           "Sec-Fetch-Dest: iframe",
           "Referer: https://sinac.cav.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/ATSPO/pgdasd2018.app/Consulta",
           "Accept-Language: pt-BR,pt;q=0.9",
        );
        $caminho_local = $this->caminho_da_pasta_pdfs."/PGDASD-DECLARACAO-".md5(uniqid("")).".pdf";
        $tentativas = 0;
        $retorno = '';
        while ( $tentativas < 10){
            $tentativas = $tentativas + 1;
            $content = $this->exec($url, $headers);
            $aux_dir_ext = str_replace(FCPATH, "",$caminho_local);
            $aux_dir_ext = str_replace("//", "/", $aux_dir_ext);
            if ( $this->verifica_pdf_valido($content)){
                upload_google_source($content, $aux_dir_ext);
                $retorno = "https://storage.googleapis.com/cron-veri-files-br/".$aux_dir_ext;
                break;
            }
        }
        return $retorno;
    }
} 