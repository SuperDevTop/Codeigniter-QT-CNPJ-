<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'libraries/Ecac/Ecac.php');
require 'vendor/autoload.php';
use Google\Cloud\Storage\StorageClient;
use Dompdf\Dompdf;
use Dompdf\Options;

class Parcelamento_nao_previdenciario extends Ecac
{

    public function __construct($params = array(), $conectar = true)
    {
        parent::__construct($params, $conectar);
    }

    function processos_negociados(){
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/ecac/Aplicacao.aspx?id=7&origem=menu",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $page = $this->obter_pagina(false, 'https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/parcweb_gerenciador.asp', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $nbsp = html_entity_decode("&nbsp;");
        $cnpj_na_pagina = trim(str_replace("CNPJ:$nbsp", "", $html->find('b',0)->plaintext));

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/Menu.asp",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $page = $this->obter_pagina(false, 'https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoProcessos.asp', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $table = $html->find('table[cellspacing=2]',0);
        $processos_negociados = array();

        if ($table){
            $trs = $table->find('tr');
            $posicao  = 0;
            foreach ($trs as $tr){
                if ($posicao > 0){
                    $processo = trim($tr->find('td', 0)->plaintext);
                    $data_do_deferimento = trim($tr->find('td', 1)->plaintext);
                    $situacao = trim($tr->find('td', 2)->plaintext);

                    $processos = array(
                        'processo' => $processo,
                        'data_do_deferimento' => $data_do_deferimento,
                        'situacao' => $situacao
                    );

                    $processos['tributos_do_processo_negociados'] = $this->obter_tributos_do_processo_negociados($cnpj_na_pagina, $processo, $situacao);
                    
                    $processos_negociados[] = $processos;
                }
                $posicao++;
            }
        }
        return $processos_negociados;
    }

    public function obter_tributos_do_processo_negociados($cnpj_na_pagina, $numero_processo, $situacao)
    {
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoProcessos.asp",
            "Accept-Language: pt-BR,pt;q=0.9",
        );
        $page = $this->obter_pagina(false, "https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoTributos.asp?Ni=$cnpj_na_pagina&TipoContr=1&NuProcesso=$numero_processo&SitProcesso=$situacao&SIST=PARCWEB", [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $table = $html->find('table[cellspacing=2]',0);
        $pedidos = array();

        if ($table){
            $trs = $table->find('tr');
            $posicao  = 0;
            foreach ($trs as $tr){
                if ($posicao > 0 && trim($tr->find('td', 1)->plaintext) == 'Ativo'){
                    $tributo = trim($tr->find('td', 0)->plaintext);
                    $situacao = trim($tr->find('td', 1)->plaintext);
                    $saldo = trim($tr->find('td', 2)->plaintext);
                    $total_em_atraso = trim($tr->find('td', 3)->plaintext);
                    $parcelas_em_atraso = trim($tr->find('td', 4)->plaintext);

                    $tributos_do_processo = array(
                        'tributo' => $tributo,
                        'situacao' => $situacao,
                        'saldo' => $saldo,
                        'total_em_atraso' => $total_em_atraso,
                        'parcelas_em_atraso' => $parcelas_em_atraso
                    );
                    $tributos_do_processo['demonstrativo_das_parcelas'] = $this->demonstrativo_das_parcelas($cnpj_na_pagina, $numero_processo, $situacao, $parcelas_em_atraso, $tributo);
                    
                    $pedidos [] = $tributos_do_processo;
                }
                $posicao++;
            }
        }
        return $pedidos;
    }

    public function demonstrativo_das_parcelas($cnpj_na_pagina, $numero_processo, $situacao, $qtd_parcela, $nome_tributo)
    {
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoTributos.asp?Ni=$cnpj_na_pagina&TipoContr=1&NuProcesso=$numero_processo&SitProcesso=$situacao&SIST=PARCWEB",
            "Accept-Language: pt-BR,pt;q=0.9",
         );

        $page = $this->obter_pagina(false, "https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoParcelas.asp?Ni=$cnpj_na_pagina&TipoContr=1&NuProcesso=$numero_processo&Situacao=$situacao&QtdParc=$qtd_parcela&NomeTrib=$nome_tributo&SIST=PARCWEB", [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $table = $html->find('table[cellspacing=2]',0);
        $pedidos = array();

        if ($table){
            $trs = $table->find('tr');
            $posicao  = 0;
            foreach ($trs as $tr){
                if ($posicao > 0){
                    $numero_parcela = trim($tr->find('td', 0)->plaintext);
                    $data_vencimento = trim($tr->find('td', 1)->plaintext);
                    $valor_ate_vencimento = trim($tr->find('td', 2)->plaintext);
                    $saldo_devedor_atual = trim($tr->find('td', 3)->plaintext);
                    $situacao = trim($tr->find('td', 4)->plaintext);

                    $demonstrativo = array(
                        'numero_parcela' => $numero_parcela,
                        'data_vencimento' => $data_vencimento,
                        'valor_ate_vencimento' => $valor_ate_vencimento,
                        'saldo_devedor_atual' => $saldo_devedor_atual,
                        'situacao' => $situacao
                    );

                    $pedidos[] = $demonstrativo;
                }
                $posicao++;
            }
        }
        return  $pedidos;
    }

    //GERAR PARCELA
    function gerar_parcela_nao_previdenciario($numero_processo, $situacao, $nome_tributo, $qtd_parcela, $numero_parcela, $data_vencimento, $valor_parcela){
        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/ecac/Aplicacao.aspx?id=7&origem=menu",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $page = $this->obter_pagina(false, 'https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/parcweb_gerenciador.asp', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $nbsp = html_entity_decode("&nbsp;");
        $cnpj_na_pagina = trim(str_replace("CNPJ:$nbsp", "", $html->find('b',0)->plaintext));

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: iframe",
            "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/Menu.asp",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $page = $this->obter_pagina(false, 'https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoProcessos.asp', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $table = $html->find('table[cellspacing=2]',0);

        if ($table){
            $trs = $table->find('tr');
            $posicao  = 0;
            foreach ($trs as $tr){
                if ($posicao > 0 && $numero_processo == trim($tr->find('td', 0)->plaintext)){
                    $headers = array(
                        "Connection: keep-alive",
                        'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                        "sec-ch-ua-mobile: ?0",
                        'sec-ch-ua-platform: "Windows"',
                        "Upgrade-Insecure-Requests: 1",
                        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                        "Sec-Fetch-Site: same-origin",
                        "Sec-Fetch-Mode: navigate",
                        "Sec-Fetch-User: ?1",
                        "Sec-Fetch-Dest: iframe",
                        "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoProcessos.asp",
                        "Accept-Language: pt-BR,pt;q=0.9",
                    );
            
                    $data = http_build_query([
                        "Ni" => $cnpj_na_pagina,
                        "TipoContr" => "1",
                        "NuProcesso" => $numero_processo,
                        "SitProcesso" => $situacao,
                        "SIST" => "PARCWEB"
                    ]);
                    $page = $this->obter_pagina(false, "https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoTributos.asp?$data", [], $headers);
                    $html = new Simple_html_dom();
                    $html->load($page);
            
                    $table = $html->find('table[cellspacing=2]',0);
            
                    if ($table){
                        $trs = $table->find('tr');
                        $posicao_2  = 0;
                        foreach ($trs as $tr){
                            if ($posicao_2 > 0 && $nome_tributo == trim($tr->find('td', 0)->plaintext)){
                                $data = http_build_query([
                                    "Ni" => $cnpj_na_pagina,
                                    "TipoContr" => "1",
                                    "NuProcesso" => $numero_processo,
                                    "SitProcesso" => $situacao,
                                    "SIST" => "PARCWEB"
                                ]);
                                $headers = array(
                                    "Connection: keep-alive",
                                    'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                                    "sec-ch-ua-mobile: ?0",
                                    'sec-ch-ua-platform: "Windows"',
                                    "Upgrade-Insecure-Requests: 1",
                                    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                                    "Sec-Fetch-Site: same-origin",
                                    "Sec-Fetch-Mode: navigate",
                                    "Sec-Fetch-User: ?1",
                                    "Sec-Fetch-Dest: iframe",
                                    "Referer: https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoTributos.asp?$data",
                                    "Accept-Language: pt-BR,pt;q=0.9",
                                );
                        
                                $data = http_build_query([
                                    "Ni" => $cnpj_na_pagina,
                                    "TipoContr" => "1",
                                    "NuProcesso" => $numero_processo,
                                    "Situacao" => $situacao,
                                    "QtdParc" => $qtd_parcela,
                                    "NomeTrib" => $nome_tributo,
                                    "SIST" => "PARCWEB"
                                ]);
                                $page = $this->obter_pagina(false, "https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoRelacaoParcelas.asp?$data", [], $headers);
                                $html = new Simple_html_dom();
                                $html->load($page);
                        
                                $table = $html->find('table[cellspacing=2]',0);
                        
                                if ($table){
                                    $trs = $table->find('tr');
                                    $posicao_3  = 0;
                                    foreach ($trs as $tr){
                                        if ($posicao_3 > 0 && $numero_parcela == trim($tr->find('td', 0)->plaintext)){
                                            return $this->baixar_parcela_nao_previdenciario($cnpj_na_pagina, $numero_processo, $situacao, $nome_tributo, $numero_parcela, $data_vencimento, $valor_parcela);
                                        }
                                        $posicao_3++;
                                    }
                                }
                            }
                            $posicao_2++;
                        }
                    }
                }
                $posicao++;
            }
        }
    }

    function baixar_parcela_nao_previdenciario($cnpj_na_pagina, $numero_processo, $situacao, $nome_tributo, $numero_parcela, $data_vencimento, $valor_parcela)
    {
        date_default_timezone_set('America/Bahia');
        $data_atual = date('Ymdhis');
        $headers = array(
            "Connection: keep-alive",
            "Cache-Control: max-age=0",
            'sec-ch-ua: "Google Chrome";v="95", "Chromium";v="95", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Sec-Fetch-Site: none",
            "Sec-Fetch-Mode: navigate",
            "Sec-Fetch-User: ?1",
            "Sec-Fetch-Dest: document",
            "Accept-Language: pt-BR,pt;q=0.9",
        );

        $data = http_build_query([
            "Ni" => $cnpj_na_pagina,
            "TipoContr" => "1",
            "NuProcesso" => $numero_processo,
            "Tributo" => $nome_tributo,
            "DtVenc" => $data_vencimento,
            "VlParcela" => $valor_parcela,
            "NrParcela" => $numero_parcela
        ]);
        curl_setopt($this->curl, CURLOPT_URL , "https://cav.receita.fazenda.gov.br/Servicos/ATSPO/parcweb.app/ExtratoEmissaoDARF.asp?$data" );
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->curl, CURLOPT_COOKIESESSION, 1);
        curl_setopt($this->curl, CURLOPT_FRESH_CONNECT, 1);
        curl_setopt($this->curl, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie_path);
        $caminho_local = $this->caminho_da_pasta_pdfs."/DARF-{$nome_tributo}-{$data_atual}.pdf";
        
        $response = curl_exec($this->curl);

        $response = str_replace('https://cav.receita.fazenda.gov.br/Servicos/ATSPO/Darf.app/estiloDARF.css', base_url('assets/css/boleto-parcelamento/estiloDARF.css'), $response);
        $response = str_replace('https://cav.receita.fazenda.gov.br/Servicos/ATSPO/Darf.app/estiloDARFprint.css', base_url('assets/css/boleto-parcelamento/estiloDARFprint.css'), $response);
        $response = str_replace('https://cav.receita.fazenda.gov.br/Servicos/ATSPO/Darf.app/imagens/brasil.gif', base_url('assets/css/boleto-parcelamento/brasil.gif'), $response);
      
        $options = new Options();
        $options->set('isRemoteEnabled', TRUE);
        $dompdf = new Dompdf($options);

        $dompdf->loadHtml($response);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $content = $dompdf->output();

        $aux_dir_ext = str_replace(FCPATH, "",$caminho_local);
        $aux_dir_ext = str_replace("//", "/", $aux_dir_ext);
        if ( $this->verifica_pdf_valido($content)){
            upload_google_source($content, $aux_dir_ext);
            $retorno = "https://storage.googleapis.com/cron-veri-files-br/".$aux_dir_ext;
        }

        if(curl_errno($this->curl))
        {
            echo curl_error($this->curl);
            return false;
        }   

        return $retorno;
    }

    function verifica_pdf_valido($content){
        if (preg_match("/^%PDF-1./", $content)) {
            return true;
        } else {
            return false;
        }
    }
}