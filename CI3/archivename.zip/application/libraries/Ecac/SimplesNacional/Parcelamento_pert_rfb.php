<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once(APPPATH . 'libraries/Ecac/Ecac.php');


class Parcelamento_pert_rfb extends Ecac
{
    public function __construct($params = array(), $conectar = true)
    {
        parent::__construct($params, $conectar);
    }

    function obter_parcelamentos($cnpj)
    {
        $parcelamentos = array();

        $headers = array(
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Upgrade-Insecure-Requests: 1",
            "Referer: https://cav.receita.fazenda.gov.br/",
        );

        $page = $this->obter_pagina(false, 'https://sic.cav.receita.fazenda.gov.br/siefpar-internet/home.html', [], $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "Accept: application/json, text/plain, */*",
            "Content-Type: application/json",
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Origin: https://sic.cav.receita.fazenda.gov.br",
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-Dest: empty",
            "Referer: https://sic.cav.receita.fazenda.gov.br/siefpar-internet/ng/consultar-parcelamento/consultar-parcelamento",
            "Accept-Language: pt-BR,pt;q=0.9",
        );
        $data = '{"ni":"' . $cnpj . '","mesInicial":null,"anoInicial":null,"mesFinal":null,"anoFinal":null}';

        $page = $this->obter_pagina(true, 'https://sic.cav.receita.fazenda.gov.br/siefpar-internet/cons/api/private/parc/consulta/consultar-parcelamento/consultar', $data, $headers);
        $html = new Simple_html_dom();
        $html->load($page);

        $parcelamentos = json_decode($html);

        foreach ($parcelamentos as $parcelamento) {
            
            $parcelamento[0]->demonstrativo_de_parcelas =  $this->obter_demonstrativo_de_parcelas($parcelamento[0]->idFormatado);

            $parcelamento[0]->demonstrativo_de_pagamentos =  $this->obter_demonstrativo_de_pagamentos($parcelamento[0]->idFormatado);
        }

        return $parcelamentos;
    }

    private function obter_demonstrativo_de_parcelas($id)
    {
        $url = 'https://sic.cav.receita.fazenda.gov.br/siefpar-internet/cons/api/private/parc/consulta/demonstrativo-parcela/demonstrativo?idParc=' . $id;

            curl_setopt($this->curl, CURLOPT_URL, $url);
            curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($this->curl, CURLOPT_FRESH_CONNECT, 0);
            curl_setopt($this->curl, CURLOPT_POST, 0);
            curl_setopt($this->curl, CURLOPT_FORBID_REUSE, 1);
            curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, 0);
            curl_setopt($this->curl, CURLOPT_FAILONERROR, 0);

            $headers = array(
                "Connection: keep-alive",
                'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
                "Accept: application/json, text/plain, */*",
                "sec-ch-ua-mobile: ?0",
                'sec-ch-ua-platform: "Windows"',
                "Sec-Fetch-Site: same-origin",
                "Sec-Fetch-Mode: cors",
                "Sec-Fetch-Dest: empty",
                "Referer: https://sic.cav.receita.fazenda.gov.br/siefpar-internet/ng/consultar-parcelamento/demonstrativo-parcela",
                "Accept-Language: pt-BR,pt;q=0.9",
            );
            curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($this->curl);
            return json_decode($response);
    }

    private function obter_demonstrativo_de_pagamentos($id)
    {
        $url = 'https://sic.cav.receita.fazenda.gov.br/siefpar-internet/cons/api/private/parc/consulta/demonstrativo-pagamento/obter-demonstrativo-pagamentos?idParc=' . $id;

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_FRESH_CONNECT, 0);
        curl_setopt($this->curl, CURLOPT_POST, 0);
        curl_setopt($this->curl, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($this->curl, CURLOPT_FAILONERROR, 0);

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "Accept: application/json, text/plain, */*",
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-Dest: empty",
            "Referer: https://sic.cav.receita.fazenda.gov.br/siefpar-internet/ng/consultar-parcelamento/demonstrativo-pagamento",
            "Accept-Language: pt-BR,pt;q=0.9",
        );
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($this->curl);
        return json_decode($response);
    }

    //GERAR PARCELA
    function gerar_parcela_pert_rfb($id_formatado, $id_parcela){
        date_default_timezone_set('America/Bahia');
        $data_atual = date('Ymdhis');

        $url = 'https://sic.cav.receita.fazenda.gov.br/siefpar-internet/cons/api/private/parc/consulta/emissao/emitir-documento-arrecadacao-parcela?idParc='.$id_formatado.'&idsParcelas='.$id_parcela;

        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_FRESH_CONNECT, 0);
        curl_setopt($this->curl, CURLOPT_POST, 0);
        curl_setopt($this->curl, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($this->curl, CURLOPT_FAILONERROR, 0);

        $headers = array(
            "Connection: keep-alive",
            'sec-ch-ua: "Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
            "Accept: application/json, text/plain, */*",
            "sec-ch-ua-mobile: ?0",
            'sec-ch-ua-platform: "Windows"',
            "Sec-Fetch-Site: same-origin",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-Dest: empty",
            "Referer: https://sic.cav.receita.fazenda.gov.br/siefpar-internet/ng/consultar-parcelamento/demonstrativo-pagamento",
            "Accept-Language: pt-BR,pt;q=0.9",
        );
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);

        $content = curl_exec($this->curl);


        $caminho_local = $this->caminho_da_pasta_pdfs."/DARF-{$data_atual}.pdf";

        $aux_dir_ext = str_replace(FCPATH, "",$caminho_local);
        $aux_dir_ext = str_replace("//", "/", $aux_dir_ext);
        if ( $this->verifica_pdf_valido($content)){
            upload_google_source($content, $aux_dir_ext);
            $retorno = "https://storage.googleapis.com/cron-veri-files-br/".$aux_dir_ext;
        }

        if(curl_errno($this->curl))
        {
            echo curl_error($this->curl);
            return false;
        }
        return $retorno;
    }

    function verifica_pdf_valido($content){
        if (preg_match("/^%PDF-1./", $content)) {
            return true;
        } else {
            return false;
        }
    }
}
