<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Cron_parcelamento_nao_previdenciario_procuracao extends CI_Controller
{
    function buscar(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');
        $folder_pdf = FCPATH . 'arquivos/parcelamento-nao-prividenciario/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }

            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_1(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_1($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);

                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }
            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_2(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_2($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }

            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_3(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_3($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }

            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_4(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_4($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    
                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo);
                    
                    if($existe_tributos_processos_negociados->qtd <= 0){
                        foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                            $tributos_do_processo['id_processo'] = $id_processo;
                            $tributos_do_processo['cnpj'] = $item->cnpj;

                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);

                            foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                                $demonstrativo['id_tributo'] = $id_tributo;
                                $demonstrativo['cnpj'] = $item->cnpj;
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }else{
                        foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                            $tributos_do_processo['id_processo'] = $id_processo;
                            $tributos_do_processo['cnpj'] = $item->cnpj;
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);

                            foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                                $demonstrativo['id_tributo'] = $id_tributo;
                                $demonstrativo['cnpj'] = $item->cnpj;
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }
                        }
                    }
                }
            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_5(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_5($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }

            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function buscar_extra_6(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Parcelamento_nao_previdenciario_processos_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model');
        $this->load->model('Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_6($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento_nao_previdenciario', $params, 'ecac_robo_library_procuracao');
            
            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */

            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                
                if (!$trocou_perfil) continue;

                $registros = $this->ecac_robo_library_procuracao->processos_negociados();

                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_registro = $this->Parcelamento_nao_previdenciario_processos_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $registro['processo']);

                    if($existe_registro->qtd > 0){
                        $id_processo = $existe_registro->id;
                        if ($registro['situacao'] != 'Parcelado')
                            $this->Parcelamento_nao_previdenciario_processos_negociados_model->update( $registro['cnpj'], $banco, $registro['processo'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Parcelado')
                            continue;
                        $id_processo = $this->Parcelamento_nao_previdenciario_processos_negociados_model->insert($registro, $banco);
                    }

                    foreach ($registro['tributos_do_processo_negociados'] as $tributos_do_processo){
                        $existe_tributos_processos_negociados = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->verifica_se_existe($registro['cnpj'], $banco, $id_processo, $tributos_do_processo['tributo']);
                        $tributos_do_processo['id_processo'] = $id_processo;
                        $tributos_do_processo['cnpj'] = $item->cnpj;

                        if($existe_tributos_processos_negociados->qtd > 0){
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->update($tributos_do_processo, $banco);
                        }else{
                            $id_tributo = $this->Parcelamento_nao_previdenciario_tributos_do_processo_negociados_model->insert($tributos_do_processo, $banco);
                        }

                        foreach ($tributos_do_processo['demonstrativo_das_parcelas'] as $demonstrativo) {
                            $existe =  $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_tributo, $demonstrativo['numero_parcela']);
                            $demonstrativo['id_tributo'] = $id_tributo;
                            $demonstrativo['cnpj'] = $item->cnpj;
                            if ( $existe->qtd > 0 ) {
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->update($demonstrativo, $banco);
                            }else{
                                $this->Parcelamento_nao_previdenciario_demonstrativo_das_parcelas_model->insert($demonstrativo, $banco);
                            }
                        }
                    }
                }
            }
            //Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }
}