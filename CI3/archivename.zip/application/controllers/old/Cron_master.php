<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('America/Bahia');

class Cron_master extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function carga_1(){
        $dbh = new PDO('mysql:host=34.95.237.29;', 'userParaConta2_1', '1*Acesso!@Cria*2_conta*!', array(
            PDO::ATTR_PERSISTENT => true
        ));


        $sql = $dbh->query("SELECT DISTINCT SCHEMA_NAME AS `database`
                            FROM information_schema.SCHEMATA
                            WHERE  SCHEMA_NAME NOT IN ('information_schema', 'performance_schema', 'mysql', 'phpmyadmin', 'testesistemasp', 'demo', 'baseteste', 'testebr', 'copia', 'testesistemasp')
                            ORDER BY SCHEMA_NAME");
        $getAllDbs = $sql->fetchALL(PDO::FETCH_ASSOC);

        $cliente = 1;

        foreach ($getAllDbs as $DB) {  

            if ($cliente <= 15) {
                
                $hostCompleto = $_SERVER['HTTP_HOST'];
        
                // CRON DIAGNOSTICO FISCAL
                $urlDiagnostico = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_fiscal_ecac_procuracao/cron_situacao_fiscal_com_procuracao/".$DB['database'];
                $this->get($urlDiagnostico);     

                // CRON CADIN
                $urlCadin = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_cadin_ecac_procuracao/cron_pendencia_cadin_com_procuracao/".$DB['database'];
                $this->get($urlCadin);   

                // CRON MENSAGEM ECAC
                $urlMensagensEcac = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Mensagens_ecac_procuracao/buscar_ecac_com_procuracao/".$DB['database'];
                $this->get($urlMensagensEcac);   

                // CRON DCTF
                $urlDctf = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Dctf_ecac_procuracao/cron_dctf/".$DB['database'];
                $this->get($urlDctf);  

                // CRON DAS
                $urlDas = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das/".$DB['database'];
                $this->get($urlDas);    

                // CRON DAS DEBITOS
                $urlDasDebitos = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das_debitos/".$DB['database'];
                $this->get($urlDasDebitos); 

                // CRON VENCIMENTO PROCURAÇÃO
                $urlVencimentoProc = "http://".$hostCompleto."/SistemaCronsCertificado/sp/vencimento_procuracao/cron_procuracao/".$DB['database'];
                $this->get($urlVencimentoProc);    

            }

            if($cliente == 15){
                break;
            }

            $cliente++;   
        }
    }

    public function carga_2(){
        $dbh = new PDO('mysql:host=34.95.237.29;', 'userParaConta2_1', '1*Acesso!@Cria*2_conta*!', array(
            PDO::ATTR_PERSISTENT => true
        ));

        $parametro_1 = $this->uri->segment(3);
        $parametro_2 = $this->uri->segment(4);

        $sql = $dbh->query("SELECT DISTINCT SCHEMA_NAME AS `database`
                            FROM information_schema.SCHEMATA
                            WHERE  SCHEMA_NAME NOT IN ('information_schema', 'performance_schema', 'mysql', 'phpmyadmin', 'testesistemasp', 'demo', 'baseteste', 'testebr', 'copia', 'testesistemasp')
                            ORDER BY SCHEMA_NAME");
        $getAllDbs = $sql->fetchALL(PDO::FETCH_ASSOC);

        $cliente = 1;

        foreach ($getAllDbs as $DB) {  

            if ($cliente > $parametro_1 && $cliente <= $parametro_2) {
                
                $hostCompleto = $_SERVER['HTTP_HOST'];
        
                // CRON DIAGNOSTICO FISCAL
                $urlDiagnostico = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_fiscal_ecac_procuracao/cron_situacao_fiscal_com_procuracao/".$DB['database'];
                $this->get($urlDiagnostico);     

                // CRON CADIN
                $urlCadin = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_cadin_ecac_procuracao/cron_pendencia_cadin_com_procuracao/".$DB['database'];
                $this->get($urlCadin);   

                // CRON MENSAGEM ECAC
                $urlMensagensEcac = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Mensagens_ecac_procuracao/buscar_ecac_com_procuracao/".$DB['database'];
                $this->get($urlMensagensEcac);   

                // CRON DCTF
                $urlDctf = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Dctf_ecac_procuracao/cron_dctf/".$DB['database'];
                $this->get($urlDctf);  

                // CRON DAS
                $urlDas = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das/".$DB['database'];
                $this->get($urlDas);    

                // CRON DAS DEBITOS
                $urlDasDebitos = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das_debitos/".$DB['database'];
                $this->get($urlDasDebitos); 

                // CRON VENCIMENTO PROCURAÇÃO
                $urlVencimentoProc = "http://".$hostCompleto."/SistemaCronsCertificado/sp/vencimento_procuracao/cron_procuracao/".$DB['database'];
                $this->get($urlVencimentoProc);         
            }

            if($cliente == $parametro_2){
                break;
            }

            $cliente++;   
        }
    }

    function get($url){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_exec($ch);
        curl_close($ch);

    }
}


