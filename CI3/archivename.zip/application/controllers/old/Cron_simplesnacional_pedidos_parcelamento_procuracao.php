<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Cron_simplesnacional_pedidos_parcelamento_procuracao  extends CI_Controller
{
    function buscar(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //			Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    // CRONS EXTRA CLIENTES MAIORES
    function buscar_extra_1(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_1($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    function buscar_extra_2(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_2($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    function buscar_extra_3(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_3($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    function buscar_extra_4(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_4($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    function buscar_extra_5(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_5($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }

    function buscar_extra_6(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('Simplesnacional_debitos_parcelas_model');
        $this->load->model('Simplesnacional_demonstrativo_pagamentos_model');
        $this->load->model('Simplesnacional_pedidos_parcelamentos_model');
        $folder_pdf = FCPATH . 'arquivos/recibos-parcelamento-simplesnacional/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }
        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_6($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/SimplesNacional/Parcelamento', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){
                $trocou_perfil = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if (!$trocou_perfil) continue;
                $registros = $this->ecac_robo_library_procuracao->obter_parcelamento();
                foreach ($registros as $registro){
                    $registro['cnpj'] = $item->cnpj;

                    $existe_pedido = $this->Simplesnacional_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                    if($existe_pedido->qtd > 0){
                        $id_parcelamento = $existe_pedido->id;
                        $this->Simplesnacional_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                    }else{
                        if ($registro['situacao'] != 'Em parcelamento')
                            continue;
                        $id_parcelamento = $this->Simplesnacional_pedidos_parcelamentos_model->insert($registro, $banco);
                    }


                    $existe_debitos_parcelas = $this->Simplesnacional_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                    if($existe_debitos_parcelas->qtd <= 0){
                        foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                            // $this->Simplesnacional_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                            $rdp['cnpj'] = $item->cnpj;
                            $rdp['id_parcelamento'] = $id_parcelamento;
                            $this->Simplesnacional_debitos_parcelas_model->insert($rdp, $banco);
                        }
                    }


                    foreach ($registro['demonstrativo_pagamentos'] as $dp){
                        $dp['cnpj'] = $item->cnpj;
                        $dp['id_parcelamento'] = $id_parcelamento;

                        $existe_pagamento = $this->Simplesnacional_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                        if($existe_pagamento->qtd <= 0){
                            $this->Simplesnacional_demonstrativo_pagamentos_model->insert($dp, $banco);
                        }
                        // $this->Simplesnacional_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                    }

                }

            }
            //          Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }


    }
}