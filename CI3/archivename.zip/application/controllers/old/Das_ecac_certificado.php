<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Das_ecac_certificado extends CI_Controller {

	function cron_das(){
		
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificado_model', 'certificado');
        $this->load->model('das_model');

        $folder_pdf = FCPATH . 'arquivos/pdf-das-ecac-sp/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }

        date_default_timezone_set('America/Bahia');

        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal Ecac_robo_library
             */
            $params = array('caminho_certificado' => 'https://veri-sp.com.br/crons-api/'.str_replace('//','/', $cerficado->caminho_arq ) ,
                'cerficado_senha' => $cerficado->pass,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );
            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library->acesso_valido()){
                unset($this->ecac_robo_library);
                continue;
            }

            echo "Buscando dados da empresa: ".$this->ecac_robo_library->obter_numero_documento()."\n";
            $lista_das = $this->ecac_robo_library->get_das();
            if ($lista_das && count($lista_das) > 0)
                foreach ($lista_das as $dados){
                    $dados['cnpj'] = $cerficado->cnpj_data;
                    $existe = $this->das_model->verifica_se_existe($dados['numero_declaracao'], $banco, $dados['cnpj']);

                   
                    if($existe->qtd > 0){
                        $this->das_model->update($dados, $banco);
                    }else{
                        $this->das_model->insert($dados, $banco);
                    }

                    $this->load->model('das_pago_retificado_model');
                    if ( isset( $dados['das_pago_retificado'] ) ){
                        $retificado = $dados['das_pago_retificado'];
                        $retificado['cnpj'] = $dados['cnpj'];
                        $retificado['numero_declaracao_retificacao'] = $dados['numero_declaracao'];

                        $existe = $this->das_pago_retificado_model->verifica_se_existe($retificado['numero_declaracao'], $banco, $dados['cnpj']);
                        if($existe->qtd > 0){
                            $this->das_pago_retificado_model->update($retificado, $banco);
                        }else{
                            $this->das_pago_retificado_model->insert($retificado, $banco);
                        }
                    }
                }

            unset($this->ecac_robo_library);

        }

    }

    function cron_das_debitos(){

        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificado_model', 'certificado');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');

        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal Ecac_robo_library
             */
            $params = array('caminho_certificado' => 'https://veri-sp.com.br/crons-api/'.str_replace('//','/', $cerficado->caminho_arq ) ,
                'cerficado_senha' => $cerficado->pass,
            );
            $this->load->library('Ecac_robo_eprocessos_library', $params, 'ecac_robo_library');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library->acesso_valido()){
                unset($this->ecac_robo_library);
                continue;
            }

            $registros = $this->ecac_robo_library->get_das_debitos();
            if ( $registros ){
                $this->das_debitos_model->clear($this->ecac_robo_library->get_numero_documento(), $banco);
                foreach ($registros as $registro){
                    $registro['cnpj'] = $this->ecac_robo_library->get_numero_documento();
                    $this->das_debitos_model->insert($registro, $banco);
                }
            }

            unset($this->ecac_robo_library);

        }

    }
}