<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('America/Bahia');

class Cron_teste extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function buscar_teste(){

        $banco = $this->uri->segment(3);

        // CRON - CORRIGE PGDAS - BR
        $urlCorrigePgdas = "http://localhost/SistemaCronsCertificado/sp/Situacao_fiscal_ecac_procuracao/cron_situacao_fiscal_com_procuracao/".$banco;
        $this->get($urlCorrigePgdas);        
    }

    function get($url){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        curl_close($ch);

    }
    
}


