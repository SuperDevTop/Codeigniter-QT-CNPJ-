<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Gia extends CI_Controller {

	public function buscar(){

		//VARIAVEL $banco É O NOME DO BANCO QUE É PASSADO COMO TERCEIRO PARÂMETRO NA URL
		$banco = $this->uri->segment(3);

		$command = escapeshellcmd("python3.9 "."/var/www/html/crons-api/gia_sp/main.py ".$banco);
		$output = Shell_exec($command);
		echo $output; 
		
	} 

}