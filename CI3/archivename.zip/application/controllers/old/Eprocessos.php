<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eprocessos extends CI_Controller {

	public function buscar(){

		//VARIAVEL $banco É O NOME DO BANCO QUE É PASSADO COMO TERCEIRO PARÂMETRO NA URL
		$banco = $this->uri->segment(3);

		$command = escapeshellcmd("python3.9 "."/var/www/html/crons-api/eprocessos/main.py ".$banco);
		var_dump(shell_exec($command." 2>&1"));
		// $output = Shell_exec($command);
		// echo $output; 
		
	} 

}