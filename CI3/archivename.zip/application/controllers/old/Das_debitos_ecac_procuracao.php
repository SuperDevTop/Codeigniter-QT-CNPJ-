<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Das_debitos_ecac_procuracao extends CI_Controller {

    // DAS simples nacional debitos
    function cron_das_debitos(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_1(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_1($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_2(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_2($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_3(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_3($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_4(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_4($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_5(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_5($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    function cron_das_debitos_extra_6(){
        $banco = $this->uri->segment(3);
        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_debitos_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado, 
            );

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_6($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }


            foreach ($empresas_com_procuracao as $item){

                $validado = $this->ecac_robo_library_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }
                $registros = $this->ecac_robo_library_procuracao->get_das_debitos();
                if ( $registros ){
                    $this->das_debitos_model->clear($item->cnpj, $banco);
                    foreach ($registros as $registro){
                        $registro['cnpj'] = $item->cnpj;
                        $this->das_debitos_model->insert($registro, $banco);
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

}
