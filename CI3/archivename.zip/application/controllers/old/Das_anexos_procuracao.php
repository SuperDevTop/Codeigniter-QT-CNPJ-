<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Das_anexos_procuracao extends CI_Controller {

    function cron_das(){

        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('das_model');
        $this->load->helper('googlestorage_helper');
        $folder_pdf = FCPATH . 'arquivos/pdf-das-ecac-sp/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){
            $empresas_com_procuracao = $this->certificado->get_empresas_ecac_ativa($banco, $cerficado->id_contador);
            if (count($empresas_com_procuracao) <= 0)
                continue;
            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf,
            );


            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){
                $cnpj = $item->cnpj;

                $lista_das = $this->das_model->get_all($banco, $cnpj);
                if (count($lista_das) <= 0)
                    continue;

                if(!$this->ecac_robo_library_procuracao->trocar_perfil($cnpj)){
                    continue;
                }

                foreach ($lista_das as $das){
                    $numero_declaracao = $das->numero_declaracao;
                    $numero_das = $das->numero_das;
                    $ano = date('Y');
                    $dados = array();
                    $dados['numero_declaracao'] = $numero_declaracao;
                    if ( empty($das->caminho_download_extrato) || $das->caminho_download_extrato == 'NULL') {
                        if ( intval($numero_das) > 0 ){
                            $path_extrato = $this->ecac_robo_library_procuracao->baixar_extrato_das($numero_declaracao, $numero_das, $ano);
                            if(!empty($path_extrato)){
                                $cami_aux_ext = "https://storage.googleapis.com/cron-veri-files-br/".$path_extrato;
                                $dados['caminho_download_extrato'] = $cami_aux_ext;
                            }
                        }
                    }

                    if ( empty($das->caminho_download_declaracao) || $das->caminho_download_declaracao == 'NULL' ) {
                        $path_declaracao = $this->ecac_robo_library_procuracao->baixar_declaracao_das($numero_declaracao, $ano);
                        if(!empty($path_declaracao)){
                            $cami_aux_rec = "https://storage.googleapis.com/cron-veri-files-br/".$path_declaracao;
                            $dados['caminho_download_declaracao'] = $cami_aux_rec;

                        }
                    }

                    if (  empty($das->caminho_download_recibo) || $das->caminho_download_recibo == 'NULL'){
                        $path_recibo = $this->ecac_robo_library_procuracao->baixar_recibo_das($numero_declaracao, $ano);
                        if(!empty($path_recibo)){
                            $cami_aux_dec = "https://storage.googleapis.com/cron-veri-files-br/".$path_recibo;
                            $dados['caminho_download_recibo'] = $cami_aux_dec;

                        }

                    }

                    $this->das_model->update_anexos($dados, $banco);
                    $this->verifica_das_pago_retificado($das, $banco);
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
        }
    }

    private function verifica_das_pago_retificado($das, $banco){
        $this->load->model('das_pago_retificado_model');
        $das_pago = $this->das_pago_retificado_model->busca_por_declaracao_retificada($banco, $das->numero_declaracao);

        if ( $das_pago ){
            $numero_declaracao = $das_pago->numero_declaracao;
            $numero_das = $das_pago->numero_das;
            $ano = date('Y');
            $dados['numero_declaracao'] = $numero_declaracao;
            if ( empty($das_pago->caminho_download_extrato) || $das->caminho_download_extrato == 'NULL' ) {
                if ( intval($numero_das) > 0 ){
                    $path_extrato = $this->ecac_robo_library_procuracao->baixar_extrato_das($numero_declaracao, $numero_das, $ano);
                    if(!empty($path_extrato)){
                        $cami_aux_ext = "https://storage.googleapis.com/cron-veri-files-br/".$path_extrato;
                        $dados['caminho_download_extrato'] = $cami_aux_ext;
                    }
                }
            }

            if ( empty($das_pago->caminho_download_declaracao) || $das->caminho_download_declaracao == 'NULL') {
                $path_declaracao = $this->ecac_robo_library_procuracao->baixar_declaracao_das($numero_declaracao, $ano);
                if(!empty($path_declaracao)){
                    $cami_aux_rec = "https://storage.googleapis.com/cron-veri-files-br/".$path_declaracao;
                    $dados['caminho_download_declaracao'] = $cami_aux_rec;
                }
            }

            if (  empty($das_pago->caminho_download_recibo) || $das->caminho_download_recibo == 'NULL'){
                $path_recibo = $this->ecac_robo_library_procuracao->baixar_recibo_das($numero_declaracao, $ano);
                if(!empty($path_recibo)){
                    $cami_aux_dec = "https://storage.googleapis.com/cron-veri-files-br/".$path_recibo;
                    $dados['caminho_download_recibo'] = $cami_aux_dec;
                }

            }

            $this->das_pago_retificado_model->update_anexos($dados, $banco);
        }
    }
}
