<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dctf_ecac_procuracao extends CI_Controller {

    function cron_dctf(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_declaracao_teste(){
        
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificado_model', 'certificado');
        $this->load->model('dctf_model');

        date_default_timezone_set('America/Bahia');

        $cerficados = $this->certificado->get($banco);

        $folder_pdf = FCPATH . 'arquivos/pdf-dctf-ecac/declaracaodctf/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal Ecac_robo_library
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $folder_pdf);
            
            $this->load->library('Ecac_robo_eprocessos_library', $params);

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_eprocessos_library->acesso_valido()){
                unset($this->ecac_robo_eprocessos_library);
                continue;
            }

            /**
             * DCTF consulta
             */
            $this->dctf_model->clear($this->ecac_robo_eprocessos_library->obter_numero_documento(), $banco);
            $dctf = $this->ecac_robo_eprocessos_library->get_dctf_declaracao();
            foreach ($dctf as $item) {
                $this->dctf_model->insert($item, $banco);
            }

            unset($this->ecac_robo_eprocessos_library);
        }
    }

    // CRONS EXTRA CLIENTES MAIORES
    function cron_dctf_extra_1(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_1($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }            

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_extra_2(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_2($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_extra_3(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_3($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_extra_4(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_4($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_extra_5(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_5($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

    function cron_dctf_extra_6(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('contadorprocuracao_model', 'contadorprocuracao');
        $this->load->model('dctf_model');


        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        $dctf_declarados = $this->dctf_model->find_all_dctf($banco);
        $myhashmap = array();
        foreach ($dctf_declarados as $d) {
            $myhashmap[$d->cnpj."/".$d->periodo] = $d;
        }
        
        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('numero_documento_certificado' => $cerficado->cnpj_data,
                'certificado' => $cerficado,
                'caminho_da_pasta_pdfs' => $this->config->item('caminho_pasta_pdf'));

            $empresas_com_procuracao = $this->contadorprocuracao->buscar_empresas_vinculadas_extra_6($banco, $cerficado->id_contador);

            if (empty($empresas_com_procuracao)) {
                continue;
            }

            $this->load->library('Ecac/Dctf', $this->params, 'ecac_robo_library_eprocessos_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }
            
            foreach ($empresas_com_procuracao as $item){

                /**
                 * Função que altera o perfil no portal
                 */
                $validado = $this->ecac_robo_library_eprocessos_procuracao->trocar_perfil($item->cnpj);
                if(! $validado){
                    echo "CNPJ: {$item->cnpj} - sem procuração";
                    continue;
                }

                /**
                 * dctf consulta
                 */

                // $this->dctf_model->clear($this->ecac_robo_library_eprocessos_procuracao->obter_numero_documento(), $banco);
                
                $dctf = $this->ecac_robo_library_eprocessos_procuracao->get_dctf($myhashmap);
                foreach ($dctf as $item_aux) {
                    echo "CNPJ: {$item->cnpj} - inserido";
                    $this->dctf_model->insert($item_aux, $banco);
                }

            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }
}
