<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vencimento_procuracao extends CI_Controller {

	function cron_procuracao(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificadocontador_model', 'certificado');
        $this->load->model('procuracao_model');

        date_default_timezone_set('America/Bahia');

        $cerficados = $this->certificado->get($banco);
        $this->procuracao_model->clear('', $banco);

        foreach ($cerficados as $cerficado){

            /**
             * Carrega a library principal Ecac_robo_library
             */
           $params = array('caminho_certificado' => 'https://veri-sp.com.br/crons-api/'.str_replace('//','/', $cerficado->caminho_arq ) ,
            // $params = array('caminho_certificado' => str_replace('//','/', $cerficado->caminho_arq ) ,
            'cerficado_senha' => $cerficado->pass,
                'caminho_da_pasta_pdfs' => '');
            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params);



            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library_eprocessos_procuracao->acesso_valido()){
                unset($this->ecac_robo_library_eprocessos_procuracao);
                continue;
            }

            /**
             * PROCURAÇÃO consulta
             */
            $procuracoes = $this->ecac_robo_library_eprocessos_procuracao->get_procuracoes();
            if ($procuracoes){

                foreach ($procuracoes as $item) {
                    $this->procuracao_model->insert($cerficado->cnpj_data, $item, $banco);
                }
            }
            unset($this->ecac_robo_library_eprocessos_procuracao);
        }
    }

}