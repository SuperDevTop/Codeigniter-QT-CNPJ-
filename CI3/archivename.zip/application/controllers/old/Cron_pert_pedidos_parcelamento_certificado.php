<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Cron_pert_pedidos_parcelamento_certificado  extends CI_Controller
{
    function buscar(){
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificado_model', 'certificado');
        $this->load->model('Pert_debitos_parcelas_model');
        $this->load->model('Pert_demonstrativo_pagamentos_model');
        $this->load->model('Pert_pedidos_parcelamentos_model');

        date_default_timezone_set('America/Bahia');

        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado){
            /**
             * Carrega a library principal Ecac_robo_library
             */
            $params = array('certificado' => $cerficado,
            );
            $this->load->library('Ecac/SimplesNacional/Parcelamento_pert', $params, 'ecac_robo_library');


            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if(!$this->ecac_robo_library->acesso_valido()){
                unset($this->ecac_robo_library);
                continue;
            }

            $registros = $this->ecac_robo_library->obter_parcelamento();
          
            foreach ($registros as $registro){
                $registro['cnpj'] = $cerficado->cnpj_data;

                $existe_pedido = $this->Pert_pedidos_parcelamentos_model->verifica_se_existe($registro['cnpj'], $banco, $registro['numero']);

                if($existe_pedido->qtd > 0){
                    $id_parcelamento = $existe_pedido->id;
                    $this->Pert_pedidos_parcelamentos_model->update( $registro['cnpj'], $banco, $registro['numero'],  $registro['situacao']);
                }else{
                    if ($registro['situacao'] != 'Em parcelamento')
                        continue;
                    $id_parcelamento = $this->Pert_pedidos_parcelamentos_model->insert($registro, $banco);
                }


                $existe_debitos_parcelas = $this->Pert_debitos_parcelas_model->verifica_se_existe($registro['cnpj'], $banco, $id_parcelamento);

                if($existe_debitos_parcelas->qtd <= 0){
                    foreach ($registro['relacao_debitos_parcelas'] as $rdp){
                        // $this->Pert_debitos_parcelas_model->clear($registro['cnpj'], $banco);
                        $rdp['cnpj'] = $cerficado->cnpj_data;
                        $rdp['id_parcelamento'] = $id_parcelamento;
                        $this->Pert_debitos_parcelas_model->insert($rdp, $banco);
                    }
                }


                foreach ($registro['demonstrativo_pagamentos'] as $dp){
                    $dp['cnpj'] = $cerficado->cnpj_data;
                    $dp['id_parcelamento'] = $id_parcelamento;

                    $existe_pagamento = $this->Pert_demonstrativo_pagamentos_model->verifica_se_existe($dp['cnpj'], $banco, $id_parcelamento, $dp['mes_parcela']);
                    if($existe_pagamento->qtd <= 0){
                        $this->Pert_demonstrativo_pagamentos_model->insert($dp, $banco);
                    }
                    // $this->Pert_demonstrativo_pagamentos_model->clear($registro['cnpj'], $banco);
                }

            }
            unset($this->ecac_robo_library);
        }
    }
}