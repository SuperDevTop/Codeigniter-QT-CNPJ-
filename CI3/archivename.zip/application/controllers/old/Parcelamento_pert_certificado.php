<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parcelamento_pert_certificado extends CI_Controller {

    function buscar_parcelas() {
        $banco = $this->uri->segment(3);

        $this->config->load('ecac_robo_config');
        $this->load->model('certificado_model', 'certificado');
        $this->load->model('Parcelas_pert_model');

        date_default_timezone_set('America/Bahia');
        $cerficados = $this->certificado->get($banco);

        foreach ($cerficados as $cerficado) {
            /**
             * Carrega a library principal ecac_robo_library_procuracao
             */
            $params = array('caminho_certificado' => 'https://veri-sp.com.br/crons-api/'.str_replace('//','/', $cerficado->caminho_arq ) ,
                'cerficado_senha' => $cerficado->pass,
            );


            $this->load->library('Ecac_robo_library_eprocessos_procuracao', $params, 'ecac_robo_library_procuracao');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if (!$this->ecac_robo_library_procuracao->acesso_valido()) {
                unset($this->ecac_robo_library_procuracao);
                continue;
            }
            
            //$parcelas = $this->ecac_robo_library_procuracao->obter_simples_nacional_emissao_parcela();
            $parcelas = $this->ecac_robo_library_procuracao->obter_parcelas_pert();
            print_r($parcelas);
            if ($parcelas) {
                foreach ($parcelas as $parcela) {
                    $result = $this->Parcelas_pert_model->verifica_se_existe($banco, $cerficado->cnpj_data, $parcela['data_parcela']);
                    if ($result->qtd > 0) {
                        $this->Parcelas_pert_model->update($cerficado->cnpj_data, $banco, $parcela);
                    } else {
                        $this->Parcelas_pert_model->insert($cerficado->cnpj_data, $banco, $parcela);
                    }
                    if ( !isset($result['path_download_parcela']) || empty($result['path_download_parcela']) ){
                        try {
                            $this->baixar_pdf($banco, $cerficado->cnpj_data, trim($parcela['data_parcela']));
                        } catch (Exception $e) {
                            echo $e->getMessage();
                        }
                    }
                }
            }

            // Tem que fazer unset pra ele executar  o destrutor da library e encerrar a connection
            unset($this->ecac_robo_library_procuracao);
     }
    }

    public function baixar_pdf($banco, $cnpj, $data_parcela){
        $caminho_download = $this->ecac_robo_library_procuracao->gerar_parcela_pert($data_parcela);
        if($caminho_download != ""){
            $this->Simplesnacional_emissao_parcela_model->update_path($banco, $data_parcela, $cnpj, $caminho_download);
            return $caminho_download;
        }
    }
}
