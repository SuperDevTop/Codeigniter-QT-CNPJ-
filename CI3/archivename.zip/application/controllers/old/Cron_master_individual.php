<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('America/Bahia');

class Cron_master_individual extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function buscar(){

        $banco = $this->uri->segment(3);
        $hostCompleto = $_SERVER['HTTP_HOST'];
        
        // CRON DIAGNOSTICO FISCAL
        $urlDiagnostico = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_fiscal_ecac_procuracao/cron_situacao_fiscal_com_procuracao/".$banco;
        $this->get($urlDiagnostico);     

        // CRON CADIN
        $urlCadin = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Situacao_cadin_ecac_procuracao/cron_pendencia_cadin_com_procuracao/".$banco;
        $this->get($urlCadin);   

        // CRON MENSAGEM ECAC
        $urlMensagensEcac = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Mensagens_ecac_procuracao/buscar_ecac_com_procuracao/".$banco;
        $this->get($urlMensagensEcac);   

        // CRON DCTF
        $urlDctf = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Dctf_ecac_procuracao/cron_dctf/".$banco;
        $this->get($urlDctf);  

        // CRON DAS
        $urlDas = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das/".$banco;
        $this->get($urlDas);    

        // CRON DAS DEBITOS
        $urlDasDebitos = "http://".$hostCompleto."/SistemaCronsCertificado/sp/Das_ecac_procuracao/cron_das_debitos/".$banco;
        $this->get($urlDasDebitos); 

        // CRON VENCIMENTO PROCURAÇÃO
        $urlVencimentoProc = "http://".$hostCompleto."/SistemaCronsCertificado/sp/vencimento_procuracao/cron_procuracao/".$banco;
        $this->get($urlVencimentoProc);
            
    }

    function get($url){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 1);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_exec($ch);
        curl_close($ch);

    }
}


