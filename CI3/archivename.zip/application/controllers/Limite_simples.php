<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Limite_simples extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('certificado_model');
        $this->load->model('certificadocontador_model');
        $this->load->model('das_model');
        $this->load->helper('googlestorage_helper');
    }

    public function processar(){
        include ( 'PdfToText/PdfToText.phpclass' ) ;

        $banco = $this->uri->segment(3);
        $this->load->model('limite_simples_model');

        $empresas = $this->limite_simples_model->busca_empresas_das($banco);
        $pdf    =  new PdfToText() ;

        foreach ($empresas as $e) {
            $extrato = $this->limite_simples_model->busca_das_ano_corrente($banco, $e->cnpj);
            if(empty($extrato->caminho_download_declaracao)) {
                $extrato->caminho_download_declaracao = $this->emitir_function($banco, $extrato->numero_declaracao);
            }
            if(!empty($extrato->caminho_download_declaracao)){
                try{

                    $pdf->Load( $extrato->caminho_download_declaracao ) ;

                    $texto = $pdf -> Text ;

                    $posicao_inicial_numero_declaracao = strpos($texto,"Nº da Declaração");
                    $numero_declaracao_documento = substr($texto,$posicao_inicial_numero_declaracao+20);

                    $nd = explode("1.1", $numero_declaracao_documento);
                    $nd_final = $nd[0];

                    if(trim($extrato->numero_declaracao) != trim($nd_final)){
                        echo "Declaração errada para o cnpj ".$e->cnpj;
                        echo "<br>";

                        $this->limite_simples_model->setar_campo_errado_nulo($banco, $extrato->numero_declaracao);
                        continue;
                    }

                    $posicao_inicio = strpos($texto,"(RBA)");
                    $valor = substr($texto,$posicao_inicio+5);

                    $valor_aux = explode("Receita", $valor);
                    $valor_final = $valor_aux[0];

                    $valores = explode(",", $valor_final);
                    $total = $valores[2];


                    $valor_atual = substr($total,2).",".$valores[3];

                    $valorAtualBanco = str_replace(".","",$valor_atual);
                    $valorAtualBanco = str_replace(",",".",$valorAtualBanco);

                    $percentual = (int) ( ( ( (float) ($valorAtualBanco) ) / 3600000 ) * 100);

                    $existe_situacao = $this->limite_simples_model->verifica_se_existe($e->cnpj, $banco)->qtd;
                    if($existe_situacao > 0){
                        $this->limite_simples_model->update($e->cnpj, $valor_atual, $percentual, $banco, $extrato->caminho_download_declaracao);
                    }else{
                        $this->limite_simples_model->insert($e->cnpj, $valor_atual, $percentual, $banco, $extrato->caminho_download_declaracao);
                    }


                }catch(Exception $x){
                    echo $x->getMessage();
                    echo "ERRO AO PROCESSAR CNPJ - ".$e->cnpj;
                    echo '<br>';
                    continue;
                }
            }
        }
    }

    public function emitir_function($banco, $numero_declaracao){

        $das = $this->das_model->find_by_numero_declaracao($numero_declaracao, $banco);
        $competencia = $das->compentencia;
        $cnpj = $das->cnpj;

        $ano = trim(explode('/', $competencia)[1]);
        $id_empresa = $this->das_model->find_empresa_by_cnpj($banco, $cnpj)->id;
        $cerficados = $this->das_model->get_aux($id_empresa, $banco);

        if(!empty($cerficados)){
            $retorno = $this->emitir_declaracao_procuracao($numero_declaracao,  $ano, $cnpj, $banco, $cerficados);
            return $retorno;
        }else{
            $retorno = $this->emitir_declaracao($numero_declaracao,  $ano, $cnpj, $banco);
            return $retorno;
        }
    }

    public function emitir_declaracao_procuracao($numero_declaracao,  $ano, $cnpj, $banco, $cerficados){

        $folder_pdf = FCPATH . 'arquivos/pdf-das-ecac-sp/'.$banco.'/';

        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }

        $this->load->model('certificadocontador_model');
        $this->load->model('contadorprocuracao_model');

        foreach ($cerficados as $cerficado_contador) {
            $params = array('certificado' => $cerficado_contador
                'caminho_da_pasta_pdfs' => $folder_pdf);

            $this->load->library('Ecac/SimplesNacional/Pgdas', $params, 'ecac_robo_library');

            /**
             * Verifica se o acesso foi validado com sucesso, caso contrário pula para o próximo
             */
            if (!$this->ecac_robo_library->acesso_valido()) {
                unset($this->ecac_robo_library);
                continue;
            }

            $validado = $this->ecac_robo_library->trocar_perfil($cnpj);

            if(! $validado){
                echo "ERRO2";
                unset($this->ecac_robo_library);
                continue;
            }
            $caminho_download = $this->ecac_robo_library->baixar_declaracao_das($numero_declaracao, $ano);
            if($caminho_download != ""){
                $this->das_model->update_caminho_download_declaracao($caminho_download, $numero_declaracao, $banco);
                unset($this->ecac_robo_library);
                return $caminho_download;
            }else{
                unset($this->ecac_robo_library);
                return "ERRO";
            }
            unset($this->ecac_robo_library);
        }

    }

    public function emitir_declaracao($numero_declaracao,  $ano, $cnpj, $banco){

        $certificado = $this->certificado_model->find_certificado($cnpj, $banco);
        $folder_pdf = FCPATH . 'arquivos/pdf-das-ecac-sp/'.$banco.'/';


        if (!file_exists($folder_pdf)) {
            mkdir($folder_pdf, DIR_WRITE_MODE, true);
        }

         $params = array('certificado' => $certificado
                'caminho_da_pasta_pdfs' => $folder_pdf);

        $this->load->library('Ecac/SimplesNacional/Pgdas', $params, 'ecac_robo_library');

        if(!$this->ecac_robo_library->acesso_valido()){
            unset($this->ecac_robo_library);
            echo json_encode(array("error"=> true, "mensagem"=>"erro1"));
        }
        $caminho_download = $this->ecac_robo_library->baixar_declaracao_das($numero_declaracao, $ano);

        if($caminho_download != ""){

            // $caminho_download = str_replace("/var/www/html", "https://veri-sp.com.br",$caminho_download);

            $this->das_model->update_caminho_download_declaracao($banco,$numero_declaracao, $cnpj, $caminho_download);

            unset($this->ecac_robo_library);
            return $caminho_download;
        }else{
            unset($this->ecac_robo_library);
            return "ERRO";
        }
    }
}
