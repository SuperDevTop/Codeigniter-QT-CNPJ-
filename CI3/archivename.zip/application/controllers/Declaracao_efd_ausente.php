<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Declaracao_efd_ausente extends CI_Controller {

    public function processar(){
        //http://localhost/veri-sp-1.0/Api-Crons/Declaracao_efd_ausente/processar
        include ( 'PdfToText/PdfToText.phpclass' ) ;

        $banco = $this->uri->segment(3);
        $this->load->model('declaracao_ausente_model');
        $this->load->model('declaracao_ausente_efd_model');

        $registros = $this->declaracao_ausente_model->busca_situacao_fiscal($banco);
        $pdf    =  new PdfToText() ;

        foreach ($registros as $e) {

            if(!empty($e->caminho_download)){
                try{

                    $pdf->Load( $e->caminho_download ) ;

                    $cnpj = $e->cnpj;

                    $texto = $pdf -> Text ;

                    $p = explode("Pendência - ", $texto); 

                    $declaracao_regular = true;
                    foreach ($p as $index) {

                        //verifica se existe ausencia de declaração
                        $pos_declaracao = strpos($index, "Ausência de Declaração");
                        if ($pos_declaracao !== false) {

                            $this->extrair_declaracao($index, $cnpj, $banco);
                            $declaracao_regular = false;
                            break;
                        }
                    }

                    // break;

                    if($declaracao_regular){
                        $existe_registro = $this->declaracao_ausente_efd_model->verifica_se_existe($banco, $cnpj);

                        if($existe_registro->qtd > 0){
                            $this->declaracao_ausente_efd_model->atualiza_ausencia_efd_regular($banco, $cnpj);
                        }else{
                            $this->declaracao_ausente_efd_model->insere_ausencia_efd_regular($banco, $cnpj); 
                        }
                    }

                }catch(Exception $x){
                    echo "ERRO AO PROCESSAR CNPJ - ".$e->cnpj;
                    echo '<br>';
                    continue;
                }
                
            }
            
        }
        
    }


    public function extrair_declaracao($string, $cnpj, $banco){

        $area_total = $string;
        //Verifica se existe parcelamento no pdf
        $area_principal = explode("Parcelamento", $string);
        if(count($area_principal) > 1){
            $area_total = $area_principal[0];
        }

        $posicao_diagnostico = strpos($area_total, "__________________________ Diagnóstico");
        if ($posicao_diagnostico !== false) {

            $paginas = explode("__________________________ Diagnóstico", $area_total); 

            $this->extrai_efd($paginas[0], $cnpj, $banco);
        }else{
            $this->extrai_efd($area_total, $cnpj, $banco);
        }   

    }

    public function extrai_efd($string, $cnpj, $banco){

        // echo $string;
        // die();

        $area_reduzida_efd = explode("EFD-CONTRIB(Período de Apuração)", $string); 

        $count_efd = count($area_reduzida_efd);
        if ($count_efd > 1) {

            // echo "<br>";
            // echo "Possui".$cnpj;
            //SUBSTITUI TODAS AS STRINGS DE DECLARAÇAO PARA PODER DAR UM EXPLODE
            
            $texto_a_utilizar = $area_reduzida_efd[1];
            // $texto_a_utilizar = str_replace("EFD-CONTRIB", "break;", $area_reduzida_efd[1]);/////2
            $texto_a_utilizar = str_replace("GFIP", "break;", $texto_a_utilizar);
            $texto_a_utilizar = str_replace("DIRF", "break;", $texto_a_utilizar);//2
            $texto_a_utilizar = str_replace("DASN", "break;", $texto_a_utilizar);//1
            $texto_a_utilizar = str_replace("DCTF", "break;", $texto_a_utilizar);//3
            $texto_a_utilizar = str_replace("ECF", "break;",  $texto_a_utilizar);////1
            $texto_a_utilizar = str_replace("DEFIS", "break;", $texto_a_utilizar);//1
            $texto_a_utilizar = str_replace("PGDAS", "break;", $texto_a_utilizar);//3

            $texto_a_utilizar_final = explode("break;", $texto_a_utilizar);

            $existe_registro = $this->declaracao_ausente_efd_model->verifica_se_existe($banco, $cnpj);

            if($existe_registro->qtd > 0){
                $this->declaracao_ausente_efd_model->atualiza_ausencia_efd_irregular($banco, $cnpj);
            }else{
                $this->declaracao_ausente_efd_model->insere_ausencia_efd_irregular($banco, $cnpj); 
            }

            $t = nl2br($texto_a_utilizar_final[0]);

            $paginas = explode("Página", $t);
            $count_paginas = count($paginas);
            if($count_paginas > 1){
                $t = $paginas[0];
            }


            $debito = explode("Débito", $t);
            $count_debito = count($debito);
            if($count_debito > 1){
                $t = $debito[0];
            }
            
            // echo $t;
            // die();
            $efds = explode("<br />", $t);
            $this->declaracao_ausente_efd_model->limpa_ausencia_efd_detalhe($banco, $cnpj);

            foreach ($efds as $g) {
                $periodo = trim($g);
                if(!empty($periodo)){
                  $this->declaracao_ausente_efd_model->insere_ausencia_efd_detalhe($banco, $cnpj, "EFD-CONTRIB", "(Período de Apuração)", $periodo);  
                }
                
            }
        }else{

            $existe_registro = $this->declaracao_ausente_efd_model->verifica_se_existe($banco, $cnpj);

            if($existe_registro->qtd > 0){
                $this->declaracao_ausente_efd_model->atualiza_ausencia_efd_regular($banco, $cnpj);
            }else{
                $this->declaracao_ausente_efd_model->insere_ausencia_efd_regular($banco, $cnpj); 
            }
            // echo "<br>";
            // echo $cnpj." não possui";
        }
        
    }

}
