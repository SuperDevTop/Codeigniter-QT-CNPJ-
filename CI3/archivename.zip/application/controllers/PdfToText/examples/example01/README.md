The contents of *sample.pdf* come from here :

	[http://bdemauge.free.fr/ceintures/b19bpoemes.pdf](http://bdemauge.free.fr/ceintures/b19bpoemes.pdf "http://bdemauge.free.fr/ceintures/b19bpoemes.pdf")
