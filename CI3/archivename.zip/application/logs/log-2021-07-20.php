<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-20 13:09:20 --> Config Class Initialized
INFO - 2021-07-20 13:09:20 --> Hooks Class Initialized
DEBUG - 2021-07-20 13:09:20 --> UTF-8 Support Enabled
INFO - 2021-07-20 13:09:20 --> Utf8 Class Initialized
INFO - 2021-07-20 13:09:20 --> URI Class Initialized
INFO - 2021-07-20 13:09:20 --> Router Class Initialized
INFO - 2021-07-20 13:09:20 --> Output Class Initialized
INFO - 2021-07-20 13:09:20 --> Security Class Initialized
DEBUG - 2021-07-20 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-20 13:09:20 --> Input Class Initialized
INFO - 2021-07-20 13:09:20 --> Language Class Initialized
INFO - 2021-07-20 13:09:20 --> Loader Class Initialized
INFO - 2021-07-20 13:09:20 --> Helper loaded: url_helper
INFO - 2021-07-20 13:09:20 --> Helper loaded: form_helper
INFO - 2021-07-20 13:09:20 --> Helper loaded: array_helper
INFO - 2021-07-20 13:09:20 --> Helper loaded: date_helper
INFO - 2021-07-20 13:09:20 --> Helper loaded: html_helper
INFO - 2021-07-20 13:09:20 --> Database Driver Class Initialized
INFO - 2021-07-20 13:09:20 --> Controller Class Initialized
DEBUG - 2021-07-20 13:09:20 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-20 13:09:20 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-20 13:09:20 --> Model "Procuracao_model" initialized
INFO - 2021-07-20 08:09:24 --> Ecac Robo Class Initialized
INFO - 2021-07-20 08:09:35 --> Final output sent to browser
DEBUG - 2021-07-20 08:09:35 --> Total execution time: 15.0433
