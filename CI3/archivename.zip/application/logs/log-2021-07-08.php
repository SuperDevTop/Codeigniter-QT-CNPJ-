<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-08 00:22:31 --> Config Class Initialized
INFO - 2021-07-08 00:22:31 --> Hooks Class Initialized
DEBUG - 2021-07-08 00:22:31 --> UTF-8 Support Enabled
INFO - 2021-07-08 00:22:31 --> Utf8 Class Initialized
INFO - 2021-07-08 00:22:31 --> URI Class Initialized
INFO - 2021-07-08 00:22:31 --> Router Class Initialized
INFO - 2021-07-08 00:22:31 --> Output Class Initialized
INFO - 2021-07-08 00:22:31 --> Security Class Initialized
DEBUG - 2021-07-08 00:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 00:22:31 --> Input Class Initialized
INFO - 2021-07-08 00:22:31 --> Language Class Initialized
INFO - 2021-07-08 00:22:31 --> Loader Class Initialized
INFO - 2021-07-08 00:22:31 --> Helper loaded: url_helper
INFO - 2021-07-08 00:22:31 --> Helper loaded: form_helper
INFO - 2021-07-08 00:22:31 --> Helper loaded: array_helper
INFO - 2021-07-08 00:22:31 --> Helper loaded: date_helper
INFO - 2021-07-08 00:22:31 --> Helper loaded: html_helper
INFO - 2021-07-08 00:22:31 --> Database Driver Class Initialized
INFO - 2021-07-08 00:22:31 --> Controller Class Initialized
DEBUG - 2021-07-08 00:22:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 00:22:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-08 00:22:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-08 00:40:30 --> Config Class Initialized
INFO - 2021-07-08 00:40:30 --> Hooks Class Initialized
DEBUG - 2021-07-08 00:40:30 --> UTF-8 Support Enabled
INFO - 2021-07-08 00:40:30 --> Utf8 Class Initialized
INFO - 2021-07-08 00:40:30 --> URI Class Initialized
INFO - 2021-07-08 00:40:30 --> Router Class Initialized
INFO - 2021-07-08 00:40:30 --> Output Class Initialized
INFO - 2021-07-08 00:40:30 --> Security Class Initialized
DEBUG - 2021-07-08 00:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 00:40:30 --> Input Class Initialized
INFO - 2021-07-08 00:40:30 --> Language Class Initialized
INFO - 2021-07-08 00:40:30 --> Loader Class Initialized
INFO - 2021-07-08 00:40:30 --> Helper loaded: url_helper
INFO - 2021-07-08 00:40:30 --> Helper loaded: form_helper
INFO - 2021-07-08 00:40:30 --> Helper loaded: array_helper
INFO - 2021-07-08 00:40:30 --> Helper loaded: date_helper
INFO - 2021-07-08 00:40:30 --> Helper loaded: html_helper
INFO - 2021-07-08 00:40:30 --> Database Driver Class Initialized
INFO - 2021-07-08 00:40:30 --> Controller Class Initialized
DEBUG - 2021-07-08 00:40:30 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 00:40:30 --> Model "Certificado_cron_model" initialized
INFO - 2021-07-08 00:47:08 --> Config Class Initialized
INFO - 2021-07-08 00:47:08 --> Hooks Class Initialized
DEBUG - 2021-07-08 00:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-08 00:47:08 --> Utf8 Class Initialized
INFO - 2021-07-08 00:47:08 --> URI Class Initialized
INFO - 2021-07-08 00:47:08 --> Router Class Initialized
INFO - 2021-07-08 00:47:08 --> Output Class Initialized
INFO - 2021-07-08 00:47:08 --> Security Class Initialized
DEBUG - 2021-07-08 00:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 00:47:08 --> Input Class Initialized
INFO - 2021-07-08 00:47:08 --> Language Class Initialized
INFO - 2021-07-08 00:47:08 --> Loader Class Initialized
INFO - 2021-07-08 00:47:08 --> Helper loaded: url_helper
INFO - 2021-07-08 00:47:08 --> Helper loaded: form_helper
INFO - 2021-07-08 00:47:08 --> Helper loaded: array_helper
INFO - 2021-07-08 00:47:08 --> Helper loaded: date_helper
INFO - 2021-07-08 00:47:08 --> Helper loaded: html_helper
INFO - 2021-07-08 00:47:08 --> Database Driver Class Initialized
INFO - 2021-07-08 00:47:08 --> Controller Class Initialized
DEBUG - 2021-07-08 00:47:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 00:47:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-08 00:47:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-08 01:01:26 --> Config Class Initialized
INFO - 2021-07-08 01:01:26 --> Hooks Class Initialized
DEBUG - 2021-07-08 01:01:26 --> UTF-8 Support Enabled
INFO - 2021-07-08 01:01:26 --> Utf8 Class Initialized
INFO - 2021-07-08 01:01:26 --> URI Class Initialized
INFO - 2021-07-08 01:01:26 --> Router Class Initialized
INFO - 2021-07-08 01:01:26 --> Output Class Initialized
INFO - 2021-07-08 01:01:26 --> Security Class Initialized
DEBUG - 2021-07-08 01:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 01:01:26 --> Input Class Initialized
INFO - 2021-07-08 01:01:26 --> Language Class Initialized
INFO - 2021-07-08 01:01:26 --> Loader Class Initialized
INFO - 2021-07-08 01:01:26 --> Helper loaded: url_helper
INFO - 2021-07-08 01:01:26 --> Helper loaded: form_helper
INFO - 2021-07-08 01:01:26 --> Helper loaded: array_helper
INFO - 2021-07-08 01:01:26 --> Helper loaded: date_helper
INFO - 2021-07-08 01:01:26 --> Helper loaded: html_helper
INFO - 2021-07-08 01:01:26 --> Database Driver Class Initialized
INFO - 2021-07-08 01:01:26 --> Controller Class Initialized
DEBUG - 2021-07-08 01:01:26 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 01:01:26 --> Model "Certificado_model" initialized
INFO - 2021-07-08 01:01:26 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-08 01:31:32 --> Config Class Initialized
INFO - 2021-07-08 01:31:32 --> Hooks Class Initialized
DEBUG - 2021-07-08 01:31:32 --> UTF-8 Support Enabled
INFO - 2021-07-08 01:31:32 --> Utf8 Class Initialized
INFO - 2021-07-08 01:31:32 --> URI Class Initialized
INFO - 2021-07-08 01:31:32 --> Router Class Initialized
INFO - 2021-07-08 01:31:32 --> Output Class Initialized
INFO - 2021-07-08 01:31:32 --> Security Class Initialized
DEBUG - 2021-07-08 01:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 01:31:32 --> Input Class Initialized
INFO - 2021-07-08 01:31:32 --> Language Class Initialized
INFO - 2021-07-08 01:31:32 --> Loader Class Initialized
INFO - 2021-07-08 01:31:32 --> Helper loaded: url_helper
INFO - 2021-07-08 01:31:32 --> Helper loaded: form_helper
INFO - 2021-07-08 01:31:32 --> Helper loaded: array_helper
INFO - 2021-07-08 01:31:32 --> Helper loaded: date_helper
INFO - 2021-07-08 01:31:32 --> Helper loaded: html_helper
INFO - 2021-07-08 01:31:32 --> Database Driver Class Initialized
INFO - 2021-07-08 01:31:33 --> Controller Class Initialized
DEBUG - 2021-07-08 01:31:33 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 01:31:33 --> Model "Certificado_model" initialized
INFO - 2021-07-08 01:31:33 --> Model "Eprocessos_ativos_model" initialized
INFO - 2021-07-08 01:31:33 --> Model "Eprocessos_inativos_model" initialized
INFO - 2021-07-08 01:31:33 --> Model "Eprocessos_ativos_historico_model" initialized
INFO - 2021-07-08 01:31:33 --> Model "Eprocessos_inativos_historico_model" initialized
INFO - 2021-07-08 02:19:55 --> Config Class Initialized
INFO - 2021-07-08 02:19:55 --> Hooks Class Initialized
DEBUG - 2021-07-08 02:19:55 --> UTF-8 Support Enabled
INFO - 2021-07-08 02:19:55 --> Utf8 Class Initialized
INFO - 2021-07-08 02:19:55 --> URI Class Initialized
INFO - 2021-07-08 02:19:55 --> Router Class Initialized
INFO - 2021-07-08 02:19:55 --> Output Class Initialized
INFO - 2021-07-08 02:19:55 --> Security Class Initialized
DEBUG - 2021-07-08 02:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-08 02:19:55 --> Input Class Initialized
INFO - 2021-07-08 02:19:55 --> Language Class Initialized
INFO - 2021-07-08 02:19:55 --> Loader Class Initialized
INFO - 2021-07-08 02:19:55 --> Helper loaded: url_helper
INFO - 2021-07-08 02:19:55 --> Helper loaded: form_helper
INFO - 2021-07-08 02:19:55 --> Helper loaded: array_helper
INFO - 2021-07-08 02:19:55 --> Helper loaded: date_helper
INFO - 2021-07-08 02:19:55 --> Helper loaded: html_helper
INFO - 2021-07-08 02:19:55 --> Database Driver Class Initialized
INFO - 2021-07-08 02:19:55 --> Controller Class Initialized
DEBUG - 2021-07-08 02:19:55 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-08 02:19:55 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-08 02:19:55 --> Model "Contadorprocuracao_model" initialized
