<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-06 13:53:30 --> Config Class Initialized
INFO - 2021-07-06 13:53:30 --> Hooks Class Initialized
DEBUG - 2021-07-06 13:53:30 --> UTF-8 Support Enabled
INFO - 2021-07-06 13:53:30 --> Utf8 Class Initialized
INFO - 2021-07-06 13:53:30 --> URI Class Initialized
INFO - 2021-07-06 13:53:30 --> Router Class Initialized
INFO - 2021-07-06 13:53:30 --> Output Class Initialized
INFO - 2021-07-06 13:53:30 --> Security Class Initialized
DEBUG - 2021-07-06 13:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 13:53:30 --> Input Class Initialized
INFO - 2021-07-06 13:53:30 --> Language Class Initialized
INFO - 2021-07-06 13:53:30 --> Loader Class Initialized
INFO - 2021-07-06 13:53:30 --> Helper loaded: url_helper
INFO - 2021-07-06 13:53:30 --> Helper loaded: form_helper
INFO - 2021-07-06 13:53:30 --> Helper loaded: array_helper
INFO - 2021-07-06 13:53:30 --> Helper loaded: date_helper
INFO - 2021-07-06 13:53:30 --> Helper loaded: html_helper
INFO - 2021-07-06 13:53:30 --> Database Driver Class Initialized
INFO - 2021-07-06 13:53:31 --> Controller Class Initialized
DEBUG - 2021-07-06 13:53:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-06 13:53:31 --> Model "Certificado_cron_model" initialized
INFO - 2021-07-06 08:53:34 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:53:40 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-06 08:53:43 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:53:54 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:04 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:15 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:23 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:31 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:40 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:49 --> Ecac Robo Class Initialized
ERROR - 2021-07-06 08:54:54 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/mdantas/03628496500.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-06 08:54:54 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:54:57 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:06 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:15 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:24 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:32 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:41 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:50 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:55:58 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:07 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:16 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:24 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:33 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:42 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:51 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:56:56 --> Final output sent to browser
DEBUG - 2021-07-06 08:56:56 --> Total execution time: 205.9495
INFO - 2021-07-06 13:58:33 --> Config Class Initialized
INFO - 2021-07-06 13:58:33 --> Hooks Class Initialized
DEBUG - 2021-07-06 13:58:33 --> UTF-8 Support Enabled
INFO - 2021-07-06 13:58:33 --> Utf8 Class Initialized
INFO - 2021-07-06 13:58:33 --> URI Class Initialized
INFO - 2021-07-06 13:58:33 --> Router Class Initialized
INFO - 2021-07-06 13:58:33 --> Output Class Initialized
INFO - 2021-07-06 13:58:33 --> Security Class Initialized
DEBUG - 2021-07-06 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 13:58:33 --> Input Class Initialized
INFO - 2021-07-06 13:58:33 --> Language Class Initialized
INFO - 2021-07-06 13:58:33 --> Loader Class Initialized
INFO - 2021-07-06 13:58:33 --> Helper loaded: url_helper
INFO - 2021-07-06 13:58:33 --> Helper loaded: form_helper
INFO - 2021-07-06 13:58:33 --> Helper loaded: array_helper
INFO - 2021-07-06 13:58:33 --> Helper loaded: date_helper
INFO - 2021-07-06 13:58:33 --> Helper loaded: html_helper
INFO - 2021-07-06 13:58:33 --> Database Driver Class Initialized
INFO - 2021-07-06 13:58:33 --> Controller Class Initialized
DEBUG - 2021-07-06 13:58:33 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-06 13:58:33 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-06 13:58:33 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-06 08:58:37 --> Ecac Robo Class Initialized
INFO - 2021-07-06 08:58:43 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-06 08:58:43 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-06 08:59:20 --> Ecac Robo Class Initialized
INFO - 2021-07-06 09:02:00 --> Final output sent to browser
DEBUG - 2021-07-06 09:02:00 --> Total execution time: 207.0860
INFO - 2021-07-06 15:14:58 --> Config Class Initialized
INFO - 2021-07-06 15:14:58 --> Hooks Class Initialized
DEBUG - 2021-07-06 15:14:58 --> UTF-8 Support Enabled
INFO - 2021-07-06 15:14:58 --> Utf8 Class Initialized
INFO - 2021-07-06 15:14:58 --> URI Class Initialized
INFO - 2021-07-06 15:14:58 --> Router Class Initialized
INFO - 2021-07-06 15:14:58 --> Output Class Initialized
INFO - 2021-07-06 15:14:58 --> Security Class Initialized
DEBUG - 2021-07-06 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 15:14:58 --> Input Class Initialized
INFO - 2021-07-06 15:14:58 --> Language Class Initialized
INFO - 2021-07-06 15:14:58 --> Loader Class Initialized
INFO - 2021-07-06 15:14:58 --> Helper loaded: url_helper
INFO - 2021-07-06 15:14:58 --> Helper loaded: form_helper
INFO - 2021-07-06 15:14:58 --> Helper loaded: array_helper
INFO - 2021-07-06 15:14:58 --> Helper loaded: date_helper
INFO - 2021-07-06 15:14:58 --> Helper loaded: html_helper
INFO - 2021-07-06 15:14:58 --> Database Driver Class Initialized
INFO - 2021-07-06 15:14:58 --> Controller Class Initialized
DEBUG - 2021-07-06 15:14:58 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-06 15:14:58 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-06 15:14:58 --> Model "Procuracao_model" initialized
INFO - 2021-07-06 10:15:03 --> Ecac Robo Class Initialized
INFO - 2021-07-06 10:15:16 --> Final output sent to browser
DEBUG - 2021-07-06 10:15:16 --> Total execution time: 18.0371
INFO - 2021-07-06 15:44:58 --> Config Class Initialized
INFO - 2021-07-06 15:44:58 --> Hooks Class Initialized
DEBUG - 2021-07-06 15:44:58 --> UTF-8 Support Enabled
INFO - 2021-07-06 15:44:58 --> Utf8 Class Initialized
INFO - 2021-07-06 15:44:58 --> URI Class Initialized
INFO - 2021-07-06 15:44:58 --> Router Class Initialized
INFO - 2021-07-06 15:44:58 --> Output Class Initialized
INFO - 2021-07-06 15:44:58 --> Security Class Initialized
DEBUG - 2021-07-06 15:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 15:44:58 --> Input Class Initialized
INFO - 2021-07-06 15:44:58 --> Language Class Initialized
INFO - 2021-07-06 15:44:58 --> Loader Class Initialized
INFO - 2021-07-06 15:44:58 --> Helper loaded: url_helper
INFO - 2021-07-06 15:44:58 --> Helper loaded: form_helper
INFO - 2021-07-06 15:44:58 --> Helper loaded: array_helper
INFO - 2021-07-06 15:44:58 --> Helper loaded: date_helper
INFO - 2021-07-06 15:44:58 --> Helper loaded: html_helper
INFO - 2021-07-06 15:44:58 --> Database Driver Class Initialized
INFO - 2021-07-06 15:44:58 --> Controller Class Initialized
DEBUG - 2021-07-06 15:44:58 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-06 15:44:58 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-06 15:44:58 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-06 10:45:02 --> Ecac Robo Class Initialized
INFO - 2021-07-06 10:45:10 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-06 10:45:10 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-06 11:06:06 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-06 11:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:44) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-06 16:58:25 --> Config Class Initialized
INFO - 2021-07-06 16:58:25 --> Hooks Class Initialized
DEBUG - 2021-07-06 16:58:25 --> UTF-8 Support Enabled
INFO - 2021-07-06 16:58:25 --> Utf8 Class Initialized
INFO - 2021-07-06 16:58:25 --> URI Class Initialized
INFO - 2021-07-06 16:58:25 --> Router Class Initialized
INFO - 2021-07-06 16:58:25 --> Output Class Initialized
INFO - 2021-07-06 16:58:25 --> Security Class Initialized
DEBUG - 2021-07-06 16:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-06 16:58:25 --> Input Class Initialized
INFO - 2021-07-06 16:58:25 --> Language Class Initialized
INFO - 2021-07-06 16:58:25 --> Loader Class Initialized
INFO - 2021-07-06 16:58:25 --> Helper loaded: url_helper
INFO - 2021-07-06 16:58:25 --> Helper loaded: form_helper
INFO - 2021-07-06 16:58:25 --> Helper loaded: array_helper
INFO - 2021-07-06 16:58:25 --> Helper loaded: date_helper
INFO - 2021-07-06 16:58:25 --> Helper loaded: html_helper
INFO - 2021-07-06 16:58:25 --> Database Driver Class Initialized
INFO - 2021-07-06 16:58:25 --> Controller Class Initialized
DEBUG - 2021-07-06 16:58:25 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-06 16:58:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-06 16:58:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-06 11:58:29 --> Ecac Robo Class Initialized
INFO - 2021-07-06 11:58:33 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-06 11:58:33 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-06 12:20:32 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-06 12:20:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:75) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-06 19:34:34 --> Ecac Robo Class Initialized
INFO - 2021-07-06 19:34:42 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-06 19:58:39 --> Final output sent to browser
DEBUG - 2021-07-06 19:58:39 --> Total execution time: 1,447.8661
INFO - 2021-07-06 20:00:30 --> Ecac Robo Class Initialized
INFO - 2021-07-06 20:19:08 --> Final output sent to browser
DEBUG - 2021-07-06 20:19:08 --> Total execution time: 1,120.9085
ERROR - 2021-07-06 20:25:52 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-06 20:25:52 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-06 20:25:52 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
ERROR - 2021-07-06 20:25:52 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-06 20:25:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-06 20:38:21 --> Ecac Robo Class Initialized
INFO - 2021-07-06 20:38:26 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-06 20:38:26 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-06 20:47:00 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-06 20:47:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:75) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-06 20:50:58 --> Ecac Robo Class Initialized
INFO - 2021-07-06 20:51:07 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-06 21:39:50 --> Ecac Robo Class Initialized
INFO - 2021-07-06 21:39:50 --> Final output sent to browser
DEBUG - 2021-07-06 21:39:50 --> Total execution time: 2,935.2922
INFO - 2021-07-06 21:49:35 --> Ecac Robo Class Initialized
INFO - 2021-07-06 21:49:45 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-06 22:19:02 --> Ecac Robo Class Initialized
INFO - 2021-07-06 22:19:12 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-06 22:19:12 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-06 22:31:16 --> Final output sent to browser
DEBUG - 2021-07-06 22:31:16 --> Total execution time: 738.2643
INFO - 2021-07-06 22:38:16 --> Ecac Robo Class Initialized
INFO - 2021-07-06 23:14:46 --> Ecac Robo Class Initialized
INFO - 2021-07-06 23:14:52 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-06 23:14:52 --> Final output sent to browser
DEBUG - 2021-07-06 23:14:52 --> Total execution time: 9.2593
