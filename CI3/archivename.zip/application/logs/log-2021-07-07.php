<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-07 00:34:31 --> Config Class Initialized
INFO - 2021-07-07 00:34:31 --> Hooks Class Initialized
DEBUG - 2021-07-07 00:34:31 --> UTF-8 Support Enabled
INFO - 2021-07-07 00:34:31 --> Utf8 Class Initialized
INFO - 2021-07-07 00:34:31 --> URI Class Initialized
INFO - 2021-07-07 00:34:31 --> Router Class Initialized
INFO - 2021-07-07 00:34:31 --> Output Class Initialized
INFO - 2021-07-07 00:34:31 --> Security Class Initialized
DEBUG - 2021-07-07 00:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 00:34:31 --> Input Class Initialized
INFO - 2021-07-07 00:34:31 --> Language Class Initialized
INFO - 2021-07-07 00:34:31 --> Loader Class Initialized
INFO - 2021-07-07 00:34:31 --> Helper loaded: url_helper
INFO - 2021-07-07 00:34:31 --> Helper loaded: form_helper
INFO - 2021-07-07 00:34:31 --> Helper loaded: array_helper
INFO - 2021-07-07 00:34:31 --> Helper loaded: date_helper
INFO - 2021-07-07 00:34:31 --> Helper loaded: html_helper
INFO - 2021-07-07 00:34:31 --> Database Driver Class Initialized
INFO - 2021-07-07 00:34:31 --> Controller Class Initialized
DEBUG - 2021-07-07 00:34:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 00:34:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 00:34:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 01:00:27 --> Config Class Initialized
INFO - 2021-07-07 01:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-07 01:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-07 01:00:27 --> Utf8 Class Initialized
INFO - 2021-07-07 01:00:27 --> URI Class Initialized
INFO - 2021-07-07 01:00:27 --> Router Class Initialized
INFO - 2021-07-07 01:00:27 --> Output Class Initialized
INFO - 2021-07-07 01:00:27 --> Security Class Initialized
DEBUG - 2021-07-07 01:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 01:00:27 --> Input Class Initialized
INFO - 2021-07-07 01:00:27 --> Language Class Initialized
INFO - 2021-07-07 01:00:27 --> Loader Class Initialized
INFO - 2021-07-07 01:00:27 --> Helper loaded: url_helper
INFO - 2021-07-07 01:00:27 --> Helper loaded: form_helper
INFO - 2021-07-07 01:00:27 --> Helper loaded: array_helper
INFO - 2021-07-07 01:00:27 --> Helper loaded: date_helper
INFO - 2021-07-07 01:00:27 --> Helper loaded: html_helper
INFO - 2021-07-07 01:00:27 --> Database Driver Class Initialized
INFO - 2021-07-07 01:00:27 --> Controller Class Initialized
INFO - 2021-07-07 01:00:27 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 01:00:27 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 01:00:27 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-07 01:25:52 --> Config Class Initialized
INFO - 2021-07-07 01:25:52 --> Hooks Class Initialized
DEBUG - 2021-07-07 01:25:52 --> UTF-8 Support Enabled
INFO - 2021-07-07 01:25:52 --> Utf8 Class Initialized
INFO - 2021-07-07 01:25:52 --> URI Class Initialized
INFO - 2021-07-07 01:25:52 --> Router Class Initialized
INFO - 2021-07-07 01:25:52 --> Output Class Initialized
INFO - 2021-07-07 01:25:52 --> Security Class Initialized
DEBUG - 2021-07-07 01:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 01:25:52 --> Input Class Initialized
INFO - 2021-07-07 01:25:52 --> Language Class Initialized
INFO - 2021-07-07 01:25:52 --> Loader Class Initialized
INFO - 2021-07-07 01:25:52 --> Helper loaded: url_helper
INFO - 2021-07-07 01:25:52 --> Helper loaded: form_helper
INFO - 2021-07-07 01:25:52 --> Helper loaded: array_helper
INFO - 2021-07-07 01:25:52 --> Helper loaded: date_helper
INFO - 2021-07-07 01:25:52 --> Helper loaded: html_helper
INFO - 2021-07-07 01:25:52 --> Database Driver Class Initialized
INFO - 2021-07-07 01:25:52 --> Controller Class Initialized
DEBUG - 2021-07-07 01:25:52 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 01:25:52 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 01:25:52 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 01:38:18 --> Config Class Initialized
INFO - 2021-07-07 01:38:18 --> Hooks Class Initialized
DEBUG - 2021-07-07 01:38:18 --> UTF-8 Support Enabled
INFO - 2021-07-07 01:38:18 --> Utf8 Class Initialized
INFO - 2021-07-07 01:38:18 --> URI Class Initialized
INFO - 2021-07-07 01:38:18 --> Router Class Initialized
INFO - 2021-07-07 01:38:18 --> Output Class Initialized
INFO - 2021-07-07 01:38:18 --> Security Class Initialized
DEBUG - 2021-07-07 01:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 01:38:18 --> Input Class Initialized
INFO - 2021-07-07 01:38:18 --> Language Class Initialized
INFO - 2021-07-07 01:38:18 --> Loader Class Initialized
INFO - 2021-07-07 01:38:18 --> Helper loaded: url_helper
INFO - 2021-07-07 01:38:18 --> Helper loaded: form_helper
INFO - 2021-07-07 01:38:18 --> Helper loaded: array_helper
INFO - 2021-07-07 01:38:18 --> Helper loaded: date_helper
INFO - 2021-07-07 01:38:18 --> Helper loaded: html_helper
INFO - 2021-07-07 01:38:18 --> Database Driver Class Initialized
INFO - 2021-07-07 01:38:18 --> Controller Class Initialized
DEBUG - 2021-07-07 01:38:18 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 01:38:18 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 01:38:18 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 01:50:55 --> Config Class Initialized
INFO - 2021-07-07 01:50:55 --> Hooks Class Initialized
DEBUG - 2021-07-07 01:50:55 --> UTF-8 Support Enabled
INFO - 2021-07-07 01:50:55 --> Utf8 Class Initialized
INFO - 2021-07-07 01:50:55 --> URI Class Initialized
INFO - 2021-07-07 01:50:55 --> Router Class Initialized
INFO - 2021-07-07 01:50:55 --> Output Class Initialized
INFO - 2021-07-07 01:50:55 --> Security Class Initialized
DEBUG - 2021-07-07 01:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 01:50:55 --> Input Class Initialized
INFO - 2021-07-07 01:50:55 --> Language Class Initialized
INFO - 2021-07-07 01:50:55 --> Loader Class Initialized
INFO - 2021-07-07 01:50:55 --> Helper loaded: url_helper
INFO - 2021-07-07 01:50:55 --> Helper loaded: form_helper
INFO - 2021-07-07 01:50:55 --> Helper loaded: array_helper
INFO - 2021-07-07 01:50:55 --> Helper loaded: date_helper
INFO - 2021-07-07 01:50:55 --> Helper loaded: html_helper
INFO - 2021-07-07 01:50:55 --> Database Driver Class Initialized
INFO - 2021-07-07 01:50:55 --> Controller Class Initialized
DEBUG - 2021-07-07 01:50:55 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 01:50:55 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 01:50:55 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 02:49:31 --> Config Class Initialized
INFO - 2021-07-07 02:49:31 --> Hooks Class Initialized
DEBUG - 2021-07-07 02:49:31 --> UTF-8 Support Enabled
INFO - 2021-07-07 02:49:31 --> Utf8 Class Initialized
INFO - 2021-07-07 02:49:31 --> URI Class Initialized
INFO - 2021-07-07 02:49:31 --> Router Class Initialized
INFO - 2021-07-07 02:49:31 --> Output Class Initialized
INFO - 2021-07-07 02:49:31 --> Security Class Initialized
DEBUG - 2021-07-07 02:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 02:49:31 --> Input Class Initialized
INFO - 2021-07-07 02:49:31 --> Language Class Initialized
INFO - 2021-07-07 02:49:31 --> Loader Class Initialized
INFO - 2021-07-07 02:49:31 --> Helper loaded: url_helper
INFO - 2021-07-07 02:49:31 --> Helper loaded: form_helper
INFO - 2021-07-07 02:49:31 --> Helper loaded: array_helper
INFO - 2021-07-07 02:49:31 --> Helper loaded: date_helper
INFO - 2021-07-07 02:49:31 --> Helper loaded: html_helper
INFO - 2021-07-07 02:49:31 --> Database Driver Class Initialized
INFO - 2021-07-07 02:49:31 --> Controller Class Initialized
DEBUG - 2021-07-07 02:49:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 02:49:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 02:49:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 03:18:58 --> Config Class Initialized
INFO - 2021-07-07 03:18:58 --> Hooks Class Initialized
DEBUG - 2021-07-07 03:18:58 --> UTF-8 Support Enabled
INFO - 2021-07-07 03:18:58 --> Utf8 Class Initialized
INFO - 2021-07-07 03:18:58 --> URI Class Initialized
INFO - 2021-07-07 03:18:58 --> Router Class Initialized
INFO - 2021-07-07 03:18:58 --> Output Class Initialized
INFO - 2021-07-07 03:18:58 --> Security Class Initialized
DEBUG - 2021-07-07 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 03:18:58 --> Input Class Initialized
INFO - 2021-07-07 03:18:58 --> Language Class Initialized
INFO - 2021-07-07 03:18:58 --> Loader Class Initialized
INFO - 2021-07-07 03:18:58 --> Helper loaded: url_helper
INFO - 2021-07-07 03:18:58 --> Helper loaded: form_helper
INFO - 2021-07-07 03:18:58 --> Helper loaded: array_helper
INFO - 2021-07-07 03:18:58 --> Helper loaded: date_helper
INFO - 2021-07-07 03:18:58 --> Helper loaded: html_helper
INFO - 2021-07-07 03:18:58 --> Database Driver Class Initialized
INFO - 2021-07-07 03:18:58 --> Controller Class Initialized
DEBUG - 2021-07-07 03:18:58 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 03:18:58 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 03:18:58 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 03:38:02 --> Config Class Initialized
INFO - 2021-07-07 03:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-07 03:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-07 03:38:02 --> Utf8 Class Initialized
INFO - 2021-07-07 03:38:02 --> URI Class Initialized
INFO - 2021-07-07 03:38:02 --> Router Class Initialized
INFO - 2021-07-07 03:38:02 --> Output Class Initialized
INFO - 2021-07-07 03:38:02 --> Security Class Initialized
DEBUG - 2021-07-07 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 03:38:02 --> Input Class Initialized
INFO - 2021-07-07 03:38:02 --> Language Class Initialized
INFO - 2021-07-07 03:38:02 --> Loader Class Initialized
INFO - 2021-07-07 03:38:02 --> Helper loaded: url_helper
INFO - 2021-07-07 03:38:02 --> Helper loaded: form_helper
INFO - 2021-07-07 03:38:02 --> Helper loaded: array_helper
INFO - 2021-07-07 03:38:02 --> Helper loaded: date_helper
INFO - 2021-07-07 03:38:02 --> Helper loaded: html_helper
INFO - 2021-07-07 03:38:02 --> Database Driver Class Initialized
INFO - 2021-07-07 03:38:02 --> Controller Class Initialized
INFO - 2021-07-07 03:38:02 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 03:38:02 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 03:38:02 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-07 04:14:43 --> Config Class Initialized
INFO - 2021-07-07 04:14:43 --> Hooks Class Initialized
DEBUG - 2021-07-07 04:14:43 --> UTF-8 Support Enabled
INFO - 2021-07-07 04:14:43 --> Utf8 Class Initialized
INFO - 2021-07-07 04:14:43 --> URI Class Initialized
INFO - 2021-07-07 04:14:43 --> Router Class Initialized
INFO - 2021-07-07 04:14:43 --> Output Class Initialized
INFO - 2021-07-07 04:14:43 --> Security Class Initialized
DEBUG - 2021-07-07 04:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 04:14:43 --> Input Class Initialized
INFO - 2021-07-07 04:14:43 --> Language Class Initialized
INFO - 2021-07-07 04:14:43 --> Loader Class Initialized
INFO - 2021-07-07 04:14:43 --> Helper loaded: url_helper
INFO - 2021-07-07 04:14:43 --> Helper loaded: form_helper
INFO - 2021-07-07 04:14:43 --> Helper loaded: array_helper
INFO - 2021-07-07 04:14:43 --> Helper loaded: date_helper
INFO - 2021-07-07 04:14:43 --> Helper loaded: html_helper
INFO - 2021-07-07 04:14:43 --> Database Driver Class Initialized
INFO - 2021-07-07 04:14:43 --> Controller Class Initialized
DEBUG - 2021-07-07 04:14:43 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 04:14:43 --> Model "Certificado_cron_model" initialized
INFO - 2021-07-07 10:13:03 --> Config Class Initialized
INFO - 2021-07-07 10:13:03 --> Hooks Class Initialized
DEBUG - 2021-07-07 10:13:03 --> UTF-8 Support Enabled
INFO - 2021-07-07 10:13:03 --> Utf8 Class Initialized
INFO - 2021-07-07 10:13:03 --> URI Class Initialized
INFO - 2021-07-07 10:13:03 --> Router Class Initialized
INFO - 2021-07-07 10:13:03 --> Output Class Initialized
INFO - 2021-07-07 10:13:03 --> Security Class Initialized
DEBUG - 2021-07-07 10:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 10:13:03 --> Input Class Initialized
INFO - 2021-07-07 10:13:03 --> Language Class Initialized
INFO - 2021-07-07 10:13:03 --> Loader Class Initialized
INFO - 2021-07-07 10:13:03 --> Helper loaded: url_helper
INFO - 2021-07-07 10:13:03 --> Helper loaded: form_helper
INFO - 2021-07-07 10:13:03 --> Helper loaded: array_helper
INFO - 2021-07-07 10:13:03 --> Helper loaded: date_helper
INFO - 2021-07-07 10:13:03 --> Helper loaded: html_helper
INFO - 2021-07-07 10:13:03 --> Database Driver Class Initialized
INFO - 2021-07-07 10:13:03 --> Controller Class Initialized
DEBUG - 2021-07-07 10:13:03 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 10:13:03 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 10:13:03 --> Model "Procuracao_model" initialized
INFO - 2021-07-07 05:13:07 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 05:13:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 05:13:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 05:13:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
ERROR - 2021-07-07 05:13:23 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-07 05:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Vencimento_procuracao.php:39) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-07 10:14:41 --> Config Class Initialized
INFO - 2021-07-07 10:14:41 --> Hooks Class Initialized
DEBUG - 2021-07-07 10:14:41 --> UTF-8 Support Enabled
INFO - 2021-07-07 10:14:41 --> Utf8 Class Initialized
INFO - 2021-07-07 10:14:41 --> URI Class Initialized
INFO - 2021-07-07 10:14:41 --> Router Class Initialized
INFO - 2021-07-07 10:14:41 --> Output Class Initialized
INFO - 2021-07-07 10:14:41 --> Security Class Initialized
DEBUG - 2021-07-07 10:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 10:14:41 --> Input Class Initialized
INFO - 2021-07-07 10:14:41 --> Language Class Initialized
INFO - 2021-07-07 10:14:41 --> Loader Class Initialized
INFO - 2021-07-07 10:14:41 --> Helper loaded: url_helper
INFO - 2021-07-07 10:14:41 --> Helper loaded: form_helper
INFO - 2021-07-07 10:14:41 --> Helper loaded: array_helper
INFO - 2021-07-07 10:14:41 --> Helper loaded: date_helper
INFO - 2021-07-07 10:14:41 --> Helper loaded: html_helper
INFO - 2021-07-07 10:14:41 --> Database Driver Class Initialized
INFO - 2021-07-07 10:14:41 --> Controller Class Initialized
DEBUG - 2021-07-07 10:14:41 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 10:14:41 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 10:14:41 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 05:14:44 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 05:14:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 05:14:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 05:14:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
ERROR - 2021-07-07 05:14:44 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-07 05:14:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-07 10:16:11 --> Config Class Initialized
INFO - 2021-07-07 10:16:11 --> Hooks Class Initialized
DEBUG - 2021-07-07 10:16:11 --> UTF-8 Support Enabled
INFO - 2021-07-07 10:16:11 --> Utf8 Class Initialized
INFO - 2021-07-07 10:16:11 --> URI Class Initialized
INFO - 2021-07-07 10:16:11 --> Router Class Initialized
INFO - 2021-07-07 10:16:11 --> Output Class Initialized
INFO - 2021-07-07 10:16:11 --> Security Class Initialized
DEBUG - 2021-07-07 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 10:16:11 --> Input Class Initialized
INFO - 2021-07-07 10:16:11 --> Language Class Initialized
INFO - 2021-07-07 10:16:11 --> Loader Class Initialized
INFO - 2021-07-07 10:16:11 --> Helper loaded: url_helper
INFO - 2021-07-07 10:16:11 --> Helper loaded: form_helper
INFO - 2021-07-07 10:16:11 --> Helper loaded: array_helper
INFO - 2021-07-07 10:16:11 --> Helper loaded: date_helper
INFO - 2021-07-07 10:16:11 --> Helper loaded: html_helper
INFO - 2021-07-07 10:16:11 --> Database Driver Class Initialized
INFO - 2021-07-07 10:16:12 --> Controller Class Initialized
DEBUG - 2021-07-07 10:16:12 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 10:16:12 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 10:16:12 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 05:16:15 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:16:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:16:22 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:16:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:16:32 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-07 10:26:30 --> Config Class Initialized
INFO - 2021-07-07 10:26:30 --> Hooks Class Initialized
DEBUG - 2021-07-07 10:26:30 --> UTF-8 Support Enabled
INFO - 2021-07-07 10:26:30 --> Utf8 Class Initialized
INFO - 2021-07-07 10:26:30 --> URI Class Initialized
INFO - 2021-07-07 10:26:30 --> Router Class Initialized
INFO - 2021-07-07 10:26:30 --> Output Class Initialized
INFO - 2021-07-07 10:26:30 --> Security Class Initialized
DEBUG - 2021-07-07 10:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 10:26:30 --> Input Class Initialized
INFO - 2021-07-07 10:26:30 --> Language Class Initialized
INFO - 2021-07-07 10:26:30 --> Loader Class Initialized
INFO - 2021-07-07 10:26:30 --> Helper loaded: url_helper
INFO - 2021-07-07 10:26:30 --> Helper loaded: form_helper
INFO - 2021-07-07 10:26:30 --> Helper loaded: array_helper
INFO - 2021-07-07 10:26:30 --> Helper loaded: date_helper
INFO - 2021-07-07 10:26:30 --> Helper loaded: html_helper
INFO - 2021-07-07 10:26:30 --> Database Driver Class Initialized
INFO - 2021-07-07 10:26:30 --> Controller Class Initialized
DEBUG - 2021-07-07 10:26:30 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 10:26:30 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 10:26:30 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 05:26:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:26:36 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:26:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:26:42 --> Ecac Robo Class Initialized
INFO - 2021-07-07 05:26:46 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 05:26:46 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-07 06:11:16 --> Severity: Warning --> mysqli::query(): MySQL server has gone away C:\xampp\htdocs\SistemaCronsCertificado\sp\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-07-07 06:11:16 --> Severity: Warning --> mysqli::query(): Error reading result set's header C:\xampp\htdocs\SistemaCronsCertificado\sp\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-07-07 06:11:16 --> Query error: MySQL server has gone away - Invalid query: INSERT INTO `mtzcontabilidade`.`dtb_empresas_sem_procuracao` (`cnpj`) VALUES ('09040930000143')
INFO - 2021-07-07 06:11:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-07-07 06:11:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Situacao_fiscal_ecac_procuracao.php:101) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-07 07:17:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 07:17:39 --> Final output sent to browser
DEBUG - 2021-07-07 07:17:39 --> Total execution time: 6,668.9114
INFO - 2021-07-07 16:45:11 --> Config Class Initialized
INFO - 2021-07-07 16:45:11 --> Hooks Class Initialized
DEBUG - 2021-07-07 16:45:11 --> UTF-8 Support Enabled
INFO - 2021-07-07 16:45:11 --> Utf8 Class Initialized
INFO - 2021-07-07 16:45:11 --> URI Class Initialized
INFO - 2021-07-07 16:45:11 --> Router Class Initialized
INFO - 2021-07-07 16:45:11 --> Output Class Initialized
INFO - 2021-07-07 16:45:11 --> Security Class Initialized
DEBUG - 2021-07-07 16:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 16:45:11 --> Input Class Initialized
INFO - 2021-07-07 16:45:11 --> Language Class Initialized
INFO - 2021-07-07 16:45:11 --> Loader Class Initialized
INFO - 2021-07-07 16:45:11 --> Helper loaded: url_helper
INFO - 2021-07-07 16:45:11 --> Helper loaded: form_helper
INFO - 2021-07-07 16:45:11 --> Helper loaded: array_helper
INFO - 2021-07-07 16:45:11 --> Helper loaded: date_helper
INFO - 2021-07-07 16:45:11 --> Helper loaded: html_helper
INFO - 2021-07-07 16:45:11 --> Database Driver Class Initialized
INFO - 2021-07-07 16:45:11 --> Controller Class Initialized
DEBUG - 2021-07-07 16:45:11 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 16:45:11 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 16:45:11 --> Model "Contadorprocuracao_model" initialized
ERROR - 2021-07-07 11:45:11 --> Query error: Table 'Exatas.dtb_certificado_contador' doesn't exist - Invalid query: SELECT *
FROM `Exatas`.`dtb_certificado_contador`
INFO - 2021-07-07 11:45:11 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-07 16:45:20 --> Config Class Initialized
INFO - 2021-07-07 16:45:20 --> Hooks Class Initialized
DEBUG - 2021-07-07 16:45:20 --> UTF-8 Support Enabled
INFO - 2021-07-07 16:45:20 --> Utf8 Class Initialized
INFO - 2021-07-07 16:45:20 --> URI Class Initialized
INFO - 2021-07-07 16:45:20 --> Router Class Initialized
INFO - 2021-07-07 16:45:20 --> Output Class Initialized
INFO - 2021-07-07 16:45:20 --> Security Class Initialized
DEBUG - 2021-07-07 16:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 16:45:20 --> Input Class Initialized
INFO - 2021-07-07 16:45:20 --> Language Class Initialized
INFO - 2021-07-07 16:45:20 --> Loader Class Initialized
INFO - 2021-07-07 16:45:20 --> Helper loaded: url_helper
INFO - 2021-07-07 16:45:20 --> Helper loaded: form_helper
INFO - 2021-07-07 16:45:20 --> Helper loaded: array_helper
INFO - 2021-07-07 16:45:20 --> Helper loaded: date_helper
INFO - 2021-07-07 16:45:20 --> Helper loaded: html_helper
INFO - 2021-07-07 16:45:20 --> Database Driver Class Initialized
INFO - 2021-07-07 16:45:20 --> Controller Class Initialized
DEBUG - 2021-07-07 16:45:20 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 16:45:20 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 16:45:20 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 11:45:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 11:45:27 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 11:45:27 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-07 16:49:03 --> Config Class Initialized
INFO - 2021-07-07 16:49:03 --> Hooks Class Initialized
DEBUG - 2021-07-07 16:49:03 --> UTF-8 Support Enabled
INFO - 2021-07-07 16:49:03 --> Utf8 Class Initialized
INFO - 2021-07-07 16:49:03 --> URI Class Initialized
INFO - 2021-07-07 16:49:03 --> Router Class Initialized
INFO - 2021-07-07 16:49:03 --> Output Class Initialized
INFO - 2021-07-07 16:49:03 --> Security Class Initialized
DEBUG - 2021-07-07 16:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 16:49:03 --> Input Class Initialized
INFO - 2021-07-07 16:49:03 --> Language Class Initialized
INFO - 2021-07-07 16:49:03 --> Loader Class Initialized
INFO - 2021-07-07 16:49:03 --> Helper loaded: url_helper
INFO - 2021-07-07 16:49:03 --> Helper loaded: form_helper
INFO - 2021-07-07 16:49:03 --> Helper loaded: array_helper
INFO - 2021-07-07 16:49:03 --> Helper loaded: date_helper
INFO - 2021-07-07 16:49:03 --> Helper loaded: html_helper
INFO - 2021-07-07 16:49:03 --> Database Driver Class Initialized
INFO - 2021-07-07 16:49:03 --> Controller Class Initialized
DEBUG - 2021-07-07 16:49:03 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 16:49:03 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 16:49:03 --> Model "Procuracao_model" initialized
INFO - 2021-07-07 11:49:06 --> Ecac Robo Class Initialized
INFO - 2021-07-07 11:49:59 --> Final output sent to browser
DEBUG - 2021-07-07 11:49:59 --> Total execution time: 56.0414
INFO - 2021-07-07 12:18:04 --> Ecac Robo Class Initialized
INFO - 2021-07-07 12:18:04 --> Final output sent to browser
DEBUG - 2021-07-07 12:18:04 --> Total execution time: 1,964.5442
INFO - 2021-07-07 19:32:47 --> Config Class Initialized
INFO - 2021-07-07 19:32:47 --> Hooks Class Initialized
DEBUG - 2021-07-07 19:32:47 --> UTF-8 Support Enabled
INFO - 2021-07-07 19:32:47 --> Utf8 Class Initialized
INFO - 2021-07-07 19:32:47 --> URI Class Initialized
INFO - 2021-07-07 19:32:47 --> Router Class Initialized
INFO - 2021-07-07 19:32:47 --> Output Class Initialized
INFO - 2021-07-07 19:32:47 --> Security Class Initialized
DEBUG - 2021-07-07 19:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 19:32:47 --> Input Class Initialized
INFO - 2021-07-07 19:32:47 --> Language Class Initialized
INFO - 2021-07-07 19:32:47 --> Loader Class Initialized
INFO - 2021-07-07 19:32:47 --> Helper loaded: url_helper
INFO - 2021-07-07 19:32:47 --> Helper loaded: form_helper
INFO - 2021-07-07 19:32:47 --> Helper loaded: array_helper
INFO - 2021-07-07 19:32:47 --> Helper loaded: date_helper
INFO - 2021-07-07 19:32:47 --> Helper loaded: html_helper
INFO - 2021-07-07 19:32:47 --> Database Driver Class Initialized
INFO - 2021-07-07 19:32:47 --> Controller Class Initialized
DEBUG - 2021-07-07 19:32:47 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 19:32:47 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 19:32:47 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 14:32:50 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:33:32 --> Config Class Initialized
INFO - 2021-07-07 19:33:32 --> Hooks Class Initialized
DEBUG - 2021-07-07 19:33:32 --> UTF-8 Support Enabled
INFO - 2021-07-07 19:33:32 --> Utf8 Class Initialized
INFO - 2021-07-07 19:33:32 --> URI Class Initialized
INFO - 2021-07-07 19:33:32 --> Router Class Initialized
INFO - 2021-07-07 19:33:32 --> Output Class Initialized
INFO - 2021-07-07 19:33:32 --> Security Class Initialized
DEBUG - 2021-07-07 19:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 19:33:32 --> Input Class Initialized
INFO - 2021-07-07 19:33:32 --> Language Class Initialized
INFO - 2021-07-07 19:33:32 --> Loader Class Initialized
INFO - 2021-07-07 19:33:32 --> Helper loaded: url_helper
INFO - 2021-07-07 19:33:32 --> Helper loaded: form_helper
INFO - 2021-07-07 19:33:32 --> Helper loaded: array_helper
INFO - 2021-07-07 19:33:32 --> Helper loaded: date_helper
INFO - 2021-07-07 19:33:32 --> Helper loaded: html_helper
INFO - 2021-07-07 19:33:32 --> Database Driver Class Initialized
INFO - 2021-07-07 19:33:32 --> Controller Class Initialized
DEBUG - 2021-07-07 19:33:32 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 19:33:32 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 19:33:32 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 14:33:35 --> Ecac Robo Class Initialized
INFO - 2021-07-07 14:33:54 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 14:33:54 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-07 14:33:59 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-07 14:42:01 --> Final output sent to browser
DEBUG - 2021-07-07 14:42:01 --> Total execution time: 509.4268
INFO - 2021-07-07 14:54:47 --> Final output sent to browser
DEBUG - 2021-07-07 14:54:47 --> Total execution time: 1,320.8594
INFO - 2021-07-07 19:59:14 --> Config Class Initialized
INFO - 2021-07-07 19:59:14 --> Hooks Class Initialized
DEBUG - 2021-07-07 19:59:14 --> UTF-8 Support Enabled
INFO - 2021-07-07 19:59:14 --> Utf8 Class Initialized
INFO - 2021-07-07 19:59:14 --> URI Class Initialized
INFO - 2021-07-07 19:59:14 --> Router Class Initialized
INFO - 2021-07-07 19:59:14 --> Output Class Initialized
INFO - 2021-07-07 19:59:14 --> Security Class Initialized
DEBUG - 2021-07-07 19:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 19:59:14 --> Input Class Initialized
INFO - 2021-07-07 19:59:14 --> Language Class Initialized
INFO - 2021-07-07 19:59:14 --> Loader Class Initialized
INFO - 2021-07-07 19:59:14 --> Helper loaded: url_helper
INFO - 2021-07-07 19:59:14 --> Helper loaded: form_helper
INFO - 2021-07-07 19:59:14 --> Helper loaded: array_helper
INFO - 2021-07-07 19:59:14 --> Helper loaded: date_helper
INFO - 2021-07-07 19:59:14 --> Helper loaded: html_helper
INFO - 2021-07-07 19:59:14 --> Database Driver Class Initialized
INFO - 2021-07-07 19:59:14 --> Controller Class Initialized
DEBUG - 2021-07-07 19:59:14 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 19:59:14 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 19:59:14 --> Model "Procuracao_model" initialized
INFO - 2021-07-07 14:59:17 --> Ecac Robo Class Initialized
INFO - 2021-07-07 14:59:56 --> Final output sent to browser
DEBUG - 2021-07-07 14:59:56 --> Total execution time: 42.9028
INFO - 2021-07-07 20:17:05 --> Config Class Initialized
INFO - 2021-07-07 20:17:05 --> Hooks Class Initialized
DEBUG - 2021-07-07 20:17:05 --> UTF-8 Support Enabled
INFO - 2021-07-07 20:17:05 --> Utf8 Class Initialized
INFO - 2021-07-07 20:17:05 --> URI Class Initialized
INFO - 2021-07-07 20:17:05 --> Router Class Initialized
INFO - 2021-07-07 20:17:05 --> Output Class Initialized
INFO - 2021-07-07 20:17:05 --> Security Class Initialized
DEBUG - 2021-07-07 20:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 20:17:05 --> Input Class Initialized
INFO - 2021-07-07 20:17:05 --> Language Class Initialized
INFO - 2021-07-07 20:17:05 --> Loader Class Initialized
INFO - 2021-07-07 20:17:05 --> Helper loaded: url_helper
INFO - 2021-07-07 20:17:05 --> Helper loaded: form_helper
INFO - 2021-07-07 20:17:05 --> Helper loaded: array_helper
INFO - 2021-07-07 20:17:05 --> Helper loaded: date_helper
INFO - 2021-07-07 20:17:05 --> Helper loaded: html_helper
INFO - 2021-07-07 20:17:05 --> Database Driver Class Initialized
INFO - 2021-07-07 20:17:05 --> Controller Class Initialized
INFO - 2021-07-07 20:17:05 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 20:17:05 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 20:17:05 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-07 15:17:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 15:22:29 --> Final output sent to browser
DEBUG - 2021-07-07 15:22:29 --> Total execution time: 323.2972
INFO - 2021-07-07 21:39:05 --> Config Class Initialized
INFO - 2021-07-07 21:39:05 --> Hooks Class Initialized
DEBUG - 2021-07-07 21:39:05 --> UTF-8 Support Enabled
INFO - 2021-07-07 21:39:05 --> Utf8 Class Initialized
INFO - 2021-07-07 21:39:05 --> URI Class Initialized
INFO - 2021-07-07 21:39:05 --> Router Class Initialized
INFO - 2021-07-07 21:39:05 --> Output Class Initialized
INFO - 2021-07-07 21:39:05 --> Security Class Initialized
DEBUG - 2021-07-07 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 21:39:05 --> Input Class Initialized
INFO - 2021-07-07 21:39:05 --> Language Class Initialized
INFO - 2021-07-07 21:39:05 --> Loader Class Initialized
INFO - 2021-07-07 21:39:05 --> Helper loaded: url_helper
INFO - 2021-07-07 21:39:05 --> Helper loaded: form_helper
INFO - 2021-07-07 21:39:05 --> Helper loaded: array_helper
INFO - 2021-07-07 21:39:05 --> Helper loaded: date_helper
INFO - 2021-07-07 21:39:05 --> Helper loaded: html_helper
INFO - 2021-07-07 21:39:05 --> Database Driver Class Initialized
INFO - 2021-07-07 21:39:05 --> Controller Class Initialized
DEBUG - 2021-07-07 21:39:05 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 21:39:05 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 21:39:05 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-07 21:39:05 --> Model "Dctf_model" initialized
INFO - 2021-07-07 16:39:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:46:01 --> Config Class Initialized
INFO - 2021-07-07 21:46:01 --> Hooks Class Initialized
DEBUG - 2021-07-07 21:46:01 --> UTF-8 Support Enabled
INFO - 2021-07-07 21:46:01 --> Utf8 Class Initialized
INFO - 2021-07-07 21:46:01 --> URI Class Initialized
INFO - 2021-07-07 21:46:01 --> Router Class Initialized
INFO - 2021-07-07 21:46:01 --> Output Class Initialized
INFO - 2021-07-07 21:46:01 --> Security Class Initialized
DEBUG - 2021-07-07 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-07 21:46:01 --> Input Class Initialized
INFO - 2021-07-07 21:46:01 --> Language Class Initialized
INFO - 2021-07-07 21:46:01 --> Loader Class Initialized
INFO - 2021-07-07 21:46:01 --> Helper loaded: url_helper
INFO - 2021-07-07 21:46:01 --> Helper loaded: form_helper
INFO - 2021-07-07 21:46:01 --> Helper loaded: array_helper
INFO - 2021-07-07 21:46:01 --> Helper loaded: date_helper
INFO - 2021-07-07 21:46:01 --> Helper loaded: html_helper
INFO - 2021-07-07 21:46:01 --> Database Driver Class Initialized
INFO - 2021-07-07 21:46:01 --> Controller Class Initialized
DEBUG - 2021-07-07 21:46:01 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-07 21:46:01 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-07 21:46:01 --> Model "Procuracao_model" initialized
INFO - 2021-07-07 16:46:04 --> Final output sent to browser
DEBUG - 2021-07-07 16:46:04 --> Total execution time: 419.0116
INFO - 2021-07-07 16:46:05 --> Ecac Robo Class Initialized
INFO - 2021-07-07 16:46:52 --> Final output sent to browser
DEBUG - 2021-07-07 16:46:52 --> Total execution time: 50.6742
INFO - 2021-07-07 19:22:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:22:43 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-07 19:40:36 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:40:45 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-07 19:40:55 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:08 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:17 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:41:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:42:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:42:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:42:35 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:42:46 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:42:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:05 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:13 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:22 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:43:52 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:44:01 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:44:11 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:44:23 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:44:32 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:44:32 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:44:32 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:44:32 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:44:37 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:44:37 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:44:37 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
ERROR - 2021-07-07 19:44:37 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-07 19:44:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Situacao_fiscal_ecac_procuracao.php:101) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-07 19:44:38 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:44:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:44:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:44:44 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:44:44 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:44:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:45:00 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:45:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:45:24 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:45:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:45:58 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:46:07 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:46:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:46:36 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:46:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:46:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:47:11 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:47:14 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:47:29 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:47:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:47:51 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 19:47:51 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-07 19:48:01 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:48:16 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:48:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:48:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:48:52 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:49:06 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:49:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:49:21 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:49:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:49:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:50:10 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:50:22 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:50:33 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:50:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:50:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:06 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:51:12 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:51:12 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:51:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:16 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:51:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:51:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:51:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:51:21 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:25 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:51:35 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:51:35 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:51:35 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:51:36 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:52 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:51:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:52:12 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:52:20 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/32014327840.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 19:52:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:52:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:52:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:52:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:52:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:53:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:53:34 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:53:40 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:53:40 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:53:40 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:53:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:53:43 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:53:52 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:54:04 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:54:16 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:54:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:54:40 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:54:46 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:54:46 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:54:46 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:54:46 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:54:56 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:55:01 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/10731781880.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 19:55:01 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:55:01 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:55:01 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:55:05 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 19:55:14 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 19:55:14 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 19:55:14 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 19:55:14 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:55:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:55:27 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:55:58 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:11 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:56:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:57:07 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:57:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:57:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:57:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:57:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 19:58:09 --> Final output sent to browser
DEBUG - 2021-07-07 19:58:09 --> Total execution time: 1,058.4103
INFO - 2021-07-07 20:01:30 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:01:37 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:02:04 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:02:28 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/01683489000106.pfx): failed to open stream: Uma tentativa de conex�o falhou porque o componente conectado n�o respondeu
corretamente ap�s um per�odo de tempo ou a conex�o estabelecida falhou
porque o host conectado n�o respondeu.
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 20:02:28 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:02:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:02:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:02:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:02:54 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:03:01 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:03:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:03:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:03:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:29 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:38 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:43 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:53 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:04:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:06 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:18 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:05:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:05:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:05:21 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:05:21 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:25 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:05:28 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:05:28 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:05:28 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:05:30 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:05:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:06 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:11 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:06:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:08 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:17 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:24 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:37 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:07:39 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-07 20:07:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:75) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-07 20:07:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:07:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:17 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:34 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:43 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:50 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:08:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:09:08 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:09:14 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:09:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:09:48 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:09:50 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:09:50 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:09:50 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:09:50 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:09:51 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:09:51 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:09:51 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:09:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:09:54 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:09:59 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:09:59 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:09:59 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:09:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:07 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:10:09 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:10:09 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:10:09 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:10:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:13 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:39 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:10:40 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/32014327840.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 20:10:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:10:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:13 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:30 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:39 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:11:41 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:11:41 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:11:41 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:11:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:11:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:12:09 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:12:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:12:29 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:12:53 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:12:55 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:12:55 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:12:55 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:12:55 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:05 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:13:08 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/10731781880.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 20:13:08 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:13:08 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:13:08 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:14 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:13:16 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:13:16 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:13:16 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:13:17 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:33 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:13:55 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:13 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:27 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:42 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:53 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:14:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:15:05 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:15:14 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:15:17 --> Final output sent to browser
DEBUG - 2021-07-07 20:15:17 --> Total execution time: 831.4206
INFO - 2021-07-07 20:31:37 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:31:40 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 20:31:40 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-07 20:31:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:32:10 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:32:43 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:33:29 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:33:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:33:43 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:33:47 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:34:24 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:34:42 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:34:53 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:35:28 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:36:03 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:36:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:36:31 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:37:05 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:37:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:37:55 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:38:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:38:42 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:38:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:39:40 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:39:47 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:39:47 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:39:47 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:39:47 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:40:05 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:40:34 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:40:34 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:40:34 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:40:35 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:40:44 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:41:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:41:13 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:41:37 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:42:22 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:42:45 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:42:54 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:43:05 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:43:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:43:30 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:43:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:43:50 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:44:25 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:44:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:45:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:45:44 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:46:38 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:46:51 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:47:46 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:48:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:48:27 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:48:56 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:49:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:49:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:49:48 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:50:19 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:51:50 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:51:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:52:29 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:52:43 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:52:49 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:52:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:52:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:52:54 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:53:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:53:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:53:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:53:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:53:30 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:53:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:53:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:53:49 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:53:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:53:55 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:54:12 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:54:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:54:25 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:54:27 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/32014327840.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 20:54:27 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:54:31 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:55:14 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:55:28 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:55:40 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:55:58 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:56:05 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:56:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:56:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:56:23 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:56:23 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:56:31 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:56:39 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:57:18 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:57:28 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:57:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:58:16 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:58:20 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:58:20 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:58:20 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:58:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:58:24 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:58:29 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:58:29 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:58:29 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:58:29 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:58:29 --> Severity: Warning --> file_get_contents(https://veri-sp.com.br/crons-api/assets/empresas/certificados/tecconcontabil/10731781880.pfx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 217
INFO - 2021-07-07 20:58:30 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:58:30 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:58:30 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:58:30 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:58:30 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:58:36 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 20:58:42 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-07 20:58:42 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-07 20:58:42 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
INFO - 2021-07-07 20:58:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:58:57 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:03 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:11 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:20 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:26 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 20:59:49 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:00:01 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:00:16 --> Ecac Robo Class Initialized
ERROR - 2021-07-07 21:00:18 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_eprocessos_library.php 313
ERROR - 2021-07-07 21:00:18 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_eprocessos_library.php 314
INFO - 2021-07-07 21:00:27 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:00:32 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:00:46 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:01:02 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:01:41 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:02:12 --> Final output sent to browser
DEBUG - 2021-07-07 21:02:12 --> Total execution time: 1,840.1046
INFO - 2021-07-07 21:19:59 --> Ecac Robo Class Initialized
INFO - 2021-07-07 21:20:06 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-07 21:20:06 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-07 22:01:30 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-07 22:01:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:75) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
