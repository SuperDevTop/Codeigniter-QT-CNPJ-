<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-16 16:58:19 --> Config Class Initialized
INFO - 2021-07-16 16:58:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 16:58:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 16:58:19 --> Utf8 Class Initialized
INFO - 2021-07-16 16:58:19 --> URI Class Initialized
INFO - 2021-07-16 16:58:19 --> Router Class Initialized
INFO - 2021-07-16 16:58:19 --> Output Class Initialized
INFO - 2021-07-16 16:58:19 --> Security Class Initialized
DEBUG - 2021-07-16 16:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 16:58:19 --> Input Class Initialized
INFO - 2021-07-16 16:58:19 --> Language Class Initialized
INFO - 2021-07-16 16:58:19 --> Loader Class Initialized
INFO - 2021-07-16 16:58:19 --> Helper loaded: url_helper
INFO - 2021-07-16 16:58:19 --> Helper loaded: form_helper
INFO - 2021-07-16 16:58:19 --> Helper loaded: array_helper
INFO - 2021-07-16 16:58:19 --> Helper loaded: date_helper
INFO - 2021-07-16 16:58:19 --> Helper loaded: html_helper
INFO - 2021-07-16 16:58:19 --> Database Driver Class Initialized
INFO - 2021-07-16 16:58:19 --> Controller Class Initialized
DEBUG - 2021-07-16 16:58:19 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 16:58:19 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 16:58:19 --> Model "Procuracao_model" initialized
INFO - 2021-07-16 16:58:22 --> Config Class Initialized
INFO - 2021-07-16 16:58:22 --> Hooks Class Initialized
DEBUG - 2021-07-16 16:58:22 --> UTF-8 Support Enabled
INFO - 2021-07-16 16:58:22 --> Utf8 Class Initialized
INFO - 2021-07-16 16:58:22 --> URI Class Initialized
INFO - 2021-07-16 16:58:22 --> Router Class Initialized
INFO - 2021-07-16 16:58:22 --> Output Class Initialized
INFO - 2021-07-16 16:58:22 --> Security Class Initialized
DEBUG - 2021-07-16 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 16:58:22 --> Input Class Initialized
INFO - 2021-07-16 16:58:22 --> Language Class Initialized
INFO - 2021-07-16 16:58:22 --> Loader Class Initialized
INFO - 2021-07-16 16:58:22 --> Helper loaded: url_helper
INFO - 2021-07-16 16:58:22 --> Helper loaded: form_helper
INFO - 2021-07-16 16:58:22 --> Helper loaded: array_helper
INFO - 2021-07-16 16:58:22 --> Helper loaded: date_helper
INFO - 2021-07-16 16:58:22 --> Helper loaded: html_helper
INFO - 2021-07-16 16:58:22 --> Database Driver Class Initialized
INFO - 2021-07-16 16:58:22 --> Controller Class Initialized
DEBUG - 2021-07-16 16:58:22 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 16:58:22 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 16:58:22 --> Model "Procuracao_model" initialized
ERROR - 2021-07-16 11:59:14 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-16 12:00:55 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
INFO - 2021-07-16 17:03:15 --> Config Class Initialized
INFO - 2021-07-16 17:03:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 17:03:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 17:03:15 --> Utf8 Class Initialized
INFO - 2021-07-16 17:03:15 --> URI Class Initialized
INFO - 2021-07-16 17:03:15 --> Router Class Initialized
INFO - 2021-07-16 17:03:15 --> Output Class Initialized
INFO - 2021-07-16 17:03:15 --> Security Class Initialized
DEBUG - 2021-07-16 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 17:03:15 --> Input Class Initialized
INFO - 2021-07-16 17:03:15 --> Language Class Initialized
INFO - 2021-07-16 17:03:15 --> Loader Class Initialized
INFO - 2021-07-16 17:03:15 --> Helper loaded: url_helper
INFO - 2021-07-16 17:03:15 --> Helper loaded: form_helper
INFO - 2021-07-16 17:03:15 --> Helper loaded: array_helper
INFO - 2021-07-16 17:03:15 --> Helper loaded: date_helper
INFO - 2021-07-16 17:03:15 --> Helper loaded: html_helper
INFO - 2021-07-16 17:03:15 --> Database Driver Class Initialized
INFO - 2021-07-16 17:03:15 --> Controller Class Initialized
DEBUG - 2021-07-16 17:03:15 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 17:03:15 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 17:03:15 --> Model "Procuracao_model" initialized
INFO - 2021-07-16 12:05:35 --> Ecac Robo Class Initialized
INFO - 2021-07-16 12:06:06 --> Ecac Robo Class Initialized
INFO - 2021-07-16 12:06:27 --> Final output sent to browser
DEBUG - 2021-07-16 12:06:27 --> Total execution time: 192.3937
INFO - 2021-07-16 17:10:26 --> Config Class Initialized
INFO - 2021-07-16 17:10:26 --> Hooks Class Initialized
DEBUG - 2021-07-16 17:10:26 --> UTF-8 Support Enabled
INFO - 2021-07-16 17:10:26 --> Utf8 Class Initialized
INFO - 2021-07-16 17:10:26 --> URI Class Initialized
INFO - 2021-07-16 17:10:26 --> Router Class Initialized
INFO - 2021-07-16 17:10:26 --> Output Class Initialized
INFO - 2021-07-16 17:10:26 --> Security Class Initialized
DEBUG - 2021-07-16 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 17:10:26 --> Input Class Initialized
INFO - 2021-07-16 17:10:26 --> Language Class Initialized
INFO - 2021-07-16 17:10:26 --> Loader Class Initialized
INFO - 2021-07-16 17:10:26 --> Helper loaded: url_helper
INFO - 2021-07-16 17:10:26 --> Helper loaded: form_helper
INFO - 2021-07-16 17:10:26 --> Helper loaded: array_helper
INFO - 2021-07-16 17:10:26 --> Helper loaded: date_helper
INFO - 2021-07-16 17:10:26 --> Helper loaded: html_helper
INFO - 2021-07-16 17:10:26 --> Database Driver Class Initialized
INFO - 2021-07-16 17:10:28 --> Controller Class Initialized
DEBUG - 2021-07-16 17:10:28 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 17:10:28 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 17:10:28 --> Model "Procuracao_model" initialized
INFO - 2021-07-16 12:10:34 --> Ecac Robo Class Initialized
INFO - 2021-07-16 12:11:23 --> Ecac Robo Class Initialized
INFO - 2021-07-16 12:12:07 --> Final output sent to browser
DEBUG - 2021-07-16 12:12:07 --> Total execution time: 101.1779
INFO - 2021-07-16 18:43:15 --> Config Class Initialized
INFO - 2021-07-16 18:43:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 18:43:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 18:43:15 --> Utf8 Class Initialized
INFO - 2021-07-16 18:43:15 --> URI Class Initialized
INFO - 2021-07-16 18:43:15 --> Router Class Initialized
INFO - 2021-07-16 18:43:15 --> Output Class Initialized
INFO - 2021-07-16 18:43:15 --> Security Class Initialized
DEBUG - 2021-07-16 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 18:43:15 --> Input Class Initialized
INFO - 2021-07-16 18:43:15 --> Language Class Initialized
ERROR - 2021-07-16 18:43:15 --> 404 Page Not Found: SistemacronsCertificado/sp
INFO - 2021-07-16 18:43:34 --> Config Class Initialized
INFO - 2021-07-16 18:43:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 18:43:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 18:43:34 --> Utf8 Class Initialized
INFO - 2021-07-16 18:43:34 --> URI Class Initialized
INFO - 2021-07-16 18:43:34 --> Router Class Initialized
INFO - 2021-07-16 18:43:34 --> Output Class Initialized
INFO - 2021-07-16 18:43:34 --> Security Class Initialized
DEBUG - 2021-07-16 18:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 18:43:34 --> Input Class Initialized
INFO - 2021-07-16 18:43:34 --> Language Class Initialized
ERROR - 2021-07-16 18:43:34 --> 404 Page Not Found: SistemacronsCertificado/sp
INFO - 2021-07-16 18:43:45 --> Config Class Initialized
INFO - 2021-07-16 18:43:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 18:43:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 18:43:45 --> Utf8 Class Initialized
INFO - 2021-07-16 18:43:45 --> URI Class Initialized
INFO - 2021-07-16 18:43:45 --> Router Class Initialized
INFO - 2021-07-16 18:43:45 --> Output Class Initialized
INFO - 2021-07-16 18:43:45 --> Security Class Initialized
DEBUG - 2021-07-16 18:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 18:43:45 --> Input Class Initialized
INFO - 2021-07-16 18:43:45 --> Language Class Initialized
INFO - 2021-07-16 18:43:45 --> Loader Class Initialized
INFO - 2021-07-16 18:43:45 --> Helper loaded: url_helper
INFO - 2021-07-16 18:43:45 --> Helper loaded: form_helper
INFO - 2021-07-16 18:43:45 --> Helper loaded: array_helper
INFO - 2021-07-16 18:43:45 --> Helper loaded: date_helper
INFO - 2021-07-16 18:43:45 --> Helper loaded: html_helper
INFO - 2021-07-16 18:43:45 --> Database Driver Class Initialized
INFO - 2021-07-16 18:43:45 --> Controller Class Initialized
DEBUG - 2021-07-16 18:43:45 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 18:43:45 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 18:43:45 --> Model "Procuracao_model" initialized
INFO - 2021-07-16 13:43:49 --> Ecac Robo Class Initialized
INFO - 2021-07-16 13:44:53 --> Final output sent to browser
DEBUG - 2021-07-16 13:44:53 --> Total execution time: 68.2482
INFO - 2021-07-16 19:59:00 --> Config Class Initialized
INFO - 2021-07-16 19:59:00 --> Hooks Class Initialized
DEBUG - 2021-07-16 19:59:00 --> UTF-8 Support Enabled
INFO - 2021-07-16 19:59:00 --> Utf8 Class Initialized
INFO - 2021-07-16 19:59:00 --> URI Class Initialized
INFO - 2021-07-16 19:59:00 --> Router Class Initialized
INFO - 2021-07-16 19:59:00 --> Output Class Initialized
INFO - 2021-07-16 19:59:00 --> Security Class Initialized
DEBUG - 2021-07-16 19:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 19:59:00 --> Input Class Initialized
INFO - 2021-07-16 19:59:00 --> Language Class Initialized
INFO - 2021-07-16 19:59:00 --> Loader Class Initialized
INFO - 2021-07-16 19:59:00 --> Helper loaded: url_helper
INFO - 2021-07-16 19:59:00 --> Helper loaded: form_helper
INFO - 2021-07-16 19:59:00 --> Helper loaded: array_helper
INFO - 2021-07-16 19:59:00 --> Helper loaded: date_helper
INFO - 2021-07-16 19:59:00 --> Helper loaded: html_helper
INFO - 2021-07-16 19:59:00 --> Database Driver Class Initialized
INFO - 2021-07-16 19:59:01 --> Controller Class Initialized
INFO - 2021-07-16 19:59:01 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 19:59:01 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 19:59:01 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 14:59:05 --> Ecac Robo Class Initialized
INFO - 2021-07-16 14:59:10 --> Ecac Robo Class Initialized
ERROR - 2021-07-16 14:59:10 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 302
ERROR - 2021-07-16 14:59:10 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 308
ERROR - 2021-07-16 14:59:10 --> Severity: Warning --> file_put_contents(): Filename cannot be empty C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Certificate\Pkcs12.php 309
ERROR - 2021-07-16 14:59:10 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
ERROR - 2021-07-16 14:59:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-16 20:06:24 --> Config Class Initialized
INFO - 2021-07-16 20:06:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 20:06:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 20:06:24 --> Utf8 Class Initialized
INFO - 2021-07-16 20:06:24 --> URI Class Initialized
INFO - 2021-07-16 20:06:24 --> Router Class Initialized
INFO - 2021-07-16 20:06:24 --> Output Class Initialized
INFO - 2021-07-16 20:06:24 --> Security Class Initialized
DEBUG - 2021-07-16 20:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 20:06:24 --> Input Class Initialized
INFO - 2021-07-16 20:06:24 --> Language Class Initialized
INFO - 2021-07-16 20:06:24 --> Loader Class Initialized
INFO - 2021-07-16 20:06:24 --> Helper loaded: url_helper
INFO - 2021-07-16 20:06:24 --> Helper loaded: form_helper
INFO - 2021-07-16 20:06:24 --> Helper loaded: array_helper
INFO - 2021-07-16 20:06:24 --> Helper loaded: date_helper
INFO - 2021-07-16 20:06:24 --> Helper loaded: html_helper
INFO - 2021-07-16 20:06:24 --> Database Driver Class Initialized
INFO - 2021-07-16 20:06:25 --> Controller Class Initialized
INFO - 2021-07-16 20:06:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 20:06:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 20:06:25 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 15:06:29 --> Ecac Robo Class Initialized
INFO - 2021-07-16 15:09:32 --> Ecac Robo Class Initialized
INFO - 2021-07-16 15:09:32 --> Final output sent to browser
DEBUG - 2021-07-16 15:09:32 --> Total execution time: 187.9173
INFO - 2021-07-16 21:17:02 --> Config Class Initialized
INFO - 2021-07-16 21:17:02 --> Hooks Class Initialized
DEBUG - 2021-07-16 21:17:02 --> UTF-8 Support Enabled
INFO - 2021-07-16 21:17:02 --> Utf8 Class Initialized
INFO - 2021-07-16 21:17:02 --> URI Class Initialized
INFO - 2021-07-16 21:17:02 --> Router Class Initialized
INFO - 2021-07-16 21:17:02 --> Output Class Initialized
INFO - 2021-07-16 21:17:02 --> Security Class Initialized
DEBUG - 2021-07-16 21:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 21:17:02 --> Input Class Initialized
INFO - 2021-07-16 21:17:02 --> Language Class Initialized
INFO - 2021-07-16 21:17:02 --> Loader Class Initialized
INFO - 2021-07-16 21:17:02 --> Helper loaded: url_helper
INFO - 2021-07-16 21:17:02 --> Helper loaded: form_helper
INFO - 2021-07-16 21:17:02 --> Helper loaded: array_helper
INFO - 2021-07-16 21:17:02 --> Helper loaded: date_helper
INFO - 2021-07-16 21:17:02 --> Helper loaded: html_helper
INFO - 2021-07-16 21:17:02 --> Database Driver Class Initialized
INFO - 2021-07-16 21:17:02 --> Controller Class Initialized
INFO - 2021-07-16 21:17:02 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 21:17:02 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 21:17:02 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 16:17:07 --> Ecac Robo Class Initialized
INFO - 2021-07-16 16:41:04 --> Final output sent to browser
DEBUG - 2021-07-16 16:41:04 --> Total execution time: 1,441.7902
INFO - 2021-07-16 21:44:25 --> Config Class Initialized
INFO - 2021-07-16 21:44:25 --> Hooks Class Initialized
DEBUG - 2021-07-16 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-07-16 21:44:25 --> Utf8 Class Initialized
INFO - 2021-07-16 21:44:25 --> URI Class Initialized
INFO - 2021-07-16 21:44:25 --> Router Class Initialized
INFO - 2021-07-16 21:44:25 --> Output Class Initialized
INFO - 2021-07-16 21:44:25 --> Security Class Initialized
DEBUG - 2021-07-16 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 21:44:25 --> Input Class Initialized
INFO - 2021-07-16 21:44:25 --> Language Class Initialized
INFO - 2021-07-16 21:44:25 --> Loader Class Initialized
INFO - 2021-07-16 21:44:25 --> Helper loaded: url_helper
INFO - 2021-07-16 21:44:25 --> Helper loaded: form_helper
INFO - 2021-07-16 21:44:25 --> Helper loaded: array_helper
INFO - 2021-07-16 21:44:25 --> Helper loaded: date_helper
INFO - 2021-07-16 21:44:25 --> Helper loaded: html_helper
INFO - 2021-07-16 21:44:25 --> Database Driver Class Initialized
INFO - 2021-07-16 21:44:25 --> Controller Class Initialized
DEBUG - 2021-07-16 21:44:25 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 21:44:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 21:44:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 21:44:25 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 16:44:29 --> Ecac Robo Class Initialized
INFO - 2021-07-16 17:05:58 --> Final output sent to browser
DEBUG - 2021-07-16 17:05:58 --> Total execution time: 1,293.7607
INFO - 2021-07-16 22:12:12 --> Config Class Initialized
INFO - 2021-07-16 22:12:12 --> Hooks Class Initialized
DEBUG - 2021-07-16 22:12:12 --> UTF-8 Support Enabled
INFO - 2021-07-16 22:12:12 --> Utf8 Class Initialized
INFO - 2021-07-16 22:12:12 --> URI Class Initialized
INFO - 2021-07-16 22:12:12 --> Router Class Initialized
INFO - 2021-07-16 22:12:12 --> Output Class Initialized
INFO - 2021-07-16 22:12:12 --> Security Class Initialized
DEBUG - 2021-07-16 22:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 22:12:12 --> Input Class Initialized
INFO - 2021-07-16 22:12:12 --> Language Class Initialized
INFO - 2021-07-16 22:12:12 --> Loader Class Initialized
INFO - 2021-07-16 22:12:12 --> Helper loaded: url_helper
INFO - 2021-07-16 22:12:12 --> Helper loaded: form_helper
INFO - 2021-07-16 22:12:12 --> Helper loaded: array_helper
INFO - 2021-07-16 22:12:12 --> Helper loaded: date_helper
INFO - 2021-07-16 22:12:12 --> Helper loaded: html_helper
INFO - 2021-07-16 22:12:12 --> Database Driver Class Initialized
INFO - 2021-07-16 22:12:13 --> Controller Class Initialized
DEBUG - 2021-07-16 22:12:13 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 22:12:13 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 22:12:13 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 22:12:13 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 17:12:16 --> Ecac Robo Class Initialized
INFO - 2021-07-16 17:27:23 --> Final output sent to browser
DEBUG - 2021-07-16 17:27:23 --> Total execution time: 910.1400
INFO - 2021-07-16 22:32:44 --> Config Class Initialized
INFO - 2021-07-16 22:32:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 22:32:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 22:32:44 --> Utf8 Class Initialized
INFO - 2021-07-16 22:32:44 --> URI Class Initialized
INFO - 2021-07-16 22:32:44 --> Router Class Initialized
INFO - 2021-07-16 22:32:44 --> Output Class Initialized
INFO - 2021-07-16 22:32:44 --> Security Class Initialized
DEBUG - 2021-07-16 22:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 22:32:44 --> Input Class Initialized
INFO - 2021-07-16 22:32:44 --> Language Class Initialized
INFO - 2021-07-16 22:32:44 --> Loader Class Initialized
INFO - 2021-07-16 22:32:44 --> Helper loaded: url_helper
INFO - 2021-07-16 22:32:44 --> Helper loaded: form_helper
INFO - 2021-07-16 22:32:44 --> Helper loaded: array_helper
INFO - 2021-07-16 22:32:44 --> Helper loaded: date_helper
INFO - 2021-07-16 22:32:44 --> Helper loaded: html_helper
INFO - 2021-07-16 22:32:44 --> Database Driver Class Initialized
INFO - 2021-07-16 22:32:44 --> Controller Class Initialized
DEBUG - 2021-07-16 22:32:44 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 22:32:44 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 22:32:44 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 22:32:44 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 17:32:48 --> Ecac Robo Class Initialized
INFO - 2021-07-16 17:33:39 --> Final output sent to browser
DEBUG - 2021-07-16 17:33:39 --> Total execution time: 55.7265
INFO - 2021-07-16 22:38:24 --> Config Class Initialized
INFO - 2021-07-16 22:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 22:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 22:38:24 --> Utf8 Class Initialized
INFO - 2021-07-16 22:38:24 --> URI Class Initialized
INFO - 2021-07-16 22:38:24 --> Router Class Initialized
INFO - 2021-07-16 22:38:24 --> Output Class Initialized
INFO - 2021-07-16 22:38:24 --> Security Class Initialized
DEBUG - 2021-07-16 22:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 22:38:24 --> Input Class Initialized
INFO - 2021-07-16 22:38:24 --> Language Class Initialized
INFO - 2021-07-16 22:38:24 --> Loader Class Initialized
INFO - 2021-07-16 22:38:24 --> Helper loaded: url_helper
INFO - 2021-07-16 22:38:24 --> Helper loaded: form_helper
INFO - 2021-07-16 22:38:24 --> Helper loaded: array_helper
INFO - 2021-07-16 22:38:24 --> Helper loaded: date_helper
INFO - 2021-07-16 22:38:24 --> Helper loaded: html_helper
INFO - 2021-07-16 22:38:24 --> Database Driver Class Initialized
INFO - 2021-07-16 22:38:24 --> Controller Class Initialized
DEBUG - 2021-07-16 22:38:24 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 22:38:24 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 22:38:24 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 22:38:24 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-16 17:38:28 --> Ecac Robo Class Initialized
INFO - 2021-07-16 17:38:28 --> Final output sent to browser
DEBUG - 2021-07-16 17:38:28 --> Total execution time: 4.0377
INFO - 2021-07-16 22:59:47 --> Config Class Initialized
INFO - 2021-07-16 22:59:47 --> Hooks Class Initialized
DEBUG - 2021-07-16 22:59:47 --> UTF-8 Support Enabled
INFO - 2021-07-16 22:59:47 --> Utf8 Class Initialized
INFO - 2021-07-16 22:59:47 --> URI Class Initialized
INFO - 2021-07-16 22:59:47 --> Router Class Initialized
INFO - 2021-07-16 22:59:47 --> Output Class Initialized
INFO - 2021-07-16 22:59:47 --> Security Class Initialized
DEBUG - 2021-07-16 22:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 22:59:47 --> Input Class Initialized
INFO - 2021-07-16 22:59:47 --> Language Class Initialized
INFO - 2021-07-16 22:59:47 --> Loader Class Initialized
INFO - 2021-07-16 22:59:47 --> Helper loaded: url_helper
INFO - 2021-07-16 22:59:47 --> Helper loaded: form_helper
INFO - 2021-07-16 22:59:47 --> Helper loaded: array_helper
INFO - 2021-07-16 22:59:47 --> Helper loaded: date_helper
INFO - 2021-07-16 22:59:47 --> Helper loaded: html_helper
INFO - 2021-07-16 22:59:47 --> Database Driver Class Initialized
INFO - 2021-07-16 22:59:48 --> Controller Class Initialized
DEBUG - 2021-07-16 22:59:48 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 22:59:48 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 22:59:48 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 17:59:51 --> Ecac Robo Class Initialized
INFO - 2021-07-16 18:00:01 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-16 18:34:54 --> Final output sent to browser
DEBUG - 2021-07-16 18:34:54 --> Total execution time: 2,106.8104
INFO - 2021-07-16 23:42:13 --> Config Class Initialized
INFO - 2021-07-16 23:42:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 23:42:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 23:42:13 --> Utf8 Class Initialized
INFO - 2021-07-16 23:42:13 --> URI Class Initialized
INFO - 2021-07-16 23:42:13 --> Router Class Initialized
INFO - 2021-07-16 23:42:13 --> Output Class Initialized
INFO - 2021-07-16 23:42:13 --> Security Class Initialized
DEBUG - 2021-07-16 23:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 23:42:13 --> Input Class Initialized
INFO - 2021-07-16 23:42:13 --> Language Class Initialized
INFO - 2021-07-16 23:42:13 --> Loader Class Initialized
INFO - 2021-07-16 23:42:13 --> Helper loaded: url_helper
INFO - 2021-07-16 23:42:13 --> Helper loaded: form_helper
INFO - 2021-07-16 23:42:13 --> Helper loaded: array_helper
INFO - 2021-07-16 23:42:13 --> Helper loaded: date_helper
INFO - 2021-07-16 23:42:13 --> Helper loaded: html_helper
INFO - 2021-07-16 23:42:13 --> Database Driver Class Initialized
INFO - 2021-07-16 23:42:13 --> Controller Class Initialized
DEBUG - 2021-07-16 23:42:13 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-16 23:42:13 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-16 23:42:13 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-16 18:42:17 --> Ecac Robo Class Initialized
INFO - 2021-07-16 18:42:26 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-16 19:13:03 --> Final output sent to browser
DEBUG - 2021-07-16 19:13:03 --> Total execution time: 1,850.2778
INFO - 2021-07-16 19:25:12 --> Ecac Robo Class Initialized
INFO - 2021-07-16 19:25:20 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-16 19:49:04 --> Final output sent to browser
DEBUG - 2021-07-16 19:49:04 --> Total execution time: 1,436.0422
INFO - 2021-07-16 20:10:55 --> Ecac Robo Class Initialized
INFO - 2021-07-16 20:11:05 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-16 20:12:24 --> Final output sent to browser
DEBUG - 2021-07-16 20:12:24 --> Total execution time: 94.2645
INFO - 2021-07-16 20:22:43 --> Ecac Robo Class Initialized
INFO - 2021-07-16 20:22:48 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-16 20:22:48 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-16 20:32:44 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-16 20:32:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_procuracao.php:80) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-16 20:36:23 --> Ecac Robo Class Initialized
INFO - 2021-07-16 20:36:28 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-16 20:36:28 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-16 20:37:24 --> Final output sent to browser
DEBUG - 2021-07-16 20:37:24 --> Total execution time: 66.3502
INFO - 2021-07-16 20:37:47 --> Ecac Robo Class Initialized
INFO - 2021-07-16 20:37:52 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-16 20:37:52 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-16 20:45:40 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
