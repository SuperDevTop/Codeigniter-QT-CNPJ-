<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-22 00:31:10 --> Config Class Initialized
INFO - 2021-07-22 00:31:10 --> Hooks Class Initialized
DEBUG - 2021-07-22 00:31:10 --> UTF-8 Support Enabled
INFO - 2021-07-22 00:31:10 --> Utf8 Class Initialized
INFO - 2021-07-22 00:31:10 --> URI Class Initialized
INFO - 2021-07-22 00:31:10 --> Router Class Initialized
INFO - 2021-07-22 00:31:10 --> Output Class Initialized
INFO - 2021-07-22 00:31:10 --> Security Class Initialized
DEBUG - 2021-07-22 00:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 00:31:10 --> Input Class Initialized
INFO - 2021-07-22 00:31:10 --> Language Class Initialized
INFO - 2021-07-22 00:31:10 --> Loader Class Initialized
INFO - 2021-07-22 00:31:10 --> Helper loaded: url_helper
INFO - 2021-07-22 00:31:10 --> Helper loaded: form_helper
INFO - 2021-07-22 00:31:10 --> Helper loaded: array_helper
INFO - 2021-07-22 00:31:10 --> Helper loaded: date_helper
INFO - 2021-07-22 00:31:10 --> Helper loaded: html_helper
INFO - 2021-07-22 00:31:10 --> Database Driver Class Initialized
INFO - 2021-07-22 00:31:12 --> Controller Class Initialized
DEBUG - 2021-07-22 00:31:12 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 00:31:12 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 00:31:12 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 00:31:12 --> Model "Dctf_model" initialized
INFO - 2021-07-22 00:39:47 --> Config Class Initialized
INFO - 2021-07-22 00:39:47 --> Hooks Class Initialized
DEBUG - 2021-07-22 00:39:47 --> UTF-8 Support Enabled
INFO - 2021-07-22 00:39:47 --> Utf8 Class Initialized
INFO - 2021-07-22 00:39:47 --> URI Class Initialized
INFO - 2021-07-22 00:39:47 --> Router Class Initialized
INFO - 2021-07-22 00:39:47 --> Output Class Initialized
INFO - 2021-07-22 00:39:47 --> Security Class Initialized
DEBUG - 2021-07-22 00:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 00:39:47 --> Input Class Initialized
INFO - 2021-07-22 00:39:47 --> Language Class Initialized
INFO - 2021-07-22 00:39:47 --> Loader Class Initialized
INFO - 2021-07-22 00:39:47 --> Helper loaded: url_helper
INFO - 2021-07-22 00:39:47 --> Helper loaded: form_helper
INFO - 2021-07-22 00:39:47 --> Helper loaded: array_helper
INFO - 2021-07-22 00:39:47 --> Helper loaded: date_helper
INFO - 2021-07-22 00:39:47 --> Helper loaded: html_helper
INFO - 2021-07-22 00:39:47 --> Database Driver Class Initialized
INFO - 2021-07-22 00:39:48 --> Controller Class Initialized
DEBUG - 2021-07-22 00:39:48 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 00:39:48 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 00:39:48 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 00:39:48 --> Model "Dctf_model" initialized
INFO - 2021-07-22 00:57:45 --> Config Class Initialized
INFO - 2021-07-22 00:57:45 --> Hooks Class Initialized
DEBUG - 2021-07-22 00:57:45 --> UTF-8 Support Enabled
INFO - 2021-07-22 00:57:45 --> Utf8 Class Initialized
INFO - 2021-07-22 00:57:45 --> URI Class Initialized
INFO - 2021-07-22 00:57:45 --> Router Class Initialized
INFO - 2021-07-22 00:57:45 --> Output Class Initialized
INFO - 2021-07-22 00:57:45 --> Security Class Initialized
DEBUG - 2021-07-22 00:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 00:57:45 --> Input Class Initialized
INFO - 2021-07-22 00:57:45 --> Language Class Initialized
INFO - 2021-07-22 00:57:45 --> Loader Class Initialized
INFO - 2021-07-22 00:57:45 --> Helper loaded: url_helper
INFO - 2021-07-22 00:57:45 --> Helper loaded: form_helper
INFO - 2021-07-22 00:57:45 --> Helper loaded: array_helper
INFO - 2021-07-22 00:57:45 --> Helper loaded: date_helper
INFO - 2021-07-22 00:57:45 --> Helper loaded: html_helper
INFO - 2021-07-22 00:57:45 --> Database Driver Class Initialized
INFO - 2021-07-22 00:57:46 --> Controller Class Initialized
DEBUG - 2021-07-22 00:57:46 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 00:57:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 00:57:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 00:57:46 --> Model "Dctf_model" initialized
INFO - 2021-07-22 02:48:20 --> Config Class Initialized
INFO - 2021-07-22 02:48:20 --> Hooks Class Initialized
DEBUG - 2021-07-22 02:48:20 --> UTF-8 Support Enabled
INFO - 2021-07-22 02:48:20 --> Utf8 Class Initialized
INFO - 2021-07-22 02:48:20 --> URI Class Initialized
INFO - 2021-07-22 02:48:20 --> Router Class Initialized
INFO - 2021-07-22 02:48:20 --> Output Class Initialized
INFO - 2021-07-22 02:48:20 --> Security Class Initialized
DEBUG - 2021-07-22 02:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 02:48:20 --> Input Class Initialized
INFO - 2021-07-22 02:48:20 --> Language Class Initialized
ERROR - 2021-07-22 02:48:20 --> 404 Page Not Found: Situacao_cadin_ecac_certificado/cron_pendencia_cadin_com_procuracao
INFO - 2021-07-22 02:49:10 --> Config Class Initialized
INFO - 2021-07-22 02:49:10 --> Hooks Class Initialized
DEBUG - 2021-07-22 02:49:10 --> UTF-8 Support Enabled
INFO - 2021-07-22 02:49:10 --> Utf8 Class Initialized
INFO - 2021-07-22 02:49:10 --> URI Class Initialized
INFO - 2021-07-22 02:49:10 --> Router Class Initialized
INFO - 2021-07-22 02:49:10 --> Output Class Initialized
INFO - 2021-07-22 02:49:10 --> Security Class Initialized
DEBUG - 2021-07-22 02:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 02:49:10 --> Input Class Initialized
INFO - 2021-07-22 02:49:10 --> Language Class Initialized
INFO - 2021-07-22 02:49:10 --> Loader Class Initialized
INFO - 2021-07-22 02:49:10 --> Helper loaded: url_helper
INFO - 2021-07-22 02:49:10 --> Helper loaded: form_helper
INFO - 2021-07-22 02:49:10 --> Helper loaded: array_helper
INFO - 2021-07-22 02:49:10 --> Helper loaded: date_helper
INFO - 2021-07-22 02:49:10 --> Helper loaded: html_helper
INFO - 2021-07-22 02:49:10 --> Database Driver Class Initialized
INFO - 2021-07-22 02:49:10 --> Controller Class Initialized
DEBUG - 2021-07-22 02:49:10 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 02:49:10 --> Model "Certificado_model" initialized
INFO - 2021-07-22 02:49:10 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-22 02:57:47 --> Config Class Initialized
INFO - 2021-07-22 02:57:47 --> Hooks Class Initialized
DEBUG - 2021-07-22 02:57:47 --> UTF-8 Support Enabled
INFO - 2021-07-22 02:57:47 --> Utf8 Class Initialized
INFO - 2021-07-22 02:57:47 --> URI Class Initialized
INFO - 2021-07-22 02:57:47 --> Router Class Initialized
INFO - 2021-07-22 02:57:47 --> Output Class Initialized
INFO - 2021-07-22 02:57:47 --> Security Class Initialized
DEBUG - 2021-07-22 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 02:57:47 --> Input Class Initialized
INFO - 2021-07-22 02:57:47 --> Language Class Initialized
INFO - 2021-07-22 02:57:47 --> Loader Class Initialized
INFO - 2021-07-22 02:57:47 --> Helper loaded: url_helper
INFO - 2021-07-22 02:57:47 --> Helper loaded: form_helper
INFO - 2021-07-22 02:57:47 --> Helper loaded: array_helper
INFO - 2021-07-22 02:57:47 --> Helper loaded: date_helper
INFO - 2021-07-22 02:57:47 --> Helper loaded: html_helper
INFO - 2021-07-22 02:57:47 --> Database Driver Class Initialized
INFO - 2021-07-22 02:57:47 --> Controller Class Initialized
DEBUG - 2021-07-22 02:57:47 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 02:57:47 --> Model "Certificado_model" initialized
INFO - 2021-07-22 02:57:47 --> Model "Eprocessos_ativos_model" initialized
INFO - 2021-07-22 02:57:47 --> Model "Eprocessos_inativos_model" initialized
INFO - 2021-07-22 02:57:47 --> Model "Eprocessos_ativos_historico_model" initialized
INFO - 2021-07-22 02:57:47 --> Model "Eprocessos_inativos_historico_model" initialized
INFO - 2021-07-22 14:45:00 --> Config Class Initialized
INFO - 2021-07-22 14:45:00 --> Hooks Class Initialized
DEBUG - 2021-07-22 14:45:00 --> UTF-8 Support Enabled
INFO - 2021-07-22 14:45:00 --> Utf8 Class Initialized
INFO - 2021-07-22 14:45:00 --> URI Class Initialized
INFO - 2021-07-22 14:45:00 --> Router Class Initialized
INFO - 2021-07-22 14:45:00 --> Output Class Initialized
INFO - 2021-07-22 14:45:00 --> Security Class Initialized
DEBUG - 2021-07-22 14:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 14:45:00 --> Input Class Initialized
INFO - 2021-07-22 14:45:00 --> Language Class Initialized
INFO - 2021-07-22 14:45:00 --> Loader Class Initialized
INFO - 2021-07-22 14:45:00 --> Helper loaded: url_helper
INFO - 2021-07-22 14:45:00 --> Helper loaded: form_helper
INFO - 2021-07-22 14:45:00 --> Helper loaded: array_helper
INFO - 2021-07-22 14:45:00 --> Helper loaded: date_helper
INFO - 2021-07-22 14:45:00 --> Helper loaded: html_helper
INFO - 2021-07-22 14:45:00 --> Database Driver Class Initialized
INFO - 2021-07-22 14:45:01 --> Controller Class Initialized
DEBUG - 2021-07-22 14:45:01 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 14:45:01 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 14:45:01 --> Model "Procuracao_model" initialized
INFO - 2021-07-22 09:45:05 --> Ecac Robo Class Initialized
INFO - 2021-07-22 09:45:30 --> Final output sent to browser
DEBUG - 2021-07-22 09:45:30 --> Total execution time: 29.4140
INFO - 2021-07-22 14:47:04 --> Config Class Initialized
INFO - 2021-07-22 14:47:04 --> Hooks Class Initialized
DEBUG - 2021-07-22 14:47:04 --> UTF-8 Support Enabled
INFO - 2021-07-22 14:47:04 --> Utf8 Class Initialized
INFO - 2021-07-22 14:47:04 --> URI Class Initialized
INFO - 2021-07-22 14:47:04 --> Router Class Initialized
INFO - 2021-07-22 14:47:04 --> Output Class Initialized
INFO - 2021-07-22 14:47:04 --> Security Class Initialized
DEBUG - 2021-07-22 14:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 14:47:04 --> Input Class Initialized
INFO - 2021-07-22 14:47:04 --> Language Class Initialized
INFO - 2021-07-22 14:47:04 --> Loader Class Initialized
INFO - 2021-07-22 14:47:04 --> Helper loaded: url_helper
INFO - 2021-07-22 14:47:04 --> Helper loaded: form_helper
INFO - 2021-07-22 14:47:04 --> Helper loaded: array_helper
INFO - 2021-07-22 14:47:04 --> Helper loaded: date_helper
INFO - 2021-07-22 14:47:04 --> Helper loaded: html_helper
INFO - 2021-07-22 14:47:04 --> Database Driver Class Initialized
INFO - 2021-07-22 14:47:04 --> Controller Class Initialized
DEBUG - 2021-07-22 14:47:04 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 14:47:04 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 14:47:04 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 09:47:08 --> Ecac Robo Class Initialized
INFO - 2021-07-22 09:47:12 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-22 09:47:12 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-22 15:04:08 --> Config Class Initialized
INFO - 2021-07-22 15:04:08 --> Hooks Class Initialized
DEBUG - 2021-07-22 15:04:08 --> UTF-8 Support Enabled
INFO - 2021-07-22 15:04:08 --> Utf8 Class Initialized
INFO - 2021-07-22 15:04:08 --> URI Class Initialized
INFO - 2021-07-22 15:04:08 --> Router Class Initialized
INFO - 2021-07-22 15:04:08 --> Output Class Initialized
INFO - 2021-07-22 15:04:08 --> Security Class Initialized
DEBUG - 2021-07-22 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 15:04:08 --> Input Class Initialized
INFO - 2021-07-22 15:04:08 --> Language Class Initialized
INFO - 2021-07-22 15:04:08 --> Loader Class Initialized
INFO - 2021-07-22 15:04:08 --> Helper loaded: url_helper
INFO - 2021-07-22 15:04:08 --> Helper loaded: form_helper
INFO - 2021-07-22 15:04:08 --> Helper loaded: array_helper
INFO - 2021-07-22 15:04:08 --> Helper loaded: date_helper
INFO - 2021-07-22 15:04:08 --> Helper loaded: html_helper
INFO - 2021-07-22 15:04:08 --> Database Driver Class Initialized
INFO - 2021-07-22 15:04:08 --> Controller Class Initialized
DEBUG - 2021-07-22 15:04:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 15:04:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 15:04:08 --> Model "Procuracao_model" initialized
INFO - 2021-07-22 10:04:12 --> Ecac Robo Class Initialized
INFO - 2021-07-22 10:04:59 --> Final output sent to browser
DEBUG - 2021-07-22 10:04:59 --> Total execution time: 51.2089
INFO - 2021-07-22 15:05:31 --> Config Class Initialized
INFO - 2021-07-22 15:05:31 --> Hooks Class Initialized
DEBUG - 2021-07-22 15:05:31 --> UTF-8 Support Enabled
INFO - 2021-07-22 15:05:31 --> Utf8 Class Initialized
INFO - 2021-07-22 15:05:31 --> URI Class Initialized
INFO - 2021-07-22 15:05:31 --> Router Class Initialized
INFO - 2021-07-22 15:05:31 --> Output Class Initialized
INFO - 2021-07-22 15:05:31 --> Security Class Initialized
DEBUG - 2021-07-22 15:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 15:05:31 --> Input Class Initialized
INFO - 2021-07-22 15:05:31 --> Language Class Initialized
INFO - 2021-07-22 15:05:31 --> Loader Class Initialized
INFO - 2021-07-22 15:05:31 --> Helper loaded: url_helper
INFO - 2021-07-22 15:05:31 --> Helper loaded: form_helper
INFO - 2021-07-22 15:05:31 --> Helper loaded: array_helper
INFO - 2021-07-22 15:05:31 --> Helper loaded: date_helper
INFO - 2021-07-22 15:05:31 --> Helper loaded: html_helper
INFO - 2021-07-22 15:05:31 --> Database Driver Class Initialized
INFO - 2021-07-22 15:05:31 --> Controller Class Initialized
DEBUG - 2021-07-22 15:05:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 15:05:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 15:05:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 10:05:34 --> Ecac Robo Class Initialized
INFO - 2021-07-22 10:06:04 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-22 10:06:04 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-22 10:07:11 --> Final output sent to browser
DEBUG - 2021-07-22 10:07:11 --> Total execution time: 1,207.8429
ERROR - 2021-07-22 10:14:43 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 381
ERROR - 2021-07-22 10:14:43 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 382
ERROR - 2021-07-22 10:24:25 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 381
ERROR - 2021-07-22 10:24:25 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 382
INFO - 2021-07-22 10:40:54 --> Final output sent to browser
DEBUG - 2021-07-22 10:40:54 --> Total execution time: 2,123.3904
INFO - 2021-07-22 15:57:45 --> Config Class Initialized
INFO - 2021-07-22 15:57:45 --> Hooks Class Initialized
DEBUG - 2021-07-22 15:57:45 --> UTF-8 Support Enabled
INFO - 2021-07-22 15:57:45 --> Utf8 Class Initialized
INFO - 2021-07-22 15:57:45 --> URI Class Initialized
INFO - 2021-07-22 15:57:45 --> Router Class Initialized
INFO - 2021-07-22 15:57:45 --> Output Class Initialized
INFO - 2021-07-22 15:57:45 --> Security Class Initialized
DEBUG - 2021-07-22 15:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 15:57:45 --> Input Class Initialized
INFO - 2021-07-22 15:57:45 --> Language Class Initialized
INFO - 2021-07-22 15:57:45 --> Loader Class Initialized
INFO - 2021-07-22 15:57:45 --> Helper loaded: url_helper
INFO - 2021-07-22 15:57:45 --> Helper loaded: form_helper
INFO - 2021-07-22 15:57:45 --> Helper loaded: array_helper
INFO - 2021-07-22 15:57:45 --> Helper loaded: date_helper
INFO - 2021-07-22 15:57:45 --> Helper loaded: html_helper
INFO - 2021-07-22 15:57:45 --> Database Driver Class Initialized
INFO - 2021-07-22 15:57:45 --> Controller Class Initialized
INFO - 2021-07-22 15:57:45 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 15:57:45 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 15:57:45 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-22 10:57:49 --> Ecac Robo Class Initialized
INFO - 2021-07-22 11:14:21 --> Final output sent to browser
DEBUG - 2021-07-22 11:14:21 --> Total execution time: 995.8193
INFO - 2021-07-22 16:30:42 --> Config Class Initialized
INFO - 2021-07-22 16:30:42 --> Hooks Class Initialized
DEBUG - 2021-07-22 16:30:42 --> UTF-8 Support Enabled
INFO - 2021-07-22 16:30:42 --> Utf8 Class Initialized
INFO - 2021-07-22 16:30:42 --> URI Class Initialized
INFO - 2021-07-22 16:30:42 --> Router Class Initialized
INFO - 2021-07-22 16:30:42 --> Output Class Initialized
INFO - 2021-07-22 16:30:42 --> Security Class Initialized
DEBUG - 2021-07-22 16:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 16:30:42 --> Input Class Initialized
INFO - 2021-07-22 16:30:42 --> Language Class Initialized
INFO - 2021-07-22 16:30:42 --> Loader Class Initialized
INFO - 2021-07-22 16:30:42 --> Helper loaded: url_helper
INFO - 2021-07-22 16:30:42 --> Helper loaded: form_helper
INFO - 2021-07-22 16:30:42 --> Helper loaded: array_helper
INFO - 2021-07-22 16:30:42 --> Helper loaded: date_helper
INFO - 2021-07-22 16:30:42 --> Helper loaded: html_helper
INFO - 2021-07-22 16:30:42 --> Database Driver Class Initialized
INFO - 2021-07-22 16:30:42 --> Controller Class Initialized
INFO - 2021-07-22 16:30:42 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 16:30:42 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 16:30:42 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-22 11:30:46 --> Ecac Robo Class Initialized
INFO - 2021-07-22 16:30:47 --> Config Class Initialized
INFO - 2021-07-22 16:30:47 --> Hooks Class Initialized
DEBUG - 2021-07-22 16:30:47 --> UTF-8 Support Enabled
INFO - 2021-07-22 16:30:47 --> Utf8 Class Initialized
INFO - 2021-07-22 16:30:47 --> URI Class Initialized
INFO - 2021-07-22 16:30:47 --> Router Class Initialized
INFO - 2021-07-22 16:30:47 --> Output Class Initialized
INFO - 2021-07-22 16:30:47 --> Security Class Initialized
DEBUG - 2021-07-22 16:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 16:30:47 --> Input Class Initialized
INFO - 2021-07-22 16:30:47 --> Language Class Initialized
INFO - 2021-07-22 16:30:47 --> Loader Class Initialized
INFO - 2021-07-22 16:30:47 --> Helper loaded: url_helper
INFO - 2021-07-22 16:30:47 --> Helper loaded: form_helper
INFO - 2021-07-22 16:30:47 --> Helper loaded: array_helper
INFO - 2021-07-22 16:30:47 --> Helper loaded: date_helper
INFO - 2021-07-22 16:30:47 --> Helper loaded: html_helper
INFO - 2021-07-22 16:30:47 --> Database Driver Class Initialized
INFO - 2021-07-22 16:30:47 --> Controller Class Initialized
DEBUG - 2021-07-22 16:30:47 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 16:30:47 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-22 16:30:47 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-22 11:30:52 --> Ecac Robo Class Initialized
INFO - 2021-07-22 11:30:59 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-22 11:30:59 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-22 11:31:04 --> Final output sent to browser
DEBUG - 2021-07-22 11:31:04 --> Total execution time: 21.4617
INFO - 2021-07-22 11:31:12 --> Final output sent to browser
DEBUG - 2021-07-22 11:31:12 --> Total execution time: 24.7124
INFO - 2021-07-22 16:51:39 --> Config Class Initialized
INFO - 2021-07-22 16:51:39 --> Hooks Class Initialized
DEBUG - 2021-07-22 16:51:39 --> UTF-8 Support Enabled
INFO - 2021-07-22 16:51:39 --> Utf8 Class Initialized
INFO - 2021-07-22 16:51:39 --> URI Class Initialized
INFO - 2021-07-22 16:51:39 --> Router Class Initialized
INFO - 2021-07-22 16:51:39 --> Output Class Initialized
INFO - 2021-07-22 16:51:39 --> Security Class Initialized
DEBUG - 2021-07-22 16:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-22 16:51:39 --> Input Class Initialized
INFO - 2021-07-22 16:51:39 --> Language Class Initialized
INFO - 2021-07-22 16:51:39 --> Loader Class Initialized
INFO - 2021-07-22 16:51:39 --> Helper loaded: url_helper
INFO - 2021-07-22 16:51:39 --> Helper loaded: form_helper
INFO - 2021-07-22 16:51:39 --> Helper loaded: array_helper
INFO - 2021-07-22 16:51:39 --> Helper loaded: date_helper
INFO - 2021-07-22 16:51:39 --> Helper loaded: html_helper
INFO - 2021-07-22 16:51:39 --> Database Driver Class Initialized
INFO - 2021-07-22 16:51:39 --> Controller Class Initialized
DEBUG - 2021-07-22 16:51:39 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-22 16:51:39 --> Model "Certificado_model" initialized
INFO - 2021-07-22 16:51:39 --> Model "Dctf_model" initialized
INFO - 2021-07-22 11:51:40 --> Final output sent to browser
DEBUG - 2021-07-22 11:51:40 --> Total execution time: 0.3658
