<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-30 14:53:05 --> Config Class Initialized
INFO - 2021-06-30 14:53:05 --> Hooks Class Initialized
DEBUG - 2021-06-30 14:53:05 --> UTF-8 Support Enabled
INFO - 2021-06-30 14:53:05 --> Utf8 Class Initialized
INFO - 2021-06-30 14:53:05 --> URI Class Initialized
INFO - 2021-06-30 14:53:05 --> Router Class Initialized
INFO - 2021-06-30 14:53:05 --> Output Class Initialized
INFO - 2021-06-30 14:53:05 --> Security Class Initialized
DEBUG - 2021-06-30 14:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 14:53:05 --> Input Class Initialized
INFO - 2021-06-30 14:53:05 --> Language Class Initialized
INFO - 2021-06-30 14:53:05 --> Loader Class Initialized
INFO - 2021-06-30 14:53:05 --> Helper loaded: url_helper
INFO - 2021-06-30 14:53:05 --> Helper loaded: form_helper
INFO - 2021-06-30 14:53:05 --> Helper loaded: array_helper
INFO - 2021-06-30 14:53:05 --> Helper loaded: date_helper
INFO - 2021-06-30 14:53:05 --> Helper loaded: html_helper
INFO - 2021-06-30 14:53:05 --> Database Driver Class Initialized
INFO - 2021-06-30 14:53:05 --> Controller Class Initialized
DEBUG - 2021-06-30 14:53:05 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-06-30 14:53:05 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-30 14:53:05 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-30 14:53:08 --> Config Class Initialized
INFO - 2021-06-30 14:53:08 --> Hooks Class Initialized
DEBUG - 2021-06-30 14:53:08 --> UTF-8 Support Enabled
INFO - 2021-06-30 14:53:08 --> Utf8 Class Initialized
INFO - 2021-06-30 14:53:08 --> URI Class Initialized
INFO - 2021-06-30 14:53:08 --> Router Class Initialized
INFO - 2021-06-30 14:53:08 --> Output Class Initialized
INFO - 2021-06-30 14:53:08 --> Security Class Initialized
DEBUG - 2021-06-30 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-30 14:53:08 --> Input Class Initialized
INFO - 2021-06-30 14:53:08 --> Language Class Initialized
INFO - 2021-06-30 14:53:08 --> Loader Class Initialized
INFO - 2021-06-30 14:53:08 --> Helper loaded: url_helper
INFO - 2021-06-30 14:53:08 --> Helper loaded: form_helper
INFO - 2021-06-30 14:53:08 --> Helper loaded: array_helper
INFO - 2021-06-30 14:53:08 --> Helper loaded: date_helper
INFO - 2021-06-30 14:53:08 --> Helper loaded: html_helper
INFO - 2021-06-30 14:53:08 --> Database Driver Class Initialized
INFO - 2021-06-30 14:53:08 --> Controller Class Initialized
DEBUG - 2021-06-30 14:53:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-06-30 14:53:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-30 14:53:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-30 09:53:09 --> Ecac Robo Class Initialized
INFO - 2021-06-30 09:53:11 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-06-30 09:53:11 --> Model "Caixa_postal_model" initialized
INFO - 2021-06-30 09:53:12 --> Ecac Robo Class Initialized
INFO - 2021-06-30 09:53:15 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-06-30 09:53:15 --> Model "Caixa_postal_model" initialized
INFO - 2021-06-30 09:56:36 --> Final output sent to browser
DEBUG - 2021-06-30 09:56:36 --> Total execution time: 210.8715
INFO - 2021-06-30 09:56:37 --> Final output sent to browser
DEBUG - 2021-06-30 09:56:37 --> Total execution time: 209.3199
