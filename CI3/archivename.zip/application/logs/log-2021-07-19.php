<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-19 03:24:37 --> Config Class Initialized
INFO - 2021-07-19 03:24:37 --> Hooks Class Initialized
DEBUG - 2021-07-19 03:24:37 --> UTF-8 Support Enabled
INFO - 2021-07-19 03:24:37 --> Utf8 Class Initialized
INFO - 2021-07-19 03:24:37 --> URI Class Initialized
INFO - 2021-07-19 03:24:37 --> Router Class Initialized
INFO - 2021-07-19 03:24:37 --> Output Class Initialized
INFO - 2021-07-19 03:24:37 --> Security Class Initialized
DEBUG - 2021-07-19 03:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 03:24:37 --> Input Class Initialized
INFO - 2021-07-19 03:24:37 --> Language Class Initialized
ERROR - 2021-07-19 03:24:37 --> 404 Page Not Found: SistemacronsCertificado/sp
INFO - 2021-07-19 03:24:48 --> Config Class Initialized
INFO - 2021-07-19 03:24:48 --> Hooks Class Initialized
DEBUG - 2021-07-19 03:24:48 --> UTF-8 Support Enabled
INFO - 2021-07-19 03:24:48 --> Utf8 Class Initialized
INFO - 2021-07-19 03:24:48 --> URI Class Initialized
INFO - 2021-07-19 03:24:48 --> Router Class Initialized
INFO - 2021-07-19 03:24:48 --> Output Class Initialized
INFO - 2021-07-19 03:24:48 --> Security Class Initialized
DEBUG - 2021-07-19 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 03:24:48 --> Input Class Initialized
INFO - 2021-07-19 03:24:48 --> Language Class Initialized
INFO - 2021-07-19 03:24:48 --> Loader Class Initialized
INFO - 2021-07-19 03:24:48 --> Helper loaded: url_helper
INFO - 2021-07-19 03:24:48 --> Helper loaded: form_helper
INFO - 2021-07-19 03:24:48 --> Helper loaded: array_helper
INFO - 2021-07-19 03:24:48 --> Helper loaded: date_helper
INFO - 2021-07-19 03:24:48 --> Helper loaded: html_helper
INFO - 2021-07-19 03:24:48 --> Database Driver Class Initialized
INFO - 2021-07-19 03:24:48 --> Controller Class Initialized
DEBUG - 2021-07-19 03:24:48 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-19 03:24:48 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 03:24:48 --> Model "Procuracao_model" initialized
INFO - 2021-07-19 13:55:13 --> Config Class Initialized
INFO - 2021-07-19 13:55:13 --> Hooks Class Initialized
DEBUG - 2021-07-19 13:55:13 --> UTF-8 Support Enabled
INFO - 2021-07-19 13:55:13 --> Utf8 Class Initialized
INFO - 2021-07-19 13:55:13 --> URI Class Initialized
INFO - 2021-07-19 13:55:13 --> Router Class Initialized
INFO - 2021-07-19 13:55:13 --> Output Class Initialized
INFO - 2021-07-19 13:55:13 --> Security Class Initialized
DEBUG - 2021-07-19 13:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 13:55:13 --> Input Class Initialized
INFO - 2021-07-19 13:55:13 --> Language Class Initialized
INFO - 2021-07-19 13:55:13 --> Loader Class Initialized
INFO - 2021-07-19 13:55:13 --> Helper loaded: url_helper
INFO - 2021-07-19 13:55:13 --> Helper loaded: form_helper
INFO - 2021-07-19 13:55:13 --> Helper loaded: array_helper
INFO - 2021-07-19 13:55:13 --> Helper loaded: date_helper
INFO - 2021-07-19 13:55:13 --> Helper loaded: html_helper
INFO - 2021-07-19 13:55:13 --> Database Driver Class Initialized
INFO - 2021-07-19 13:55:14 --> Controller Class Initialized
INFO - 2021-07-19 13:55:14 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 13:55:14 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-19 13:55:14 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-19 08:55:18 --> Ecac Robo Class Initialized
INFO - 2021-07-19 08:58:06 --> Ecac Robo Class Initialized
INFO - 2021-07-19 08:58:09 --> Final output sent to browser
DEBUG - 2021-07-19 08:58:09 --> Total execution time: 175.7281
INFO - 2021-07-19 14:26:49 --> Config Class Initialized
INFO - 2021-07-19 14:26:49 --> Hooks Class Initialized
DEBUG - 2021-07-19 14:26:49 --> UTF-8 Support Enabled
INFO - 2021-07-19 14:26:49 --> Utf8 Class Initialized
INFO - 2021-07-19 14:26:49 --> URI Class Initialized
INFO - 2021-07-19 14:26:49 --> Router Class Initialized
INFO - 2021-07-19 14:26:49 --> Output Class Initialized
INFO - 2021-07-19 14:26:49 --> Security Class Initialized
DEBUG - 2021-07-19 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 14:26:49 --> Input Class Initialized
INFO - 2021-07-19 14:26:49 --> Language Class Initialized
INFO - 2021-07-19 14:26:49 --> Loader Class Initialized
INFO - 2021-07-19 14:26:49 --> Helper loaded: url_helper
INFO - 2021-07-19 14:26:49 --> Helper loaded: form_helper
INFO - 2021-07-19 14:26:49 --> Helper loaded: array_helper
INFO - 2021-07-19 14:26:49 --> Helper loaded: date_helper
INFO - 2021-07-19 14:26:49 --> Helper loaded: html_helper
INFO - 2021-07-19 14:26:49 --> Database Driver Class Initialized
INFO - 2021-07-19 14:26:50 --> Controller Class Initialized
INFO - 2021-07-19 14:26:50 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 14:26:50 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-19 14:26:50 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-19 09:26:53 --> Ecac Robo Class Initialized
INFO - 2021-07-19 09:35:12 --> Final output sent to browser
DEBUG - 2021-07-19 09:35:12 --> Total execution time: 502.5799
INFO - 2021-07-19 14:50:35 --> Config Class Initialized
INFO - 2021-07-19 14:50:35 --> Hooks Class Initialized
DEBUG - 2021-07-19 14:50:35 --> UTF-8 Support Enabled
INFO - 2021-07-19 14:50:35 --> Utf8 Class Initialized
INFO - 2021-07-19 14:50:35 --> URI Class Initialized
INFO - 2021-07-19 14:50:35 --> Router Class Initialized
INFO - 2021-07-19 14:50:35 --> Output Class Initialized
INFO - 2021-07-19 14:50:35 --> Security Class Initialized
DEBUG - 2021-07-19 14:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 14:50:35 --> Input Class Initialized
INFO - 2021-07-19 14:50:35 --> Language Class Initialized
INFO - 2021-07-19 14:50:35 --> Loader Class Initialized
INFO - 2021-07-19 14:50:35 --> Helper loaded: url_helper
INFO - 2021-07-19 14:50:35 --> Helper loaded: form_helper
INFO - 2021-07-19 14:50:35 --> Helper loaded: array_helper
INFO - 2021-07-19 14:50:35 --> Helper loaded: date_helper
INFO - 2021-07-19 14:50:35 --> Helper loaded: html_helper
INFO - 2021-07-19 14:50:35 --> Database Driver Class Initialized
INFO - 2021-07-19 14:50:36 --> Controller Class Initialized
DEBUG - 2021-07-19 14:50:36 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-19 14:50:36 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 14:50:36 --> Model "Procuracao_model" initialized
INFO - 2021-07-19 09:50:39 --> Ecac Robo Class Initialized
INFO - 2021-07-19 09:51:50 --> Ecac Robo Class Initialized
INFO - 2021-07-19 09:54:38 --> Ecac Robo Class Initialized
INFO - 2021-07-19 09:55:01 --> Final output sent to browser
DEBUG - 2021-07-19 09:55:01 --> Total execution time: 265.5828
INFO - 2021-07-19 16:57:20 --> Config Class Initialized
INFO - 2021-07-19 16:57:20 --> Hooks Class Initialized
DEBUG - 2021-07-19 16:57:20 --> UTF-8 Support Enabled
INFO - 2021-07-19 16:57:20 --> Utf8 Class Initialized
INFO - 2021-07-19 16:57:20 --> URI Class Initialized
INFO - 2021-07-19 16:57:20 --> Router Class Initialized
INFO - 2021-07-19 16:57:20 --> Output Class Initialized
INFO - 2021-07-19 16:57:20 --> Security Class Initialized
DEBUG - 2021-07-19 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 16:57:20 --> Input Class Initialized
INFO - 2021-07-19 16:57:20 --> Language Class Initialized
INFO - 2021-07-19 16:57:20 --> Loader Class Initialized
INFO - 2021-07-19 16:57:20 --> Helper loaded: url_helper
INFO - 2021-07-19 16:57:20 --> Helper loaded: form_helper
INFO - 2021-07-19 16:57:20 --> Helper loaded: array_helper
INFO - 2021-07-19 16:57:20 --> Helper loaded: date_helper
INFO - 2021-07-19 16:57:20 --> Helper loaded: html_helper
INFO - 2021-07-19 16:57:20 --> Database Driver Class Initialized
INFO - 2021-07-19 16:57:20 --> Controller Class Initialized
DEBUG - 2021-07-19 16:57:20 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-19 16:57:20 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 16:57:20 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-19 11:57:23 --> Ecac Robo Class Initialized
INFO - 2021-07-19 11:57:30 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-19 11:57:30 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-19 12:54:06 --> Ecac Robo Class Initialized
INFO - 2021-07-19 12:54:06 --> Final output sent to browser
DEBUG - 2021-07-19 12:54:06 --> Total execution time: 3,406.3588
INFO - 2021-07-19 18:48:43 --> Config Class Initialized
INFO - 2021-07-19 18:48:43 --> Hooks Class Initialized
DEBUG - 2021-07-19 18:48:43 --> UTF-8 Support Enabled
INFO - 2021-07-19 18:48:43 --> Utf8 Class Initialized
INFO - 2021-07-19 18:48:43 --> URI Class Initialized
INFO - 2021-07-19 18:48:43 --> Router Class Initialized
INFO - 2021-07-19 18:48:43 --> Output Class Initialized
INFO - 2021-07-19 18:48:43 --> Security Class Initialized
DEBUG - 2021-07-19 18:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 18:48:43 --> Input Class Initialized
INFO - 2021-07-19 18:48:43 --> Language Class Initialized
INFO - 2021-07-19 18:48:43 --> Loader Class Initialized
INFO - 2021-07-19 18:48:43 --> Helper loaded: url_helper
INFO - 2021-07-19 18:48:43 --> Helper loaded: form_helper
INFO - 2021-07-19 18:48:43 --> Helper loaded: array_helper
INFO - 2021-07-19 18:48:43 --> Helper loaded: date_helper
INFO - 2021-07-19 18:48:43 --> Helper loaded: html_helper
INFO - 2021-07-19 18:48:43 --> Database Driver Class Initialized
INFO - 2021-07-19 18:48:43 --> Controller Class Initialized
DEBUG - 2021-07-19 18:48:43 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-19 18:48:43 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 18:48:43 --> Model "Procuracao_model" initialized
INFO - 2021-07-19 13:48:47 --> Ecac Robo Class Initialized
INFO - 2021-07-19 13:51:39 --> Ecac Robo Class Initialized
INFO - 2021-07-19 13:52:23 --> Final output sent to browser
DEBUG - 2021-07-19 13:52:23 --> Total execution time: 219.7619
INFO - 2021-07-19 19:22:18 --> Config Class Initialized
INFO - 2021-07-19 19:22:18 --> Hooks Class Initialized
DEBUG - 2021-07-19 19:22:18 --> UTF-8 Support Enabled
INFO - 2021-07-19 19:22:18 --> Utf8 Class Initialized
INFO - 2021-07-19 19:22:18 --> URI Class Initialized
INFO - 2021-07-19 19:22:18 --> Router Class Initialized
INFO - 2021-07-19 19:22:18 --> Output Class Initialized
INFO - 2021-07-19 19:22:18 --> Security Class Initialized
DEBUG - 2021-07-19 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-19 19:22:18 --> Input Class Initialized
INFO - 2021-07-19 19:22:18 --> Language Class Initialized
INFO - 2021-07-19 19:22:18 --> Loader Class Initialized
INFO - 2021-07-19 19:22:18 --> Helper loaded: url_helper
INFO - 2021-07-19 19:22:18 --> Helper loaded: form_helper
INFO - 2021-07-19 19:22:18 --> Helper loaded: array_helper
INFO - 2021-07-19 19:22:18 --> Helper loaded: date_helper
INFO - 2021-07-19 19:22:18 --> Helper loaded: html_helper
INFO - 2021-07-19 19:22:18 --> Database Driver Class Initialized
INFO - 2021-07-19 19:22:18 --> Controller Class Initialized
DEBUG - 2021-07-19 19:22:18 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-19 19:22:18 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-19 19:22:18 --> Model "Procuracao_model" initialized
INFO - 2021-07-19 14:22:22 --> Ecac Robo Class Initialized
INFO - 2021-07-19 14:22:59 --> Ecac Robo Class Initialized
INFO - 2021-07-19 14:23:22 --> Final output sent to browser
DEBUG - 2021-07-19 14:23:22 --> Total execution time: 63.8048
