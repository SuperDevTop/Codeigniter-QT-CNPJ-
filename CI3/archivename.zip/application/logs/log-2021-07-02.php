<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-02 15:51:09 --> Config Class Initialized
INFO - 2021-07-02 15:51:09 --> Hooks Class Initialized
DEBUG - 2021-07-02 15:51:09 --> UTF-8 Support Enabled
INFO - 2021-07-02 15:51:09 --> Utf8 Class Initialized
INFO - 2021-07-02 15:51:09 --> URI Class Initialized
INFO - 2021-07-02 15:51:09 --> Router Class Initialized
INFO - 2021-07-02 15:51:09 --> Output Class Initialized
INFO - 2021-07-02 15:51:09 --> Security Class Initialized
DEBUG - 2021-07-02 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 15:51:09 --> Input Class Initialized
INFO - 2021-07-02 15:51:09 --> Language Class Initialized
INFO - 2021-07-02 15:51:09 --> Loader Class Initialized
INFO - 2021-07-02 15:51:09 --> Helper loaded: url_helper
INFO - 2021-07-02 15:51:09 --> Helper loaded: form_helper
INFO - 2021-07-02 15:51:09 --> Helper loaded: array_helper
INFO - 2021-07-02 15:51:09 --> Helper loaded: date_helper
INFO - 2021-07-02 15:51:09 --> Helper loaded: html_helper
INFO - 2021-07-02 15:51:09 --> Database Driver Class Initialized
INFO - 2021-07-02 15:51:10 --> Controller Class Initialized
DEBUG - 2021-07-02 15:51:10 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 15:51:10 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 15:51:10 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 15:51:12 --> Config Class Initialized
INFO - 2021-07-02 15:51:12 --> Hooks Class Initialized
DEBUG - 2021-07-02 15:51:12 --> UTF-8 Support Enabled
INFO - 2021-07-02 15:51:12 --> Utf8 Class Initialized
INFO - 2021-07-02 15:51:12 --> URI Class Initialized
INFO - 2021-07-02 15:51:12 --> Router Class Initialized
INFO - 2021-07-02 15:51:12 --> Output Class Initialized
INFO - 2021-07-02 15:51:12 --> Security Class Initialized
DEBUG - 2021-07-02 15:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 15:51:12 --> Input Class Initialized
INFO - 2021-07-02 15:51:12 --> Language Class Initialized
INFO - 2021-07-02 15:51:12 --> Loader Class Initialized
INFO - 2021-07-02 15:51:12 --> Helper loaded: url_helper
INFO - 2021-07-02 15:51:12 --> Helper loaded: form_helper
INFO - 2021-07-02 15:51:12 --> Helper loaded: array_helper
INFO - 2021-07-02 15:51:12 --> Helper loaded: date_helper
INFO - 2021-07-02 15:51:12 --> Helper loaded: html_helper
INFO - 2021-07-02 15:51:12 --> Database Driver Class Initialized
INFO - 2021-07-02 15:51:12 --> Controller Class Initialized
DEBUG - 2021-07-02 15:51:12 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 15:51:12 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 15:51:12 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 10:51:14 --> Ecac Robo Class Initialized
INFO - 2021-07-02 10:51:16 --> Ecac Robo Class Initialized
INFO - 2021-07-02 10:51:26 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-02 10:51:30 --> Model "Situacao_fiscal_model" initialized
ERROR - 2021-07-02 10:52:19 --> Severity: error --> Exception: {
  "error": {
    "code": 400,
    "message": "Provided MD5 hash \"qjrBEI2T72pE1oudxQ6DyA==\" doesn't match calculated MD5 hash \"K/xkDHpP3PJZJheS9KtO6A==\".",
    "errors": [
      {
        "message": "Provided MD5 hash \"qjrBEI2T72pE1oudxQ6DyA==\" doesn't match calculated MD5 hash \"K/xkDHpP3PJZJheS9KtO6A==\".",
        "domain": "global",
        "reason": "invalid"
      }
    ]
  }
}
 C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-02 19:02:42 --> Config Class Initialized
INFO - 2021-07-02 19:02:42 --> Hooks Class Initialized
DEBUG - 2021-07-02 19:02:42 --> UTF-8 Support Enabled
INFO - 2021-07-02 19:02:42 --> Utf8 Class Initialized
INFO - 2021-07-02 19:02:42 --> URI Class Initialized
INFO - 2021-07-02 19:02:42 --> Router Class Initialized
INFO - 2021-07-02 19:02:42 --> Output Class Initialized
INFO - 2021-07-02 19:02:42 --> Security Class Initialized
DEBUG - 2021-07-02 19:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 19:02:42 --> Input Class Initialized
INFO - 2021-07-02 19:02:42 --> Language Class Initialized
INFO - 2021-07-02 19:02:42 --> Loader Class Initialized
INFO - 2021-07-02 19:02:42 --> Helper loaded: url_helper
INFO - 2021-07-02 19:02:42 --> Helper loaded: form_helper
INFO - 2021-07-02 19:02:42 --> Helper loaded: array_helper
INFO - 2021-07-02 19:02:42 --> Helper loaded: date_helper
INFO - 2021-07-02 19:02:42 --> Helper loaded: html_helper
INFO - 2021-07-02 19:02:42 --> Database Driver Class Initialized
INFO - 2021-07-02 19:02:42 --> Controller Class Initialized
DEBUG - 2021-07-02 19:02:42 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 19:02:42 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 19:02:42 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 19:02:42 --> Model "Das_model" initialized
INFO - 2021-07-02 14:03:06 --> Ecac Robo Class Initialized
INFO - 2021-07-02 14:03:06 --> Final output sent to browser
DEBUG - 2021-07-02 14:03:06 --> Total execution time: 24.1740
INFO - 2021-07-02 19:05:00 --> Config Class Initialized
INFO - 2021-07-02 19:05:00 --> Hooks Class Initialized
DEBUG - 2021-07-02 19:05:00 --> UTF-8 Support Enabled
INFO - 2021-07-02 19:05:00 --> Utf8 Class Initialized
INFO - 2021-07-02 19:05:00 --> URI Class Initialized
INFO - 2021-07-02 19:05:00 --> Router Class Initialized
INFO - 2021-07-02 19:05:00 --> Output Class Initialized
INFO - 2021-07-02 19:05:00 --> Security Class Initialized
DEBUG - 2021-07-02 19:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 19:05:00 --> Input Class Initialized
INFO - 2021-07-02 19:05:00 --> Language Class Initialized
INFO - 2021-07-02 19:05:00 --> Loader Class Initialized
INFO - 2021-07-02 19:05:00 --> Helper loaded: url_helper
INFO - 2021-07-02 19:05:00 --> Helper loaded: form_helper
INFO - 2021-07-02 19:05:00 --> Helper loaded: array_helper
INFO - 2021-07-02 19:05:00 --> Helper loaded: date_helper
INFO - 2021-07-02 19:05:00 --> Helper loaded: html_helper
INFO - 2021-07-02 19:05:00 --> Database Driver Class Initialized
INFO - 2021-07-02 19:05:00 --> Controller Class Initialized
DEBUG - 2021-07-02 19:05:00 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 19:05:00 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 19:05:00 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 19:05:00 --> Model "Das_model" initialized
INFO - 2021-07-02 19:05:03 --> Config Class Initialized
INFO - 2021-07-02 19:05:03 --> Hooks Class Initialized
DEBUG - 2021-07-02 19:05:03 --> UTF-8 Support Enabled
INFO - 2021-07-02 19:05:03 --> Utf8 Class Initialized
INFO - 2021-07-02 19:05:03 --> URI Class Initialized
INFO - 2021-07-02 19:05:03 --> Router Class Initialized
INFO - 2021-07-02 19:05:03 --> Output Class Initialized
INFO - 2021-07-02 19:05:03 --> Security Class Initialized
DEBUG - 2021-07-02 19:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 19:05:03 --> Input Class Initialized
INFO - 2021-07-02 19:05:03 --> Language Class Initialized
INFO - 2021-07-02 19:05:03 --> Loader Class Initialized
INFO - 2021-07-02 19:05:03 --> Helper loaded: url_helper
INFO - 2021-07-02 19:05:03 --> Helper loaded: form_helper
INFO - 2021-07-02 19:05:03 --> Helper loaded: array_helper
INFO - 2021-07-02 19:05:03 --> Helper loaded: date_helper
INFO - 2021-07-02 19:05:03 --> Helper loaded: html_helper
INFO - 2021-07-02 19:05:03 --> Database Driver Class Initialized
INFO - 2021-07-02 19:05:03 --> Controller Class Initialized
DEBUG - 2021-07-02 19:05:03 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 19:05:03 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 19:05:03 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 19:05:03 --> Model "Das_model" initialized
INFO - 2021-07-02 14:05:03 --> Ecac Robo Class Initialized
INFO - 2021-07-02 14:05:07 --> Ecac Robo Class Initialized
INFO - 2021-07-02 21:02:39 --> Config Class Initialized
INFO - 2021-07-02 21:02:39 --> Hooks Class Initialized
DEBUG - 2021-07-02 21:02:39 --> UTF-8 Support Enabled
INFO - 2021-07-02 21:02:39 --> Utf8 Class Initialized
INFO - 2021-07-02 21:02:39 --> URI Class Initialized
INFO - 2021-07-02 21:02:39 --> Router Class Initialized
INFO - 2021-07-02 21:02:39 --> Output Class Initialized
INFO - 2021-07-02 21:02:39 --> Security Class Initialized
DEBUG - 2021-07-02 21:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 21:02:39 --> Input Class Initialized
INFO - 2021-07-02 21:02:39 --> Language Class Initialized
INFO - 2021-07-02 21:02:39 --> Loader Class Initialized
INFO - 2021-07-02 21:02:39 --> Helper loaded: url_helper
INFO - 2021-07-02 21:02:39 --> Helper loaded: form_helper
INFO - 2021-07-02 21:02:39 --> Helper loaded: array_helper
INFO - 2021-07-02 21:02:39 --> Helper loaded: date_helper
INFO - 2021-07-02 21:02:39 --> Helper loaded: html_helper
INFO - 2021-07-02 21:02:39 --> Database Driver Class Initialized
INFO - 2021-07-02 21:02:39 --> Controller Class Initialized
DEBUG - 2021-07-02 21:02:39 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 21:02:39 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 21:02:39 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 21:02:39 --> Model "Dctf_model" initialized
INFO - 2021-07-02 21:02:42 --> Config Class Initialized
INFO - 2021-07-02 21:02:42 --> Hooks Class Initialized
DEBUG - 2021-07-02 21:02:42 --> UTF-8 Support Enabled
INFO - 2021-07-02 21:02:42 --> Utf8 Class Initialized
INFO - 2021-07-02 21:02:42 --> URI Class Initialized
INFO - 2021-07-02 21:02:42 --> Router Class Initialized
INFO - 2021-07-02 21:02:42 --> Output Class Initialized
INFO - 2021-07-02 21:02:42 --> Security Class Initialized
DEBUG - 2021-07-02 21:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 21:02:42 --> Input Class Initialized
INFO - 2021-07-02 21:02:42 --> Language Class Initialized
INFO - 2021-07-02 21:02:42 --> Loader Class Initialized
INFO - 2021-07-02 21:02:42 --> Helper loaded: url_helper
INFO - 2021-07-02 21:02:42 --> Helper loaded: form_helper
INFO - 2021-07-02 21:02:42 --> Helper loaded: array_helper
INFO - 2021-07-02 21:02:42 --> Helper loaded: date_helper
INFO - 2021-07-02 21:02:42 --> Helper loaded: html_helper
INFO - 2021-07-02 21:02:42 --> Database Driver Class Initialized
INFO - 2021-07-02 21:02:42 --> Controller Class Initialized
DEBUG - 2021-07-02 21:02:42 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 21:02:42 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 21:02:42 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 21:02:42 --> Model "Dctf_model" initialized
INFO - 2021-07-02 16:02:42 --> Ecac Robo Class Initialized
INFO - 2021-07-02 16:02:45 --> Ecac Robo Class Initialized
INFO - 2021-07-02 16:10:00 --> Final output sent to browser
DEBUG - 2021-07-02 16:10:00 --> Total execution time: 438.7103
INFO - 2021-07-02 21:16:29 --> Config Class Initialized
INFO - 2021-07-02 21:16:29 --> Hooks Class Initialized
DEBUG - 2021-07-02 21:16:29 --> UTF-8 Support Enabled
INFO - 2021-07-02 21:16:29 --> Utf8 Class Initialized
INFO - 2021-07-02 21:16:29 --> URI Class Initialized
INFO - 2021-07-02 21:16:29 --> Router Class Initialized
INFO - 2021-07-02 21:16:29 --> Output Class Initialized
INFO - 2021-07-02 21:16:29 --> Security Class Initialized
DEBUG - 2021-07-02 21:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 21:16:29 --> Input Class Initialized
INFO - 2021-07-02 21:16:29 --> Language Class Initialized
INFO - 2021-07-02 21:16:29 --> Loader Class Initialized
INFO - 2021-07-02 21:16:29 --> Helper loaded: url_helper
INFO - 2021-07-02 21:16:29 --> Helper loaded: form_helper
INFO - 2021-07-02 21:16:29 --> Helper loaded: array_helper
INFO - 2021-07-02 21:16:29 --> Helper loaded: date_helper
INFO - 2021-07-02 21:16:29 --> Helper loaded: html_helper
INFO - 2021-07-02 21:16:29 --> Database Driver Class Initialized
INFO - 2021-07-02 21:16:29 --> Controller Class Initialized
DEBUG - 2021-07-02 21:16:29 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 21:16:29 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 21:16:29 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-02 16:16:32 --> Ecac Robo Class Initialized
INFO - 2021-07-02 16:16:39 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-02 16:35:21 --> Final output sent to browser
DEBUG - 2021-07-02 16:35:21 --> Total execution time: 1,131.8381
INFO - 2021-07-02 23:07:12 --> Config Class Initialized
INFO - 2021-07-02 23:07:12 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:07:12 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:07:12 --> Utf8 Class Initialized
INFO - 2021-07-02 23:07:12 --> URI Class Initialized
INFO - 2021-07-02 23:07:12 --> Router Class Initialized
INFO - 2021-07-02 23:07:12 --> Output Class Initialized
INFO - 2021-07-02 23:07:12 --> Security Class Initialized
DEBUG - 2021-07-02 23:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:07:12 --> Input Class Initialized
INFO - 2021-07-02 23:07:12 --> Language Class Initialized
INFO - 2021-07-02 23:07:12 --> Loader Class Initialized
INFO - 2021-07-02 23:07:12 --> Helper loaded: url_helper
INFO - 2021-07-02 23:07:12 --> Helper loaded: form_helper
INFO - 2021-07-02 23:07:12 --> Helper loaded: array_helper
INFO - 2021-07-02 23:07:12 --> Helper loaded: date_helper
INFO - 2021-07-02 23:07:12 --> Helper loaded: html_helper
INFO - 2021-07-02 23:07:12 --> Database Driver Class Initialized
INFO - 2021-07-02 23:07:12 --> Controller Class Initialized
DEBUG - 2021-07-02 23:07:12 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:07:12 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:07:12 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:07:16 --> Ecac Robo Class Initialized
ERROR - 2021-07-02 18:07:16 --> Severity: Notice --> Undefined property: Ecac_robo_library_eprocessos_procuracao::$path_script_procuracao C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1651
INFO - 2021-07-02 18:07:16 --> Final output sent to browser
DEBUG - 2021-07-02 18:07:16 --> Total execution time: 3.7412
INFO - 2021-07-02 23:09:09 --> Config Class Initialized
INFO - 2021-07-02 23:09:09 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:09:09 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:09:09 --> Utf8 Class Initialized
INFO - 2021-07-02 23:09:09 --> URI Class Initialized
INFO - 2021-07-02 23:09:09 --> Router Class Initialized
INFO - 2021-07-02 23:09:09 --> Output Class Initialized
INFO - 2021-07-02 23:09:09 --> Security Class Initialized
DEBUG - 2021-07-02 23:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:09:09 --> Input Class Initialized
INFO - 2021-07-02 23:09:09 --> Language Class Initialized
INFO - 2021-07-02 23:09:09 --> Loader Class Initialized
INFO - 2021-07-02 23:09:09 --> Helper loaded: url_helper
INFO - 2021-07-02 23:09:09 --> Helper loaded: form_helper
INFO - 2021-07-02 23:09:09 --> Helper loaded: array_helper
INFO - 2021-07-02 23:09:09 --> Helper loaded: date_helper
INFO - 2021-07-02 23:09:09 --> Helper loaded: html_helper
INFO - 2021-07-02 23:09:09 --> Database Driver Class Initialized
INFO - 2021-07-02 23:09:09 --> Controller Class Initialized
DEBUG - 2021-07-02 23:09:09 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:09:10 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:09:10 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 23:09:12 --> Config Class Initialized
INFO - 2021-07-02 23:09:12 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:09:12 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:09:12 --> Utf8 Class Initialized
INFO - 2021-07-02 23:09:12 --> URI Class Initialized
INFO - 2021-07-02 23:09:12 --> Router Class Initialized
INFO - 2021-07-02 23:09:12 --> Output Class Initialized
INFO - 2021-07-02 23:09:12 --> Security Class Initialized
DEBUG - 2021-07-02 23:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:09:12 --> Input Class Initialized
INFO - 2021-07-02 23:09:12 --> Language Class Initialized
INFO - 2021-07-02 23:09:12 --> Loader Class Initialized
INFO - 2021-07-02 23:09:12 --> Helper loaded: url_helper
INFO - 2021-07-02 23:09:12 --> Helper loaded: form_helper
INFO - 2021-07-02 23:09:12 --> Helper loaded: array_helper
INFO - 2021-07-02 23:09:12 --> Helper loaded: date_helper
INFO - 2021-07-02 23:09:12 --> Helper loaded: html_helper
INFO - 2021-07-02 23:09:12 --> Database Driver Class Initialized
INFO - 2021-07-02 23:09:13 --> Controller Class Initialized
DEBUG - 2021-07-02 23:09:13 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:09:13 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:09:13 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:09:13 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:09:13 --> Final output sent to browser
DEBUG - 2021-07-02 18:09:13 --> Total execution time: 3.3742
INFO - 2021-07-02 18:09:16 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:09:16 --> Final output sent to browser
DEBUG - 2021-07-02 18:09:16 --> Total execution time: 3.6655
INFO - 2021-07-02 23:10:28 --> Config Class Initialized
INFO - 2021-07-02 23:10:28 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:10:28 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:10:28 --> Utf8 Class Initialized
INFO - 2021-07-02 23:10:28 --> URI Class Initialized
INFO - 2021-07-02 23:10:28 --> Router Class Initialized
INFO - 2021-07-02 23:10:28 --> Output Class Initialized
INFO - 2021-07-02 23:10:28 --> Security Class Initialized
DEBUG - 2021-07-02 23:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:10:28 --> Input Class Initialized
INFO - 2021-07-02 23:10:28 --> Language Class Initialized
INFO - 2021-07-02 23:10:28 --> Loader Class Initialized
INFO - 2021-07-02 23:10:28 --> Helper loaded: url_helper
INFO - 2021-07-02 23:10:28 --> Helper loaded: form_helper
INFO - 2021-07-02 23:10:28 --> Helper loaded: array_helper
INFO - 2021-07-02 23:10:28 --> Helper loaded: date_helper
INFO - 2021-07-02 23:10:28 --> Helper loaded: html_helper
INFO - 2021-07-02 23:10:28 --> Database Driver Class Initialized
INFO - 2021-07-02 23:10:28 --> Controller Class Initialized
DEBUG - 2021-07-02 23:10:28 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:10:28 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:10:28 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 23:10:31 --> Config Class Initialized
INFO - 2021-07-02 23:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:10:31 --> Utf8 Class Initialized
INFO - 2021-07-02 23:10:31 --> URI Class Initialized
INFO - 2021-07-02 23:10:31 --> Router Class Initialized
INFO - 2021-07-02 23:10:31 --> Output Class Initialized
INFO - 2021-07-02 23:10:31 --> Security Class Initialized
DEBUG - 2021-07-02 23:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:10:31 --> Input Class Initialized
INFO - 2021-07-02 23:10:31 --> Language Class Initialized
INFO - 2021-07-02 23:10:31 --> Loader Class Initialized
INFO - 2021-07-02 23:10:31 --> Helper loaded: url_helper
INFO - 2021-07-02 23:10:31 --> Helper loaded: form_helper
INFO - 2021-07-02 23:10:31 --> Helper loaded: array_helper
INFO - 2021-07-02 23:10:31 --> Helper loaded: date_helper
INFO - 2021-07-02 23:10:31 --> Helper loaded: html_helper
INFO - 2021-07-02 23:10:31 --> Database Driver Class Initialized
INFO - 2021-07-02 18:10:31 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:10:31 --> Final output sent to browser
DEBUG - 2021-07-02 18:10:31 --> Total execution time: 3.1440
INFO - 2021-07-02 23:10:31 --> Controller Class Initialized
DEBUG - 2021-07-02 23:10:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:10:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:10:31 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:10:34 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:10:35 --> Final output sent to browser
DEBUG - 2021-07-02 18:10:35 --> Total execution time: 3.2398
INFO - 2021-07-02 23:11:20 --> Config Class Initialized
INFO - 2021-07-02 23:11:20 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:11:20 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:11:20 --> Utf8 Class Initialized
INFO - 2021-07-02 23:11:20 --> URI Class Initialized
INFO - 2021-07-02 23:11:20 --> Router Class Initialized
INFO - 2021-07-02 23:11:20 --> Output Class Initialized
INFO - 2021-07-02 23:11:20 --> Security Class Initialized
DEBUG - 2021-07-02 23:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:11:20 --> Input Class Initialized
INFO - 2021-07-02 23:11:20 --> Language Class Initialized
INFO - 2021-07-02 23:11:20 --> Loader Class Initialized
INFO - 2021-07-02 23:11:20 --> Helper loaded: url_helper
INFO - 2021-07-02 23:11:20 --> Helper loaded: form_helper
INFO - 2021-07-02 23:11:20 --> Helper loaded: array_helper
INFO - 2021-07-02 23:11:20 --> Helper loaded: date_helper
INFO - 2021-07-02 23:11:20 --> Helper loaded: html_helper
INFO - 2021-07-02 23:11:20 --> Database Driver Class Initialized
INFO - 2021-07-02 23:11:21 --> Controller Class Initialized
DEBUG - 2021-07-02 23:11:21 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:11:21 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:11:21 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 23:11:23 --> Config Class Initialized
INFO - 2021-07-02 23:11:23 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:11:23 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:11:23 --> Utf8 Class Initialized
INFO - 2021-07-02 23:11:23 --> URI Class Initialized
INFO - 2021-07-02 23:11:23 --> Router Class Initialized
INFO - 2021-07-02 23:11:23 --> Output Class Initialized
INFO - 2021-07-02 23:11:23 --> Security Class Initialized
DEBUG - 2021-07-02 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:11:23 --> Input Class Initialized
INFO - 2021-07-02 23:11:23 --> Language Class Initialized
INFO - 2021-07-02 23:11:23 --> Loader Class Initialized
INFO - 2021-07-02 23:11:23 --> Helper loaded: url_helper
INFO - 2021-07-02 23:11:23 --> Helper loaded: form_helper
INFO - 2021-07-02 23:11:23 --> Helper loaded: array_helper
INFO - 2021-07-02 23:11:23 --> Helper loaded: date_helper
INFO - 2021-07-02 23:11:23 --> Helper loaded: html_helper
INFO - 2021-07-02 23:11:23 --> Database Driver Class Initialized
INFO - 2021-07-02 23:11:24 --> Controller Class Initialized
DEBUG - 2021-07-02 23:11:24 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:11:24 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:11:24 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:11:24 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:11:24 --> Final output sent to browser
DEBUG - 2021-07-02 18:11:24 --> Total execution time: 3.6907
INFO - 2021-07-02 18:11:27 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:11:27 --> Final output sent to browser
DEBUG - 2021-07-02 18:11:27 --> Total execution time: 3.3932
INFO - 2021-07-02 23:11:52 --> Config Class Initialized
INFO - 2021-07-02 23:11:52 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:11:52 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:11:52 --> Utf8 Class Initialized
INFO - 2021-07-02 23:11:52 --> URI Class Initialized
INFO - 2021-07-02 23:11:52 --> Router Class Initialized
INFO - 2021-07-02 23:11:52 --> Output Class Initialized
INFO - 2021-07-02 23:11:52 --> Security Class Initialized
DEBUG - 2021-07-02 23:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:11:52 --> Input Class Initialized
INFO - 2021-07-02 23:11:52 --> Language Class Initialized
INFO - 2021-07-02 23:11:52 --> Loader Class Initialized
INFO - 2021-07-02 23:11:52 --> Helper loaded: url_helper
INFO - 2021-07-02 23:11:52 --> Helper loaded: form_helper
INFO - 2021-07-02 23:11:52 --> Helper loaded: array_helper
INFO - 2021-07-02 23:11:52 --> Helper loaded: date_helper
INFO - 2021-07-02 23:11:52 --> Helper loaded: html_helper
INFO - 2021-07-02 23:11:52 --> Database Driver Class Initialized
INFO - 2021-07-02 23:11:52 --> Controller Class Initialized
DEBUG - 2021-07-02 23:11:52 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:11:52 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:11:52 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 23:11:55 --> Config Class Initialized
INFO - 2021-07-02 23:11:55 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:11:55 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:11:55 --> Utf8 Class Initialized
INFO - 2021-07-02 23:11:55 --> URI Class Initialized
INFO - 2021-07-02 23:11:55 --> Router Class Initialized
INFO - 2021-07-02 23:11:55 --> Output Class Initialized
INFO - 2021-07-02 23:11:55 --> Security Class Initialized
DEBUG - 2021-07-02 23:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:11:55 --> Input Class Initialized
INFO - 2021-07-02 23:11:55 --> Language Class Initialized
INFO - 2021-07-02 23:11:55 --> Loader Class Initialized
INFO - 2021-07-02 23:11:55 --> Helper loaded: url_helper
INFO - 2021-07-02 23:11:55 --> Helper loaded: form_helper
INFO - 2021-07-02 23:11:55 --> Helper loaded: array_helper
INFO - 2021-07-02 23:11:55 --> Helper loaded: date_helper
INFO - 2021-07-02 23:11:55 --> Helper loaded: html_helper
INFO - 2021-07-02 23:11:55 --> Database Driver Class Initialized
INFO - 2021-07-02 18:11:55 --> Ecac Robo Class Initialized
ERROR - 2021-07-02 18:11:55 --> Severity: error --> Exception: Call to undefined method Ecac_robo_library_eprocessos_procuracao::encerrars_conection() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1651
INFO - 2021-07-02 23:11:55 --> Controller Class Initialized
DEBUG - 2021-07-02 23:11:55 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:11:55 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:11:55 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:11:58 --> Ecac Robo Class Initialized
ERROR - 2021-07-02 18:11:58 --> Severity: error --> Exception: Call to undefined method Ecac_robo_library_eprocessos_procuracao::encerrars_conection() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1651
INFO - 2021-07-02 23:12:19 --> Config Class Initialized
INFO - 2021-07-02 23:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:12:19 --> Utf8 Class Initialized
INFO - 2021-07-02 23:12:19 --> URI Class Initialized
INFO - 2021-07-02 23:12:19 --> Router Class Initialized
INFO - 2021-07-02 23:12:19 --> Output Class Initialized
INFO - 2021-07-02 23:12:19 --> Security Class Initialized
DEBUG - 2021-07-02 23:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:12:19 --> Input Class Initialized
INFO - 2021-07-02 23:12:19 --> Language Class Initialized
INFO - 2021-07-02 23:12:19 --> Loader Class Initialized
INFO - 2021-07-02 23:12:19 --> Helper loaded: url_helper
INFO - 2021-07-02 23:12:19 --> Helper loaded: form_helper
INFO - 2021-07-02 23:12:19 --> Helper loaded: array_helper
INFO - 2021-07-02 23:12:19 --> Helper loaded: date_helper
INFO - 2021-07-02 23:12:19 --> Helper loaded: html_helper
INFO - 2021-07-02 23:12:19 --> Database Driver Class Initialized
INFO - 2021-07-02 23:12:19 --> Controller Class Initialized
DEBUG - 2021-07-02 23:12:19 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:12:19 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:12:19 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:12:22 --> Ecac Robo Class Initialized
INFO - 2021-07-02 23:12:22 --> Config Class Initialized
INFO - 2021-07-02 23:12:22 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:12:22 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:12:22 --> Utf8 Class Initialized
INFO - 2021-07-02 23:12:22 --> URI Class Initialized
INFO - 2021-07-02 23:12:22 --> Router Class Initialized
INFO - 2021-07-02 23:12:22 --> Output Class Initialized
INFO - 2021-07-02 23:12:22 --> Security Class Initialized
DEBUG - 2021-07-02 23:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:12:22 --> Input Class Initialized
INFO - 2021-07-02 23:12:22 --> Language Class Initialized
INFO - 2021-07-02 23:12:22 --> Loader Class Initialized
INFO - 2021-07-02 23:12:22 --> Helper loaded: url_helper
INFO - 2021-07-02 23:12:22 --> Helper loaded: form_helper
INFO - 2021-07-02 23:12:22 --> Helper loaded: array_helper
INFO - 2021-07-02 23:12:22 --> Helper loaded: date_helper
INFO - 2021-07-02 23:12:22 --> Helper loaded: html_helper
INFO - 2021-07-02 18:12:22 --> Final output sent to browser
DEBUG - 2021-07-02 18:12:22 --> Total execution time: 3.0318
INFO - 2021-07-02 23:12:22 --> Database Driver Class Initialized
INFO - 2021-07-02 23:12:22 --> Controller Class Initialized
DEBUG - 2021-07-02 23:12:22 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:12:22 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:12:22 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:12:25 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:12:25 --> Final output sent to browser
DEBUG - 2021-07-02 18:12:25 --> Total execution time: 3.0138
INFO - 2021-07-02 23:16:59 --> Config Class Initialized
INFO - 2021-07-02 23:16:59 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:16:59 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:16:59 --> Utf8 Class Initialized
INFO - 2021-07-02 23:16:59 --> URI Class Initialized
INFO - 2021-07-02 23:16:59 --> Router Class Initialized
INFO - 2021-07-02 23:16:59 --> Output Class Initialized
INFO - 2021-07-02 23:16:59 --> Security Class Initialized
DEBUG - 2021-07-02 23:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:16:59 --> Input Class Initialized
INFO - 2021-07-02 23:16:59 --> Language Class Initialized
INFO - 2021-07-02 23:16:59 --> Loader Class Initialized
INFO - 2021-07-02 23:16:59 --> Helper loaded: url_helper
INFO - 2021-07-02 23:16:59 --> Helper loaded: form_helper
INFO - 2021-07-02 23:16:59 --> Helper loaded: array_helper
INFO - 2021-07-02 23:16:59 --> Helper loaded: date_helper
INFO - 2021-07-02 23:16:59 --> Helper loaded: html_helper
INFO - 2021-07-02 23:16:59 --> Database Driver Class Initialized
INFO - 2021-07-02 23:16:59 --> Controller Class Initialized
DEBUG - 2021-07-02 23:16:59 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:16:59 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:16:59 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 23:17:02 --> Config Class Initialized
INFO - 2021-07-02 23:17:02 --> Hooks Class Initialized
DEBUG - 2021-07-02 23:17:02 --> UTF-8 Support Enabled
INFO - 2021-07-02 23:17:02 --> Utf8 Class Initialized
INFO - 2021-07-02 23:17:02 --> URI Class Initialized
INFO - 2021-07-02 23:17:02 --> Router Class Initialized
INFO - 2021-07-02 23:17:02 --> Output Class Initialized
INFO - 2021-07-02 23:17:02 --> Security Class Initialized
DEBUG - 2021-07-02 23:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 23:17:02 --> Input Class Initialized
INFO - 2021-07-02 23:17:02 --> Language Class Initialized
INFO - 2021-07-02 23:17:02 --> Loader Class Initialized
INFO - 2021-07-02 23:17:02 --> Helper loaded: url_helper
INFO - 2021-07-02 23:17:02 --> Helper loaded: form_helper
INFO - 2021-07-02 23:17:02 --> Helper loaded: array_helper
INFO - 2021-07-02 23:17:02 --> Helper loaded: date_helper
INFO - 2021-07-02 23:17:02 --> Helper loaded: html_helper
INFO - 2021-07-02 23:17:02 --> Database Driver Class Initialized
INFO - 2021-07-02 23:17:02 --> Controller Class Initialized
DEBUG - 2021-07-02 23:17:02 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-02 23:17:02 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-02 23:17:02 --> Model "Procuracao_model" initialized
INFO - 2021-07-02 18:17:02 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:17:02 --> Final output sent to browser
DEBUG - 2021-07-02 18:17:02 --> Total execution time: 3.2021
INFO - 2021-07-02 18:17:05 --> Ecac Robo Class Initialized
INFO - 2021-07-02 18:17:05 --> Final output sent to browser
DEBUG - 2021-07-02 18:17:05 --> Total execution time: 3.1942
