<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-29 14:28:30 --> Config Class Initialized
INFO - 2021-06-29 14:28:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 14:28:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 14:28:30 --> Utf8 Class Initialized
INFO - 2021-06-29 14:28:30 --> URI Class Initialized
INFO - 2021-06-29 14:28:30 --> Router Class Initialized
INFO - 2021-06-29 14:28:30 --> Output Class Initialized
INFO - 2021-06-29 14:28:30 --> Security Class Initialized
DEBUG - 2021-06-29 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 14:28:30 --> Input Class Initialized
INFO - 2021-06-29 14:28:30 --> Language Class Initialized
INFO - 2021-06-29 14:28:30 --> Loader Class Initialized
INFO - 2021-06-29 14:28:30 --> Helper loaded: url_helper
INFO - 2021-06-29 14:28:30 --> Helper loaded: form_helper
INFO - 2021-06-29 14:28:30 --> Helper loaded: array_helper
INFO - 2021-06-29 14:28:30 --> Helper loaded: date_helper
INFO - 2021-06-29 14:28:30 --> Helper loaded: html_helper
INFO - 2021-06-29 14:28:30 --> Database Driver Class Initialized
INFO - 2021-06-29 14:28:31 --> Controller Class Initialized
DEBUG - 2021-06-29 14:28:31 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 14:28:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 14:28:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 09:28:31 --> Helper loaded: googlestorage_helper
ERROR - 2021-06-29 09:28:38 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCrons\sp\application\libraries\Ecac\Ecac.php 323
INFO - 2021-06-29 19:43:17 --> Config Class Initialized
INFO - 2021-06-29 19:43:17 --> Hooks Class Initialized
DEBUG - 2021-06-29 19:43:17 --> UTF-8 Support Enabled
INFO - 2021-06-29 19:43:17 --> Utf8 Class Initialized
INFO - 2021-06-29 19:43:17 --> URI Class Initialized
INFO - 2021-06-29 19:43:17 --> Router Class Initialized
INFO - 2021-06-29 19:43:17 --> Output Class Initialized
INFO - 2021-06-29 19:43:17 --> Security Class Initialized
DEBUG - 2021-06-29 19:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 19:43:17 --> Input Class Initialized
INFO - 2021-06-29 19:43:17 --> Language Class Initialized
INFO - 2021-06-29 19:43:17 --> Loader Class Initialized
INFO - 2021-06-29 19:43:17 --> Helper loaded: url_helper
INFO - 2021-06-29 19:43:17 --> Helper loaded: form_helper
INFO - 2021-06-29 19:43:17 --> Helper loaded: array_helper
INFO - 2021-06-29 19:43:17 --> Helper loaded: date_helper
INFO - 2021-06-29 19:43:17 --> Helper loaded: html_helper
INFO - 2021-06-29 19:43:17 --> Database Driver Class Initialized
INFO - 2021-06-29 19:43:17 --> Controller Class Initialized
DEBUG - 2021-06-29 19:43:17 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 19:43:17 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 19:43:17 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 19:43:17 --> Model "Dctf_model" initialized
INFO - 2021-06-29 14:43:17 --> Helper loaded: googlestorage_helper
ERROR - 2021-06-29 14:43:25 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCrons\sp\application\libraries\Ecac\Ecac.php 323
INFO - 2021-06-29 19:45:04 --> Config Class Initialized
INFO - 2021-06-29 19:45:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 19:45:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 19:45:04 --> Utf8 Class Initialized
INFO - 2021-06-29 19:45:04 --> URI Class Initialized
INFO - 2021-06-29 19:45:04 --> Router Class Initialized
INFO - 2021-06-29 19:45:04 --> Output Class Initialized
INFO - 2021-06-29 19:45:04 --> Security Class Initialized
DEBUG - 2021-06-29 19:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 19:45:04 --> Input Class Initialized
INFO - 2021-06-29 19:45:04 --> Language Class Initialized
INFO - 2021-06-29 19:45:04 --> Loader Class Initialized
INFO - 2021-06-29 19:45:04 --> Helper loaded: url_helper
INFO - 2021-06-29 19:45:04 --> Helper loaded: form_helper
INFO - 2021-06-29 19:45:04 --> Helper loaded: array_helper
INFO - 2021-06-29 19:45:04 --> Helper loaded: date_helper
INFO - 2021-06-29 19:45:04 --> Helper loaded: html_helper
INFO - 2021-06-29 19:45:04 --> Database Driver Class Initialized
INFO - 2021-06-29 19:45:04 --> Controller Class Initialized
DEBUG - 2021-06-29 19:45:04 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 19:45:04 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 19:45:04 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 19:45:04 --> Model "Dctf_model" initialized
INFO - 2021-06-29 14:45:04 --> Helper loaded: googlestorage_helper
ERROR - 2021-06-29 14:45:04 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCrons\sp\application\libraries\Ecac\Ecac.php 324
INFO - 2021-06-29 20:06:32 --> Config Class Initialized
INFO - 2021-06-29 20:06:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 20:06:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 20:06:32 --> Utf8 Class Initialized
INFO - 2021-06-29 20:06:32 --> URI Class Initialized
INFO - 2021-06-29 20:06:32 --> Router Class Initialized
INFO - 2021-06-29 20:06:32 --> Output Class Initialized
INFO - 2021-06-29 20:06:32 --> Security Class Initialized
DEBUG - 2021-06-29 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 20:06:32 --> Input Class Initialized
INFO - 2021-06-29 20:06:32 --> Language Class Initialized
INFO - 2021-06-29 20:06:32 --> Loader Class Initialized
INFO - 2021-06-29 20:06:32 --> Helper loaded: url_helper
INFO - 2021-06-29 20:06:32 --> Helper loaded: form_helper
INFO - 2021-06-29 20:06:32 --> Helper loaded: array_helper
INFO - 2021-06-29 20:06:32 --> Helper loaded: date_helper
INFO - 2021-06-29 20:06:32 --> Helper loaded: html_helper
INFO - 2021-06-29 20:06:32 --> Database Driver Class Initialized
INFO - 2021-06-29 20:06:32 --> Controller Class Initialized
DEBUG - 2021-06-29 20:06:32 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 20:06:32 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 20:06:32 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 15:06:32 --> Helper loaded: googlestorage_helper
INFO - 2021-06-29 20:06:35 --> Config Class Initialized
INFO - 2021-06-29 20:06:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 20:06:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 20:06:35 --> Utf8 Class Initialized
INFO - 2021-06-29 20:06:35 --> URI Class Initialized
INFO - 2021-06-29 20:06:35 --> Router Class Initialized
INFO - 2021-06-29 20:06:35 --> Output Class Initialized
INFO - 2021-06-29 20:06:35 --> Security Class Initialized
DEBUG - 2021-06-29 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 20:06:35 --> Input Class Initialized
INFO - 2021-06-29 20:06:35 --> Language Class Initialized
INFO - 2021-06-29 20:06:35 --> Loader Class Initialized
INFO - 2021-06-29 20:06:35 --> Helper loaded: url_helper
INFO - 2021-06-29 20:06:35 --> Helper loaded: form_helper
INFO - 2021-06-29 20:06:35 --> Helper loaded: array_helper
INFO - 2021-06-29 20:06:35 --> Helper loaded: date_helper
INFO - 2021-06-29 20:06:35 --> Helper loaded: html_helper
INFO - 2021-06-29 20:06:35 --> Database Driver Class Initialized
INFO - 2021-06-29 20:06:35 --> Controller Class Initialized
DEBUG - 2021-06-29 20:06:35 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 20:06:35 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 20:06:35 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 15:06:35 --> Helper loaded: googlestorage_helper
INFO - 2021-06-29 15:06:35 --> Ecac Robo Class Initialized
INFO - 2021-06-29 15:06:38 --> Ecac Robo Class Initialized
INFO - 2021-06-29 15:06:49 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-06-29 15:06:49 --> Model "Caixa_postal_model" initialized
INFO - 2021-06-29 15:06:52 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-06-29 15:06:52 --> Model "Caixa_postal_model" initialized
INFO - 2021-06-29 20:10:35 --> Config Class Initialized
INFO - 2021-06-29 20:10:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 20:10:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 20:10:35 --> Utf8 Class Initialized
INFO - 2021-06-29 20:10:35 --> URI Class Initialized
INFO - 2021-06-29 20:10:35 --> Router Class Initialized
INFO - 2021-06-29 20:10:35 --> Output Class Initialized
INFO - 2021-06-29 20:10:35 --> Security Class Initialized
DEBUG - 2021-06-29 20:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 20:10:35 --> Input Class Initialized
INFO - 2021-06-29 20:10:35 --> Language Class Initialized
INFO - 2021-06-29 20:10:35 --> Loader Class Initialized
INFO - 2021-06-29 20:10:35 --> Helper loaded: url_helper
INFO - 2021-06-29 20:10:35 --> Helper loaded: form_helper
INFO - 2021-06-29 20:10:35 --> Helper loaded: array_helper
INFO - 2021-06-29 20:10:35 --> Helper loaded: date_helper
INFO - 2021-06-29 20:10:35 --> Helper loaded: html_helper
INFO - 2021-06-29 20:10:35 --> Database Driver Class Initialized
INFO - 2021-06-29 20:10:35 --> Controller Class Initialized
DEBUG - 2021-06-29 20:10:35 --> Config file loaded: C:\xampp\htdocs\SistemaCrons\sp\application\config/ecac_robo_config.php
INFO - 2021-06-29 20:10:35 --> Model "Certificadocontador_model" initialized
INFO - 2021-06-29 20:10:35 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-06-29 15:10:35 --> Helper loaded: googlestorage_helper
INFO - 2021-06-29 15:10:38 --> Ecac Robo Class Initialized
INFO - 2021-06-29 15:10:41 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-06-29 15:10:41 --> Model "Caixa_postal_model" initialized
ERROR - 2021-06-29 15:12:59 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCrons\sp\application\libraries\Ecac\Mensagem.php 108
INFO - 2021-06-29 15:14:42 --> Final output sent to browser
DEBUG - 2021-06-29 15:14:42 --> Total execution time: 247.2485
ERROR - 2021-06-29 15:22:58 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCrons\sp\application\libraries\Ecac\Ecac.php 324
ERROR - 2021-06-29 15:22:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCrons\sp\application\controllers\Mensagens_ecac_procuracao.php:43) C:\xampp\htdocs\SistemaCrons\sp\system\core\Common.php 570
