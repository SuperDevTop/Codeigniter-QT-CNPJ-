<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-21 15:50:23 --> Config Class Initialized
INFO - 2021-07-21 15:50:23 --> Hooks Class Initialized
DEBUG - 2021-07-21 15:50:23 --> UTF-8 Support Enabled
INFO - 2021-07-21 15:50:23 --> Utf8 Class Initialized
INFO - 2021-07-21 15:50:23 --> URI Class Initialized
INFO - 2021-07-21 15:50:23 --> Router Class Initialized
INFO - 2021-07-21 15:50:23 --> Output Class Initialized
INFO - 2021-07-21 15:50:23 --> Security Class Initialized
DEBUG - 2021-07-21 15:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 15:50:23 --> Input Class Initialized
INFO - 2021-07-21 15:50:23 --> Language Class Initialized
INFO - 2021-07-21 15:50:23 --> Loader Class Initialized
INFO - 2021-07-21 15:50:23 --> Helper loaded: url_helper
INFO - 2021-07-21 15:50:23 --> Helper loaded: form_helper
INFO - 2021-07-21 15:50:23 --> Helper loaded: array_helper
INFO - 2021-07-21 15:50:23 --> Helper loaded: date_helper
INFO - 2021-07-21 15:50:23 --> Helper loaded: html_helper
INFO - 2021-07-21 15:50:23 --> Database Driver Class Initialized
INFO - 2021-07-21 15:50:24 --> Controller Class Initialized
INFO - 2021-07-21 15:50:24 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 15:50:24 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 15:50:24 --> Model "Situacao_cadin_model" initialized
ERROR - 2021-07-21 10:50:24 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 362
INFO - 2021-07-21 17:19:36 --> Config Class Initialized
INFO - 2021-07-21 17:19:36 --> Hooks Class Initialized
DEBUG - 2021-07-21 17:19:36 --> UTF-8 Support Enabled
INFO - 2021-07-21 17:19:36 --> Utf8 Class Initialized
INFO - 2021-07-21 17:19:36 --> URI Class Initialized
INFO - 2021-07-21 17:19:36 --> Router Class Initialized
INFO - 2021-07-21 17:19:36 --> Output Class Initialized
INFO - 2021-07-21 17:19:36 --> Security Class Initialized
DEBUG - 2021-07-21 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 17:19:36 --> Input Class Initialized
INFO - 2021-07-21 17:19:36 --> Language Class Initialized
INFO - 2021-07-21 17:19:36 --> Loader Class Initialized
INFO - 2021-07-21 17:19:36 --> Helper loaded: url_helper
INFO - 2021-07-21 17:19:36 --> Helper loaded: form_helper
INFO - 2021-07-21 17:19:36 --> Helper loaded: array_helper
INFO - 2021-07-21 17:19:36 --> Helper loaded: date_helper
INFO - 2021-07-21 17:19:36 --> Helper loaded: html_helper
INFO - 2021-07-21 17:19:36 --> Database Driver Class Initialized
INFO - 2021-07-21 17:19:36 --> Controller Class Initialized
INFO - 2021-07-21 17:19:36 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 17:19:36 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 17:19:36 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-21 12:19:40 --> Ecac Robo Class Initialized
INFO - 2021-07-21 12:34:11 --> Ecac Robo Class Initialized
INFO - 2021-07-21 12:38:49 --> Ecac Robo Class Initialized
INFO - 2021-07-21 12:39:45 --> Final output sent to browser
DEBUG - 2021-07-21 12:39:45 --> Total execution time: 1,208.8401
INFO - 2021-07-21 19:25:07 --> Config Class Initialized
INFO - 2021-07-21 19:25:07 --> Hooks Class Initialized
DEBUG - 2021-07-21 19:25:07 --> UTF-8 Support Enabled
INFO - 2021-07-21 19:25:07 --> Utf8 Class Initialized
INFO - 2021-07-21 19:25:07 --> URI Class Initialized
INFO - 2021-07-21 19:25:07 --> Router Class Initialized
INFO - 2021-07-21 19:25:07 --> Output Class Initialized
INFO - 2021-07-21 19:25:07 --> Security Class Initialized
DEBUG - 2021-07-21 19:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 19:25:07 --> Input Class Initialized
INFO - 2021-07-21 19:25:07 --> Language Class Initialized
INFO - 2021-07-21 19:25:07 --> Loader Class Initialized
INFO - 2021-07-21 19:25:07 --> Helper loaded: url_helper
INFO - 2021-07-21 19:25:07 --> Helper loaded: form_helper
INFO - 2021-07-21 19:25:07 --> Helper loaded: array_helper
INFO - 2021-07-21 19:25:07 --> Helper loaded: date_helper
INFO - 2021-07-21 19:25:07 --> Helper loaded: html_helper
INFO - 2021-07-21 19:25:07 --> Database Driver Class Initialized
INFO - 2021-07-21 19:25:07 --> Controller Class Initialized
DEBUG - 2021-07-21 19:25:07 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 19:25:07 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 19:25:07 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 19:25:07 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-21 14:25:12 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:37:26 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:37:58 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:45:07 --> Final output sent to browser
DEBUG - 2021-07-21 14:45:07 --> Total execution time: 1,200.4130
INFO - 2021-07-21 19:45:47 --> Config Class Initialized
INFO - 2021-07-21 19:45:47 --> Hooks Class Initialized
DEBUG - 2021-07-21 19:45:47 --> UTF-8 Support Enabled
INFO - 2021-07-21 19:45:47 --> Utf8 Class Initialized
INFO - 2021-07-21 19:45:47 --> URI Class Initialized
INFO - 2021-07-21 19:45:47 --> Router Class Initialized
INFO - 2021-07-21 19:45:47 --> Output Class Initialized
INFO - 2021-07-21 19:45:47 --> Security Class Initialized
DEBUG - 2021-07-21 19:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 19:45:47 --> Input Class Initialized
INFO - 2021-07-21 19:45:47 --> Language Class Initialized
INFO - 2021-07-21 19:45:47 --> Loader Class Initialized
INFO - 2021-07-21 19:45:47 --> Helper loaded: url_helper
INFO - 2021-07-21 19:45:47 --> Helper loaded: form_helper
INFO - 2021-07-21 19:45:47 --> Helper loaded: array_helper
INFO - 2021-07-21 19:45:47 --> Helper loaded: date_helper
INFO - 2021-07-21 19:45:47 --> Helper loaded: html_helper
INFO - 2021-07-21 19:45:47 --> Database Driver Class Initialized
INFO - 2021-07-21 19:45:47 --> Controller Class Initialized
DEBUG - 2021-07-21 19:45:47 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 19:45:47 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 19:45:47 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 19:45:47 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-21 14:45:50 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:50:52 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:51:13 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:52:21 --> Final output sent to browser
DEBUG - 2021-07-21 14:52:21 --> Total execution time: 394.4802
INFO - 2021-07-21 19:52:33 --> Config Class Initialized
INFO - 2021-07-21 19:52:33 --> Hooks Class Initialized
DEBUG - 2021-07-21 19:52:33 --> UTF-8 Support Enabled
INFO - 2021-07-21 19:52:33 --> Utf8 Class Initialized
INFO - 2021-07-21 19:52:33 --> URI Class Initialized
INFO - 2021-07-21 19:52:33 --> Router Class Initialized
INFO - 2021-07-21 19:52:33 --> Output Class Initialized
INFO - 2021-07-21 19:52:33 --> Security Class Initialized
DEBUG - 2021-07-21 19:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 19:52:33 --> Input Class Initialized
INFO - 2021-07-21 19:52:33 --> Language Class Initialized
INFO - 2021-07-21 19:52:33 --> Loader Class Initialized
INFO - 2021-07-21 19:52:33 --> Helper loaded: url_helper
INFO - 2021-07-21 19:52:33 --> Helper loaded: form_helper
INFO - 2021-07-21 19:52:33 --> Helper loaded: array_helper
INFO - 2021-07-21 19:52:33 --> Helper loaded: date_helper
INFO - 2021-07-21 19:52:33 --> Helper loaded: html_helper
INFO - 2021-07-21 19:52:33 --> Database Driver Class Initialized
INFO - 2021-07-21 19:52:33 --> Controller Class Initialized
DEBUG - 2021-07-21 19:52:33 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 19:52:33 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 19:52:33 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 19:52:33 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-21 14:52:37 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:52:41 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:52:44 --> Ecac Robo Class Initialized
INFO - 2021-07-21 14:52:44 --> Final output sent to browser
DEBUG - 2021-07-21 14:52:44 --> Total execution time: 11.1310
INFO - 2021-07-21 22:05:16 --> Config Class Initialized
INFO - 2021-07-21 22:05:16 --> Hooks Class Initialized
DEBUG - 2021-07-21 22:05:16 --> UTF-8 Support Enabled
INFO - 2021-07-21 22:05:16 --> Utf8 Class Initialized
INFO - 2021-07-21 22:05:16 --> URI Class Initialized
INFO - 2021-07-21 22:05:16 --> Router Class Initialized
INFO - 2021-07-21 22:05:16 --> Output Class Initialized
INFO - 2021-07-21 22:05:16 --> Security Class Initialized
DEBUG - 2021-07-21 22:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 22:05:16 --> Input Class Initialized
INFO - 2021-07-21 22:05:16 --> Language Class Initialized
INFO - 2021-07-21 22:05:16 --> Loader Class Initialized
INFO - 2021-07-21 22:05:16 --> Helper loaded: url_helper
INFO - 2021-07-21 22:05:16 --> Helper loaded: form_helper
INFO - 2021-07-21 22:05:16 --> Helper loaded: array_helper
INFO - 2021-07-21 22:05:16 --> Helper loaded: date_helper
INFO - 2021-07-21 22:05:16 --> Helper loaded: html_helper
INFO - 2021-07-21 22:05:16 --> Database Driver Class Initialized
INFO - 2021-07-21 22:05:16 --> Controller Class Initialized
DEBUG - 2021-07-21 22:05:16 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 22:05:16 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 22:05:16 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 17:05:20 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:05:42 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-21 17:07:37 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:13:28 --> Final output sent to browser
DEBUG - 2021-07-21 17:13:28 --> Total execution time: 491.9508
INFO - 2021-07-21 22:13:34 --> Config Class Initialized
INFO - 2021-07-21 22:13:34 --> Hooks Class Initialized
DEBUG - 2021-07-21 22:13:34 --> UTF-8 Support Enabled
INFO - 2021-07-21 22:13:34 --> Utf8 Class Initialized
INFO - 2021-07-21 22:13:34 --> URI Class Initialized
INFO - 2021-07-21 22:13:34 --> Router Class Initialized
INFO - 2021-07-21 22:13:34 --> Output Class Initialized
INFO - 2021-07-21 22:13:34 --> Security Class Initialized
DEBUG - 2021-07-21 22:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 22:13:34 --> Input Class Initialized
INFO - 2021-07-21 22:13:34 --> Language Class Initialized
INFO - 2021-07-21 22:13:34 --> Loader Class Initialized
INFO - 2021-07-21 22:13:34 --> Helper loaded: url_helper
INFO - 2021-07-21 22:13:34 --> Helper loaded: form_helper
INFO - 2021-07-21 22:13:34 --> Helper loaded: array_helper
INFO - 2021-07-21 22:13:34 --> Helper loaded: date_helper
INFO - 2021-07-21 22:13:34 --> Helper loaded: html_helper
INFO - 2021-07-21 22:13:34 --> Database Driver Class Initialized
INFO - 2021-07-21 22:13:34 --> Controller Class Initialized
DEBUG - 2021-07-21 22:13:34 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 22:13:34 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 22:13:34 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-21 17:13:38 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:13:50 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-21 17:29:30 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:29:30 --> Final output sent to browser
DEBUG - 2021-07-21 17:29:30 --> Total execution time: 956.6872
INFO - 2021-07-21 22:52:47 --> Config Class Initialized
INFO - 2021-07-21 22:52:47 --> Hooks Class Initialized
DEBUG - 2021-07-21 22:52:47 --> UTF-8 Support Enabled
INFO - 2021-07-21 22:52:47 --> Utf8 Class Initialized
INFO - 2021-07-21 22:52:47 --> URI Class Initialized
INFO - 2021-07-21 22:52:47 --> Router Class Initialized
INFO - 2021-07-21 22:52:47 --> Output Class Initialized
INFO - 2021-07-21 22:52:47 --> Security Class Initialized
DEBUG - 2021-07-21 22:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-21 22:52:47 --> Input Class Initialized
INFO - 2021-07-21 22:52:47 --> Language Class Initialized
INFO - 2021-07-21 22:52:47 --> Loader Class Initialized
INFO - 2021-07-21 22:52:47 --> Helper loaded: url_helper
INFO - 2021-07-21 22:52:47 --> Helper loaded: form_helper
INFO - 2021-07-21 22:52:47 --> Helper loaded: array_helper
INFO - 2021-07-21 22:52:47 --> Helper loaded: date_helper
INFO - 2021-07-21 22:52:47 --> Helper loaded: html_helper
INFO - 2021-07-21 22:52:47 --> Database Driver Class Initialized
INFO - 2021-07-21 22:52:47 --> Controller Class Initialized
DEBUG - 2021-07-21 22:52:47 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-21 22:52:47 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-21 22:52:47 --> Model "Procuracao_model" initialized
INFO - 2021-07-21 17:52:51 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:53:21 --> Ecac Robo Class Initialized
INFO - 2021-07-21 17:53:47 --> Final output sent to browser
DEBUG - 2021-07-21 17:53:47 --> Total execution time: 59.7646
INFO - 2021-07-21 19:31:21 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:31:24 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:31:28 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:31:34 --> Ecac Robo Class Initialized
ERROR - 2021-07-21 19:37:55 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
INFO - 2021-07-21 19:39:54 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:39:59 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:40:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:40:08 --> Ecac Robo Class Initialized
INFO - 2021-07-21 19:53:18 --> Final output sent to browser
DEBUG - 2021-07-21 19:53:18 --> Total execution time: 810.1348
INFO - 2021-07-21 19:57:49 --> Ecac Robo Class Initialized
INFO - 2021-07-21 20:13:21 --> Final output sent to browser
DEBUG - 2021-07-21 20:13:21 --> Total execution time: 935.1671
INFO - 2021-07-21 21:49:20 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:49:26 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:49:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:49:38 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:00 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:13 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:18 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:23 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:27 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:37 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:41 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:49 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:53 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:50:59 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:07 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:14 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:19 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:23 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:29 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:36 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:43 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:51 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:51:57 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:02 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:06 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:13 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:18 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:22 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:27 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:37 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:42 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:47 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:52:51 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:01 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:05 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:11 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:19 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:23 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:29 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:33 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:38 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:42 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:47 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:53 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:53:58 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:03 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:08 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:13 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:18 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:22 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:27 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:33 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:39 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:43 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:47 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:52 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:54:56 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:20 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:25 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:30 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:44 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:50 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:54 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:55:58 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:09 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:14 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:18 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:22 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:37 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:42 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:48 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:54 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:56:58 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:13 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:22 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:28 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:38 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:43 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:57:57 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:02 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:07 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-21 21:58:07 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-21 21:58:09 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:12 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:15 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:23 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:26 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:27 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:58:27 --> Final output sent to browser
DEBUG - 2021-07-21 21:58:27 --> Total execution time: 557.4610
INFO - 2021-07-21 21:58:59 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:59:11 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:59:43 --> Ecac Robo Class Initialized
INFO - 2021-07-21 21:59:56 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:00:06 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:00:15 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:00:54 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:01:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:02:55 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:03:40 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:03:52 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:04:06 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:04:22 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:05:19 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:05:35 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:05:54 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:06:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:06:24 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:06:38 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:06:52 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:07:11 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:07:28 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:07:45 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:08:02 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:08:16 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:08:42 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:09:06 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:09:23 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:10:19 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:10:45 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:11:07 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:11:18 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:11:28 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:12:03 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:12:34 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:12:51 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:13:07 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:13:24 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:13:52 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:14:03 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:14:17 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:14:28 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:14:47 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:15:03 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:15:40 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:16:04 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:16:24 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:16:45 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:16:51 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:17:01 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:17:10 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:17:20 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:17:40 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:17:46 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:18:02 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:18:15 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:18:32 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:18:56 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:19:30 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:20:00 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:20:06 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:20:24 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:20:40 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:20:47 --> Ecac Robo Class Initialized
INFO - 2021-07-21 22:21:06 --> Ecac Robo Class Initialized
ERROR - 2021-07-21 22:21:30 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Simple_html_dom.php 1582
ERROR - 2021-07-21 22:21:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Mensagens_ecac_certificado.php:71) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
