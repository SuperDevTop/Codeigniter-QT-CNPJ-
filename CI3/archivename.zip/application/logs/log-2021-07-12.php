<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-12 16:42:34 --> Config Class Initialized
INFO - 2021-07-12 16:42:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:42:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:42:34 --> Utf8 Class Initialized
INFO - 2021-07-12 16:42:34 --> URI Class Initialized
INFO - 2021-07-12 16:42:34 --> Router Class Initialized
INFO - 2021-07-12 16:42:34 --> Output Class Initialized
INFO - 2021-07-12 16:42:34 --> Security Class Initialized
DEBUG - 2021-07-12 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:42:34 --> Input Class Initialized
INFO - 2021-07-12 16:42:34 --> Language Class Initialized
INFO - 2021-07-12 16:42:34 --> Loader Class Initialized
INFO - 2021-07-12 16:42:34 --> Helper loaded: url_helper
INFO - 2021-07-12 16:42:34 --> Helper loaded: form_helper
INFO - 2021-07-12 16:42:34 --> Helper loaded: array_helper
INFO - 2021-07-12 16:42:34 --> Helper loaded: date_helper
INFO - 2021-07-12 16:42:34 --> Helper loaded: html_helper
INFO - 2021-07-12 16:42:34 --> Database Driver Class Initialized
INFO - 2021-07-12 16:42:34 --> Controller Class Initialized
DEBUG - 2021-07-12 16:42:34 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-12 16:42:34 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-12 16:42:34 --> Model "Procuracao_model" initialized
INFO - 2021-07-12 11:42:38 --> Ecac Robo Class Initialized
INFO - 2021-07-12 11:43:22 --> Final output sent to browser
DEBUG - 2021-07-12 11:43:22 --> Total execution time: 48.8702
