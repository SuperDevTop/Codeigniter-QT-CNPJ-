<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-05 16:34:52 --> Config Class Initialized
INFO - 2021-07-05 16:34:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 16:34:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 16:34:52 --> Utf8 Class Initialized
INFO - 2021-07-05 16:34:52 --> URI Class Initialized
INFO - 2021-07-05 16:34:52 --> Router Class Initialized
INFO - 2021-07-05 16:34:52 --> Output Class Initialized
INFO - 2021-07-05 16:34:52 --> Security Class Initialized
DEBUG - 2021-07-05 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 16:34:52 --> Input Class Initialized
INFO - 2021-07-05 16:34:52 --> Language Class Initialized
INFO - 2021-07-05 16:34:52 --> Loader Class Initialized
INFO - 2021-07-05 16:34:52 --> Helper loaded: url_helper
INFO - 2021-07-05 16:34:52 --> Helper loaded: form_helper
INFO - 2021-07-05 16:34:52 --> Helper loaded: array_helper
INFO - 2021-07-05 16:34:52 --> Helper loaded: date_helper
INFO - 2021-07-05 16:34:52 --> Helper loaded: html_helper
INFO - 2021-07-05 16:34:52 --> Database Driver Class Initialized
INFO - 2021-07-05 16:34:52 --> Controller Class Initialized
DEBUG - 2021-07-05 16:34:52 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 16:34:52 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 16:34:52 --> Model "Procuracao_model" initialized
INFO - 2021-07-05 16:34:55 --> Config Class Initialized
INFO - 2021-07-05 16:34:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 16:34:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 16:34:55 --> Utf8 Class Initialized
INFO - 2021-07-05 16:34:55 --> URI Class Initialized
INFO - 2021-07-05 16:34:55 --> Router Class Initialized
INFO - 2021-07-05 16:34:55 --> Output Class Initialized
INFO - 2021-07-05 16:34:55 --> Security Class Initialized
DEBUG - 2021-07-05 16:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 16:34:55 --> Input Class Initialized
INFO - 2021-07-05 16:34:55 --> Language Class Initialized
INFO - 2021-07-05 16:34:55 --> Loader Class Initialized
INFO - 2021-07-05 16:34:55 --> Helper loaded: url_helper
INFO - 2021-07-05 16:34:55 --> Helper loaded: form_helper
INFO - 2021-07-05 16:34:55 --> Helper loaded: array_helper
INFO - 2021-07-05 16:34:55 --> Helper loaded: date_helper
INFO - 2021-07-05 16:34:55 --> Helper loaded: html_helper
INFO - 2021-07-05 16:34:55 --> Database Driver Class Initialized
INFO - 2021-07-05 16:34:55 --> Controller Class Initialized
DEBUG - 2021-07-05 16:34:55 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 16:34:55 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 16:34:55 --> Model "Procuracao_model" initialized
INFO - 2021-07-05 11:34:57 --> Ecac Robo Class Initialized
INFO - 2021-07-05 11:34:59 --> Ecac Robo Class Initialized
INFO - 2021-07-05 16:37:26 --> Config Class Initialized
INFO - 2021-07-05 16:37:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 16:37:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 16:37:26 --> Utf8 Class Initialized
INFO - 2021-07-05 16:37:26 --> URI Class Initialized
INFO - 2021-07-05 16:37:26 --> Router Class Initialized
INFO - 2021-07-05 16:37:26 --> Output Class Initialized
INFO - 2021-07-05 16:37:26 --> Security Class Initialized
DEBUG - 2021-07-05 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 16:37:26 --> Input Class Initialized
INFO - 2021-07-05 16:37:26 --> Language Class Initialized
INFO - 2021-07-05 16:37:26 --> Loader Class Initialized
INFO - 2021-07-05 16:37:26 --> Helper loaded: url_helper
INFO - 2021-07-05 16:37:26 --> Helper loaded: form_helper
INFO - 2021-07-05 16:37:26 --> Helper loaded: array_helper
INFO - 2021-07-05 16:37:26 --> Helper loaded: date_helper
INFO - 2021-07-05 16:37:26 --> Helper loaded: html_helper
INFO - 2021-07-05 16:37:26 --> Database Driver Class Initialized
INFO - 2021-07-05 16:37:26 --> Controller Class Initialized
DEBUG - 2021-07-05 16:37:26 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 16:37:26 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 16:37:26 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-05 16:37:26 --> Model "Das_model" initialized
INFO - 2021-07-05 16:37:29 --> Config Class Initialized
INFO - 2021-07-05 16:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 16:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 16:37:29 --> Utf8 Class Initialized
INFO - 2021-07-05 16:37:29 --> URI Class Initialized
INFO - 2021-07-05 16:37:29 --> Router Class Initialized
INFO - 2021-07-05 16:37:29 --> Output Class Initialized
INFO - 2021-07-05 16:37:29 --> Security Class Initialized
DEBUG - 2021-07-05 16:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 16:37:29 --> Input Class Initialized
INFO - 2021-07-05 16:37:29 --> Language Class Initialized
INFO - 2021-07-05 16:37:29 --> Loader Class Initialized
INFO - 2021-07-05 16:37:29 --> Helper loaded: url_helper
INFO - 2021-07-05 16:37:29 --> Helper loaded: form_helper
INFO - 2021-07-05 16:37:29 --> Helper loaded: array_helper
INFO - 2021-07-05 16:37:29 --> Helper loaded: date_helper
INFO - 2021-07-05 16:37:29 --> Helper loaded: html_helper
INFO - 2021-07-05 16:37:29 --> Database Driver Class Initialized
INFO - 2021-07-05 16:37:29 --> Controller Class Initialized
DEBUG - 2021-07-05 16:37:29 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 16:37:29 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 16:37:29 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-05 16:37:29 --> Model "Das_model" initialized
INFO - 2021-07-05 11:37:30 --> Ecac Robo Class Initialized
INFO - 2021-07-05 11:37:33 --> Ecac Robo Class Initialized
INFO - 2021-07-05 16:39:57 --> Config Class Initialized
INFO - 2021-07-05 16:39:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 16:39:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 16:39:57 --> Utf8 Class Initialized
INFO - 2021-07-05 16:39:57 --> URI Class Initialized
INFO - 2021-07-05 16:39:57 --> Router Class Initialized
INFO - 2021-07-05 16:39:57 --> Output Class Initialized
INFO - 2021-07-05 16:39:57 --> Security Class Initialized
DEBUG - 2021-07-05 16:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 16:39:57 --> Input Class Initialized
INFO - 2021-07-05 16:39:57 --> Language Class Initialized
INFO - 2021-07-05 16:39:57 --> Loader Class Initialized
INFO - 2021-07-05 16:39:57 --> Helper loaded: url_helper
INFO - 2021-07-05 16:39:57 --> Helper loaded: form_helper
INFO - 2021-07-05 16:39:57 --> Helper loaded: array_helper
INFO - 2021-07-05 16:39:57 --> Helper loaded: date_helper
INFO - 2021-07-05 16:39:57 --> Helper loaded: html_helper
INFO - 2021-07-05 16:39:57 --> Database Driver Class Initialized
INFO - 2021-07-05 16:39:57 --> Controller Class Initialized
DEBUG - 2021-07-05 16:39:57 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 16:39:57 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 16:39:57 --> Model "Procuracao_model" initialized
INFO - 2021-07-05 11:40:01 --> Ecac Robo Class Initialized
INFO - 2021-07-05 11:40:15 --> Final output sent to browser
DEBUG - 2021-07-05 11:40:15 --> Total execution time: 18.7203
INFO - 2021-07-05 23:54:26 --> Config Class Initialized
INFO - 2021-07-05 23:54:26 --> Hooks Class Initialized
DEBUG - 2021-07-05 23:54:26 --> UTF-8 Support Enabled
INFO - 2021-07-05 23:54:26 --> Utf8 Class Initialized
INFO - 2021-07-05 23:54:26 --> URI Class Initialized
INFO - 2021-07-05 23:54:26 --> Router Class Initialized
INFO - 2021-07-05 23:54:26 --> Output Class Initialized
INFO - 2021-07-05 23:54:26 --> Security Class Initialized
DEBUG - 2021-07-05 23:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 23:54:26 --> Input Class Initialized
INFO - 2021-07-05 23:54:26 --> Language Class Initialized
INFO - 2021-07-05 23:54:26 --> Loader Class Initialized
INFO - 2021-07-05 23:54:26 --> Helper loaded: url_helper
INFO - 2021-07-05 23:54:26 --> Helper loaded: form_helper
INFO - 2021-07-05 23:54:26 --> Helper loaded: array_helper
INFO - 2021-07-05 23:54:26 --> Helper loaded: date_helper
INFO - 2021-07-05 23:54:26 --> Helper loaded: html_helper
INFO - 2021-07-05 23:54:26 --> Database Driver Class Initialized
INFO - 2021-07-05 23:54:26 --> Controller Class Initialized
DEBUG - 2021-07-05 23:54:26 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-05 23:54:26 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-05 23:54:26 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-05 18:54:30 --> Ecac Robo Class Initialized
INFO - 2021-07-05 18:54:38 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-05 18:54:38 --> Model "Caixa_postal_model" initialized
ERROR - 2021-07-05 19:07:16 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 381
ERROR - 2021-07-05 19:07:16 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 382
ERROR - 2021-07-05 19:12:33 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 381
ERROR - 2021-07-05 19:12:33 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 382
INFO - 2021-07-05 19:15:19 --> Final output sent to browser
DEBUG - 2021-07-05 19:15:19 --> Total execution time: 1,253.5690
