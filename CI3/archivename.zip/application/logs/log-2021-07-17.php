<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-17 00:25:07 --> Config Class Initialized
INFO - 2021-07-17 00:25:07 --> Hooks Class Initialized
DEBUG - 2021-07-17 00:25:07 --> UTF-8 Support Enabled
INFO - 2021-07-17 00:25:07 --> Utf8 Class Initialized
INFO - 2021-07-17 00:25:07 --> URI Class Initialized
INFO - 2021-07-17 00:25:08 --> Router Class Initialized
INFO - 2021-07-17 00:25:08 --> Output Class Initialized
INFO - 2021-07-17 00:25:08 --> Security Class Initialized
DEBUG - 2021-07-17 00:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 00:25:08 --> Input Class Initialized
INFO - 2021-07-17 00:25:08 --> Language Class Initialized
INFO - 2021-07-17 00:25:08 --> Loader Class Initialized
INFO - 2021-07-17 00:25:08 --> Helper loaded: url_helper
INFO - 2021-07-17 00:25:08 --> Helper loaded: form_helper
INFO - 2021-07-17 00:25:08 --> Helper loaded: array_helper
INFO - 2021-07-17 00:25:08 --> Helper loaded: date_helper
INFO - 2021-07-17 00:25:08 --> Helper loaded: html_helper
INFO - 2021-07-17 00:25:08 --> Database Driver Class Initialized
INFO - 2021-07-17 00:25:08 --> Controller Class Initialized
DEBUG - 2021-07-17 00:25:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 00:25:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 00:25:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 01:10:50 --> Config Class Initialized
INFO - 2021-07-17 01:10:50 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:10:50 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:10:50 --> Utf8 Class Initialized
INFO - 2021-07-17 01:10:50 --> URI Class Initialized
INFO - 2021-07-17 01:10:50 --> Router Class Initialized
INFO - 2021-07-17 01:10:50 --> Output Class Initialized
INFO - 2021-07-17 01:10:50 --> Security Class Initialized
DEBUG - 2021-07-17 01:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:10:50 --> Input Class Initialized
INFO - 2021-07-17 01:10:50 --> Language Class Initialized
INFO - 2021-07-17 01:10:50 --> Loader Class Initialized
INFO - 2021-07-17 01:10:50 --> Helper loaded: url_helper
INFO - 2021-07-17 01:10:50 --> Helper loaded: form_helper
INFO - 2021-07-17 01:10:50 --> Helper loaded: array_helper
INFO - 2021-07-17 01:10:50 --> Helper loaded: date_helper
INFO - 2021-07-17 01:10:50 --> Helper loaded: html_helper
INFO - 2021-07-17 01:10:50 --> Database Driver Class Initialized
INFO - 2021-07-17 01:10:50 --> Controller Class Initialized
DEBUG - 2021-07-17 01:10:50 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 01:10:50 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 01:10:50 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 01:22:38 --> Config Class Initialized
INFO - 2021-07-17 01:22:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:22:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:22:38 --> Utf8 Class Initialized
INFO - 2021-07-17 01:22:38 --> URI Class Initialized
INFO - 2021-07-17 01:22:38 --> Router Class Initialized
INFO - 2021-07-17 01:22:38 --> Output Class Initialized
INFO - 2021-07-17 01:22:38 --> Security Class Initialized
DEBUG - 2021-07-17 01:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:22:38 --> Input Class Initialized
INFO - 2021-07-17 01:22:38 --> Language Class Initialized
INFO - 2021-07-17 01:22:38 --> Loader Class Initialized
INFO - 2021-07-17 01:22:38 --> Helper loaded: url_helper
INFO - 2021-07-17 01:22:38 --> Helper loaded: form_helper
INFO - 2021-07-17 01:22:38 --> Helper loaded: array_helper
INFO - 2021-07-17 01:22:38 --> Helper loaded: date_helper
INFO - 2021-07-17 01:22:38 --> Helper loaded: html_helper
INFO - 2021-07-17 01:22:38 --> Database Driver Class Initialized
INFO - 2021-07-17 01:22:38 --> Controller Class Initialized
DEBUG - 2021-07-17 01:22:38 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 01:22:38 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 01:22:38 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 01:36:18 --> Config Class Initialized
INFO - 2021-07-17 01:36:18 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:36:18 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:36:18 --> Utf8 Class Initialized
INFO - 2021-07-17 01:36:18 --> URI Class Initialized
INFO - 2021-07-17 01:36:18 --> Router Class Initialized
INFO - 2021-07-17 01:36:18 --> Output Class Initialized
INFO - 2021-07-17 01:36:18 --> Security Class Initialized
DEBUG - 2021-07-17 01:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:36:18 --> Input Class Initialized
INFO - 2021-07-17 01:36:18 --> Language Class Initialized
INFO - 2021-07-17 01:36:18 --> Loader Class Initialized
INFO - 2021-07-17 01:36:18 --> Helper loaded: url_helper
INFO - 2021-07-17 01:36:18 --> Helper loaded: form_helper
INFO - 2021-07-17 01:36:18 --> Helper loaded: array_helper
INFO - 2021-07-17 01:36:18 --> Helper loaded: date_helper
INFO - 2021-07-17 01:36:18 --> Helper loaded: html_helper
INFO - 2021-07-17 01:36:18 --> Database Driver Class Initialized
INFO - 2021-07-17 01:36:18 --> Controller Class Initialized
DEBUG - 2021-07-17 01:36:18 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 01:36:18 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 01:36:18 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 01:37:41 --> Config Class Initialized
INFO - 2021-07-17 01:37:41 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:37:41 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:37:41 --> Utf8 Class Initialized
INFO - 2021-07-17 01:37:41 --> URI Class Initialized
INFO - 2021-07-17 01:37:41 --> Router Class Initialized
INFO - 2021-07-17 01:37:41 --> Output Class Initialized
INFO - 2021-07-17 01:37:41 --> Security Class Initialized
DEBUG - 2021-07-17 01:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:37:41 --> Input Class Initialized
INFO - 2021-07-17 01:37:41 --> Language Class Initialized
INFO - 2021-07-17 01:37:41 --> Loader Class Initialized
INFO - 2021-07-17 01:37:41 --> Helper loaded: url_helper
INFO - 2021-07-17 01:37:41 --> Helper loaded: form_helper
INFO - 2021-07-17 01:37:41 --> Helper loaded: array_helper
INFO - 2021-07-17 01:37:41 --> Helper loaded: date_helper
INFO - 2021-07-17 01:37:41 --> Helper loaded: html_helper
INFO - 2021-07-17 01:37:41 --> Database Driver Class Initialized
INFO - 2021-07-17 01:37:41 --> Controller Class Initialized
DEBUG - 2021-07-17 01:37:41 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 01:37:41 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 01:37:41 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 22:54:06 --> Config Class Initialized
INFO - 2021-07-17 22:54:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 22:54:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 22:54:06 --> Utf8 Class Initialized
INFO - 2021-07-17 22:54:06 --> URI Class Initialized
INFO - 2021-07-17 22:54:06 --> Router Class Initialized
INFO - 2021-07-17 22:54:06 --> Output Class Initialized
INFO - 2021-07-17 22:54:06 --> Security Class Initialized
DEBUG - 2021-07-17 22:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 22:54:06 --> Input Class Initialized
INFO - 2021-07-17 22:54:06 --> Language Class Initialized
INFO - 2021-07-17 22:54:06 --> Loader Class Initialized
INFO - 2021-07-17 22:54:06 --> Helper loaded: url_helper
INFO - 2021-07-17 22:54:06 --> Helper loaded: form_helper
INFO - 2021-07-17 22:54:06 --> Helper loaded: array_helper
INFO - 2021-07-17 22:54:06 --> Helper loaded: date_helper
INFO - 2021-07-17 22:54:06 --> Helper loaded: html_helper
INFO - 2021-07-17 22:54:06 --> Database Driver Class Initialized
INFO - 2021-07-17 22:54:07 --> Controller Class Initialized
DEBUG - 2021-07-17 22:54:07 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 22:54:07 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 22:54:07 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 22:54:07 --> Model "Dctf_model" initialized
INFO - 2021-07-17 17:54:11 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:12:38 --> Final output sent to browser
DEBUG - 2021-07-17 18:12:38 --> Total execution time: 1,111.6694
INFO - 2021-07-17 23:13:46 --> Config Class Initialized
INFO - 2021-07-17 23:13:46 --> Hooks Class Initialized
DEBUG - 2021-07-17 23:13:46 --> UTF-8 Support Enabled
INFO - 2021-07-17 23:13:46 --> Utf8 Class Initialized
INFO - 2021-07-17 23:13:46 --> URI Class Initialized
INFO - 2021-07-17 23:13:46 --> Router Class Initialized
INFO - 2021-07-17 23:13:46 --> Output Class Initialized
INFO - 2021-07-17 23:13:46 --> Security Class Initialized
DEBUG - 2021-07-17 23:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 23:13:46 --> Input Class Initialized
INFO - 2021-07-17 23:13:46 --> Language Class Initialized
INFO - 2021-07-17 23:13:46 --> Loader Class Initialized
INFO - 2021-07-17 23:13:46 --> Helper loaded: url_helper
INFO - 2021-07-17 23:13:46 --> Helper loaded: form_helper
INFO - 2021-07-17 23:13:46 --> Helper loaded: array_helper
INFO - 2021-07-17 23:13:46 --> Helper loaded: date_helper
INFO - 2021-07-17 23:13:46 --> Helper loaded: html_helper
INFO - 2021-07-17 23:13:46 --> Database Driver Class Initialized
INFO - 2021-07-17 23:13:46 --> Controller Class Initialized
DEBUG - 2021-07-17 23:13:46 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 23:13:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 23:13:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 23:13:46 --> Model "Dctf_model" initialized
INFO - 2021-07-17 18:13:51 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:28:23 --> Final output sent to browser
DEBUG - 2021-07-17 18:28:23 --> Total execution time: 877.3824
INFO - 2021-07-17 23:30:20 --> Config Class Initialized
INFO - 2021-07-17 23:30:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 23:30:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 23:30:20 --> Utf8 Class Initialized
INFO - 2021-07-17 23:30:20 --> URI Class Initialized
INFO - 2021-07-17 23:30:20 --> Router Class Initialized
INFO - 2021-07-17 23:30:20 --> Output Class Initialized
INFO - 2021-07-17 23:30:20 --> Security Class Initialized
DEBUG - 2021-07-17 23:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 23:30:20 --> Input Class Initialized
INFO - 2021-07-17 23:30:20 --> Language Class Initialized
INFO - 2021-07-17 23:30:20 --> Loader Class Initialized
INFO - 2021-07-17 23:30:20 --> Helper loaded: url_helper
INFO - 2021-07-17 23:30:20 --> Helper loaded: form_helper
INFO - 2021-07-17 23:30:20 --> Helper loaded: array_helper
INFO - 2021-07-17 23:30:20 --> Helper loaded: date_helper
INFO - 2021-07-17 23:30:20 --> Helper loaded: html_helper
INFO - 2021-07-17 23:30:20 --> Database Driver Class Initialized
INFO - 2021-07-17 23:30:20 --> Controller Class Initialized
DEBUG - 2021-07-17 23:30:20 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 23:30:20 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 23:30:20 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 23:30:20 --> Model "Dctf_model" initialized
INFO - 2021-07-17 18:30:24 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:39:34 --> Final output sent to browser
DEBUG - 2021-07-17 18:39:34 --> Total execution time: 554.5658
INFO - 2021-07-17 23:39:54 --> Config Class Initialized
INFO - 2021-07-17 23:39:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 23:39:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 23:39:54 --> Utf8 Class Initialized
INFO - 2021-07-17 23:39:54 --> URI Class Initialized
INFO - 2021-07-17 23:39:54 --> Router Class Initialized
INFO - 2021-07-17 23:39:54 --> Output Class Initialized
INFO - 2021-07-17 23:39:54 --> Security Class Initialized
DEBUG - 2021-07-17 23:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 23:39:54 --> Input Class Initialized
INFO - 2021-07-17 23:39:54 --> Language Class Initialized
INFO - 2021-07-17 23:39:54 --> Loader Class Initialized
INFO - 2021-07-17 23:39:54 --> Helper loaded: url_helper
INFO - 2021-07-17 23:39:54 --> Helper loaded: form_helper
INFO - 2021-07-17 23:39:54 --> Helper loaded: array_helper
INFO - 2021-07-17 23:39:54 --> Helper loaded: date_helper
INFO - 2021-07-17 23:39:54 --> Helper loaded: html_helper
INFO - 2021-07-17 23:39:54 --> Database Driver Class Initialized
INFO - 2021-07-17 23:39:54 --> Controller Class Initialized
DEBUG - 2021-07-17 23:39:54 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 23:39:54 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 23:39:54 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 23:39:54 --> Model "Dctf_model" initialized
INFO - 2021-07-17 18:39:58 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:40:31 --> Final output sent to browser
DEBUG - 2021-07-17 18:40:31 --> Total execution time: 37.2323
INFO - 2021-07-17 23:43:16 --> Config Class Initialized
INFO - 2021-07-17 23:43:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 23:43:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 23:43:16 --> Utf8 Class Initialized
INFO - 2021-07-17 23:43:16 --> URI Class Initialized
INFO - 2021-07-17 23:43:16 --> Router Class Initialized
INFO - 2021-07-17 23:43:16 --> Output Class Initialized
INFO - 2021-07-17 23:43:16 --> Security Class Initialized
DEBUG - 2021-07-17 23:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 23:43:16 --> Input Class Initialized
INFO - 2021-07-17 23:43:16 --> Language Class Initialized
INFO - 2021-07-17 23:43:16 --> Loader Class Initialized
INFO - 2021-07-17 23:43:16 --> Helper loaded: url_helper
INFO - 2021-07-17 23:43:16 --> Helper loaded: form_helper
INFO - 2021-07-17 23:43:16 --> Helper loaded: array_helper
INFO - 2021-07-17 23:43:16 --> Helper loaded: date_helper
INFO - 2021-07-17 23:43:16 --> Helper loaded: html_helper
INFO - 2021-07-17 23:43:16 --> Database Driver Class Initialized
INFO - 2021-07-17 23:43:16 --> Controller Class Initialized
DEBUG - 2021-07-17 23:43:16 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 23:43:16 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 23:43:16 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 23:43:16 --> Model "Dctf_model" initialized
INFO - 2021-07-17 18:43:20 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:43:20 --> Final output sent to browser
DEBUG - 2021-07-17 18:43:20 --> Total execution time: 4.1907
INFO - 2021-07-17 23:44:43 --> Config Class Initialized
INFO - 2021-07-17 23:44:43 --> Hooks Class Initialized
DEBUG - 2021-07-17 23:44:43 --> UTF-8 Support Enabled
INFO - 2021-07-17 23:44:43 --> Utf8 Class Initialized
INFO - 2021-07-17 23:44:43 --> URI Class Initialized
INFO - 2021-07-17 23:44:43 --> Router Class Initialized
INFO - 2021-07-17 23:44:43 --> Output Class Initialized
INFO - 2021-07-17 23:44:43 --> Security Class Initialized
DEBUG - 2021-07-17 23:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 23:44:43 --> Input Class Initialized
INFO - 2021-07-17 23:44:43 --> Language Class Initialized
INFO - 2021-07-17 23:44:43 --> Loader Class Initialized
INFO - 2021-07-17 23:44:43 --> Helper loaded: url_helper
INFO - 2021-07-17 23:44:43 --> Helper loaded: form_helper
INFO - 2021-07-17 23:44:43 --> Helper loaded: array_helper
INFO - 2021-07-17 23:44:43 --> Helper loaded: date_helper
INFO - 2021-07-17 23:44:43 --> Helper loaded: html_helper
INFO - 2021-07-17 23:44:43 --> Database Driver Class Initialized
INFO - 2021-07-17 23:44:44 --> Controller Class Initialized
DEBUG - 2021-07-17 23:44:44 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-17 23:44:44 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-17 23:44:44 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-17 23:44:44 --> Model "Dctf_model" initialized
INFO - 2021-07-17 18:44:47 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:46:30 --> Ecac Robo Class Initialized
INFO - 2021-07-17 18:46:33 --> Final output sent to browser
DEBUG - 2021-07-17 18:46:33 --> Total execution time: 109.5021
INFO - 2021-07-17 19:44:28 --> Ecac Robo Class Initialized
INFO - 2021-07-17 19:44:36 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-17 19:44:36 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-17 19:50:14 --> Ecac Robo Class Initialized
INFO - 2021-07-17 19:50:17 --> Final output sent to browser
DEBUG - 2021-07-17 19:50:17 --> Total execution time: 353.1064
