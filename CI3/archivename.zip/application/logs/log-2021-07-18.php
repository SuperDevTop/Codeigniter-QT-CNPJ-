<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-18 00:44:24 --> Config Class Initialized
INFO - 2021-07-18 00:44:24 --> Hooks Class Initialized
DEBUG - 2021-07-18 00:44:24 --> UTF-8 Support Enabled
INFO - 2021-07-18 00:44:24 --> Utf8 Class Initialized
INFO - 2021-07-18 00:44:24 --> URI Class Initialized
INFO - 2021-07-18 00:44:24 --> Router Class Initialized
INFO - 2021-07-18 00:44:24 --> Output Class Initialized
INFO - 2021-07-18 00:44:24 --> Security Class Initialized
DEBUG - 2021-07-18 00:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 00:44:24 --> Input Class Initialized
INFO - 2021-07-18 00:44:24 --> Language Class Initialized
INFO - 2021-07-18 00:44:24 --> Loader Class Initialized
INFO - 2021-07-18 00:44:24 --> Helper loaded: url_helper
INFO - 2021-07-18 00:44:24 --> Helper loaded: form_helper
INFO - 2021-07-18 00:44:24 --> Helper loaded: array_helper
INFO - 2021-07-18 00:44:24 --> Helper loaded: date_helper
INFO - 2021-07-18 00:44:24 --> Helper loaded: html_helper
INFO - 2021-07-18 00:44:24 --> Database Driver Class Initialized
INFO - 2021-07-18 00:44:24 --> Controller Class Initialized
DEBUG - 2021-07-18 00:44:24 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-18 00:44:24 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-18 00:44:24 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-18 22:24:53 --> Ecac Robo Class Initialized
INFO - 2021-07-18 22:25:36 --> Final output sent to browser
DEBUG - 2021-07-18 22:25:36 --> Total execution time: 48.5944
