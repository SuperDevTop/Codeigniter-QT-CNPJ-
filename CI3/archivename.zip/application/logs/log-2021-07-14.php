<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-14 15:06:37 --> Config Class Initialized
INFO - 2021-07-14 15:06:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:06:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:06:37 --> Utf8 Class Initialized
INFO - 2021-07-14 15:06:37 --> URI Class Initialized
INFO - 2021-07-14 15:06:37 --> Router Class Initialized
INFO - 2021-07-14 15:06:37 --> Output Class Initialized
INFO - 2021-07-14 15:06:37 --> Security Class Initialized
DEBUG - 2021-07-14 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:06:37 --> Input Class Initialized
INFO - 2021-07-14 15:06:37 --> Language Class Initialized
INFO - 2021-07-14 15:06:37 --> Loader Class Initialized
INFO - 2021-07-14 15:06:37 --> Helper loaded: url_helper
INFO - 2021-07-14 15:06:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:06:38 --> Helper loaded: array_helper
INFO - 2021-07-14 15:06:38 --> Helper loaded: date_helper
INFO - 2021-07-14 15:06:38 --> Helper loaded: html_helper
INFO - 2021-07-14 15:06:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:06:38 --> Controller Class Initialized
DEBUG - 2021-07-14 15:06:38 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 15:06:38 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 15:06:38 --> Model "Procuracao_model" initialized
INFO - 2021-07-14 10:06:41 --> Ecac Robo Class Initialized
INFO - 2021-07-14 10:07:07 --> Final output sent to browser
DEBUG - 2021-07-14 10:07:07 --> Total execution time: 29.4696
INFO - 2021-07-14 15:10:39 --> Config Class Initialized
INFO - 2021-07-14 15:10:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:10:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:10:39 --> Utf8 Class Initialized
INFO - 2021-07-14 15:10:39 --> URI Class Initialized
INFO - 2021-07-14 15:10:39 --> Router Class Initialized
INFO - 2021-07-14 15:10:39 --> Output Class Initialized
INFO - 2021-07-14 15:10:39 --> Security Class Initialized
DEBUG - 2021-07-14 15:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:10:39 --> Input Class Initialized
INFO - 2021-07-14 15:10:39 --> Language Class Initialized
INFO - 2021-07-14 15:10:39 --> Loader Class Initialized
INFO - 2021-07-14 15:10:39 --> Helper loaded: url_helper
INFO - 2021-07-14 15:10:39 --> Helper loaded: form_helper
INFO - 2021-07-14 15:10:39 --> Helper loaded: array_helper
INFO - 2021-07-14 15:10:39 --> Helper loaded: date_helper
INFO - 2021-07-14 15:10:39 --> Helper loaded: html_helper
INFO - 2021-07-14 15:10:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:10:39 --> Controller Class Initialized
INFO - 2021-07-14 15:10:39 --> Model "Certificadocontador_model" initialized
ERROR - 2021-07-14 15:10:39 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Contadorprocuracao_model.php 51
INFO - 2021-07-14 15:14:51 --> Config Class Initialized
INFO - 2021-07-14 15:14:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:14:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:14:51 --> Utf8 Class Initialized
INFO - 2021-07-14 15:14:51 --> URI Class Initialized
INFO - 2021-07-14 15:14:51 --> Router Class Initialized
INFO - 2021-07-14 15:14:51 --> Output Class Initialized
INFO - 2021-07-14 15:14:51 --> Security Class Initialized
DEBUG - 2021-07-14 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:14:51 --> Input Class Initialized
INFO - 2021-07-14 15:14:51 --> Language Class Initialized
INFO - 2021-07-14 15:14:51 --> Loader Class Initialized
INFO - 2021-07-14 15:14:51 --> Helper loaded: url_helper
INFO - 2021-07-14 15:14:51 --> Helper loaded: form_helper
INFO - 2021-07-14 15:14:51 --> Helper loaded: array_helper
INFO - 2021-07-14 15:14:51 --> Helper loaded: date_helper
INFO - 2021-07-14 15:14:51 --> Helper loaded: html_helper
INFO - 2021-07-14 15:14:51 --> Database Driver Class Initialized
INFO - 2021-07-14 15:14:51 --> Controller Class Initialized
INFO - 2021-07-14 15:14:51 --> Model "Certificadocontador_model" initialized
ERROR - 2021-07-14 15:14:51 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Contadorprocuracao_model.php 51
INFO - 2021-07-14 15:15:02 --> Config Class Initialized
INFO - 2021-07-14 15:15:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:15:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:15:02 --> Utf8 Class Initialized
INFO - 2021-07-14 15:15:02 --> URI Class Initialized
INFO - 2021-07-14 15:15:02 --> Router Class Initialized
INFO - 2021-07-14 15:15:02 --> Output Class Initialized
INFO - 2021-07-14 15:15:02 --> Security Class Initialized
DEBUG - 2021-07-14 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:15:02 --> Input Class Initialized
INFO - 2021-07-14 15:15:02 --> Language Class Initialized
INFO - 2021-07-14 15:15:02 --> Loader Class Initialized
INFO - 2021-07-14 15:15:02 --> Helper loaded: url_helper
INFO - 2021-07-14 15:15:02 --> Helper loaded: form_helper
INFO - 2021-07-14 15:15:02 --> Helper loaded: array_helper
INFO - 2021-07-14 15:15:02 --> Helper loaded: date_helper
INFO - 2021-07-14 15:15:02 --> Helper loaded: html_helper
INFO - 2021-07-14 15:15:02 --> Database Driver Class Initialized
INFO - 2021-07-14 15:15:02 --> Controller Class Initialized
INFO - 2021-07-14 15:15:02 --> Model "Certificadocontador_model" initialized
ERROR - 2021-07-14 15:15:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Contadorprocuracao_model.php 51
INFO - 2021-07-14 15:17:53 --> Config Class Initialized
INFO - 2021-07-14 15:17:53 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:17:53 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:17:53 --> Utf8 Class Initialized
INFO - 2021-07-14 15:17:53 --> URI Class Initialized
INFO - 2021-07-14 15:17:53 --> Router Class Initialized
INFO - 2021-07-14 15:17:53 --> Output Class Initialized
INFO - 2021-07-14 15:17:53 --> Security Class Initialized
DEBUG - 2021-07-14 15:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:17:53 --> Input Class Initialized
INFO - 2021-07-14 15:17:53 --> Language Class Initialized
INFO - 2021-07-14 15:17:53 --> Loader Class Initialized
INFO - 2021-07-14 15:17:53 --> Helper loaded: url_helper
INFO - 2021-07-14 15:17:53 --> Helper loaded: form_helper
INFO - 2021-07-14 15:17:53 --> Helper loaded: array_helper
INFO - 2021-07-14 15:17:53 --> Helper loaded: date_helper
INFO - 2021-07-14 15:17:53 --> Helper loaded: html_helper
INFO - 2021-07-14 15:17:53 --> Database Driver Class Initialized
INFO - 2021-07-14 15:17:53 --> Controller Class Initialized
DEBUG - 2021-07-14 15:17:53 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 15:17:53 --> Model "Certificadocontador_model" initialized
ERROR - 2021-07-14 15:17:53 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Contadorprocuracao_model.php 51
INFO - 2021-07-14 15:23:19 --> Config Class Initialized
INFO - 2021-07-14 15:23:19 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:23:19 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:23:19 --> Utf8 Class Initialized
INFO - 2021-07-14 15:23:19 --> URI Class Initialized
INFO - 2021-07-14 15:23:19 --> Router Class Initialized
INFO - 2021-07-14 15:23:19 --> Output Class Initialized
INFO - 2021-07-14 15:23:19 --> Security Class Initialized
DEBUG - 2021-07-14 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:23:19 --> Input Class Initialized
INFO - 2021-07-14 15:23:19 --> Language Class Initialized
INFO - 2021-07-14 15:23:19 --> Loader Class Initialized
INFO - 2021-07-14 15:23:19 --> Helper loaded: url_helper
INFO - 2021-07-14 15:23:19 --> Helper loaded: form_helper
INFO - 2021-07-14 15:23:19 --> Helper loaded: array_helper
INFO - 2021-07-14 15:23:19 --> Helper loaded: date_helper
INFO - 2021-07-14 15:23:19 --> Helper loaded: html_helper
INFO - 2021-07-14 15:23:19 --> Database Driver Class Initialized
INFO - 2021-07-14 15:23:19 --> Controller Class Initialized
DEBUG - 2021-07-14 15:23:19 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 15:23:19 --> Model "Certificadocontador_model" initialized
ERROR - 2021-07-14 15:23:19 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Contadorprocuracao_model.php 51
INFO - 2021-07-14 15:24:28 --> Config Class Initialized
INFO - 2021-07-14 15:24:28 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:24:28 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:24:28 --> Utf8 Class Initialized
INFO - 2021-07-14 15:24:28 --> URI Class Initialized
INFO - 2021-07-14 15:24:28 --> Router Class Initialized
INFO - 2021-07-14 15:24:28 --> Output Class Initialized
INFO - 2021-07-14 15:24:28 --> Security Class Initialized
DEBUG - 2021-07-14 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:24:28 --> Input Class Initialized
INFO - 2021-07-14 15:24:28 --> Language Class Initialized
INFO - 2021-07-14 15:24:28 --> Loader Class Initialized
INFO - 2021-07-14 15:24:28 --> Helper loaded: url_helper
INFO - 2021-07-14 15:24:28 --> Helper loaded: form_helper
INFO - 2021-07-14 15:24:28 --> Helper loaded: array_helper
INFO - 2021-07-14 15:24:28 --> Helper loaded: date_helper
INFO - 2021-07-14 15:24:28 --> Helper loaded: html_helper
INFO - 2021-07-14 15:24:28 --> Database Driver Class Initialized
INFO - 2021-07-14 15:24:29 --> Controller Class Initialized
DEBUG - 2021-07-14 15:24:29 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 15:24:29 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 15:24:29 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 15:24:29 --> Model "Dctf_model" initialized
INFO - 2021-07-14 15:24:31 --> Config Class Initialized
INFO - 2021-07-14 15:24:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:24:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:24:31 --> Utf8 Class Initialized
INFO - 2021-07-14 15:24:31 --> URI Class Initialized
INFO - 2021-07-14 15:24:31 --> Router Class Initialized
INFO - 2021-07-14 15:24:31 --> Output Class Initialized
INFO - 2021-07-14 15:24:31 --> Security Class Initialized
DEBUG - 2021-07-14 15:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:24:31 --> Input Class Initialized
INFO - 2021-07-14 15:24:31 --> Language Class Initialized
INFO - 2021-07-14 15:24:31 --> Loader Class Initialized
INFO - 2021-07-14 15:24:31 --> Helper loaded: url_helper
INFO - 2021-07-14 15:24:31 --> Helper loaded: form_helper
INFO - 2021-07-14 15:24:31 --> Helper loaded: array_helper
INFO - 2021-07-14 15:24:31 --> Helper loaded: date_helper
INFO - 2021-07-14 15:24:31 --> Helper loaded: html_helper
INFO - 2021-07-14 15:24:32 --> Database Driver Class Initialized
INFO - 2021-07-14 15:24:32 --> Controller Class Initialized
DEBUG - 2021-07-14 15:24:32 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 15:24:32 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 15:24:32 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 15:24:32 --> Model "Dctf_model" initialized
INFO - 2021-07-14 10:24:32 --> Ecac Robo Class Initialized
INFO - 2021-07-14 10:24:35 --> Ecac Robo Class Initialized
INFO - 2021-07-14 10:25:15 --> Final output sent to browser
DEBUG - 2021-07-14 10:25:15 --> Total execution time: 46.3798
INFO - 2021-07-14 10:25:16 --> Final output sent to browser
DEBUG - 2021-07-14 10:25:16 --> Total execution time: 44.9445
INFO - 2021-07-14 21:36:30 --> Config Class Initialized
INFO - 2021-07-14 21:36:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:36:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:36:30 --> Utf8 Class Initialized
INFO - 2021-07-14 21:36:30 --> URI Class Initialized
INFO - 2021-07-14 21:36:30 --> Router Class Initialized
INFO - 2021-07-14 21:36:30 --> Output Class Initialized
INFO - 2021-07-14 21:36:30 --> Security Class Initialized
DEBUG - 2021-07-14 21:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:36:30 --> Input Class Initialized
INFO - 2021-07-14 21:36:30 --> Language Class Initialized
INFO - 2021-07-14 21:36:30 --> Loader Class Initialized
INFO - 2021-07-14 21:36:30 --> Helper loaded: url_helper
INFO - 2021-07-14 21:36:30 --> Helper loaded: form_helper
INFO - 2021-07-14 21:36:30 --> Helper loaded: array_helper
INFO - 2021-07-14 21:36:30 --> Helper loaded: date_helper
INFO - 2021-07-14 21:36:30 --> Helper loaded: html_helper
INFO - 2021-07-14 21:36:30 --> Database Driver Class Initialized
INFO - 2021-07-14 21:36:30 --> Controller Class Initialized
DEBUG - 2021-07-14 21:36:30 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 21:36:30 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:36:30 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 21:36:33 --> Config Class Initialized
INFO - 2021-07-14 21:36:33 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:36:33 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:36:33 --> Utf8 Class Initialized
INFO - 2021-07-14 21:36:33 --> URI Class Initialized
INFO - 2021-07-14 21:36:33 --> Router Class Initialized
INFO - 2021-07-14 21:36:33 --> Output Class Initialized
INFO - 2021-07-14 21:36:33 --> Security Class Initialized
DEBUG - 2021-07-14 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:36:33 --> Input Class Initialized
INFO - 2021-07-14 21:36:33 --> Language Class Initialized
INFO - 2021-07-14 21:36:33 --> Loader Class Initialized
INFO - 2021-07-14 21:36:33 --> Helper loaded: url_helper
INFO - 2021-07-14 21:36:33 --> Helper loaded: form_helper
INFO - 2021-07-14 21:36:33 --> Helper loaded: array_helper
INFO - 2021-07-14 21:36:33 --> Helper loaded: date_helper
INFO - 2021-07-14 21:36:33 --> Helper loaded: html_helper
INFO - 2021-07-14 21:36:33 --> Database Driver Class Initialized
INFO - 2021-07-14 21:36:33 --> Controller Class Initialized
DEBUG - 2021-07-14 21:36:33 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 21:36:33 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:36:33 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 16:36:34 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:36:36 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:36:45 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-14 16:36:47 --> Model "Situacao_fiscal_model" initialized
ERROR - 2021-07-14 16:40:08 --> Severity: error --> Exception: {
  "error": {
    "code": 400,
    "message": "Provided MD5 hash \"2nFylZiIuOQ02oLqT5xe3w==\" doesn't match calculated MD5 hash \"r1AFUjEbaLaHiMgoI8tZdg==\".",
    "errors": [
      {
        "message": "Provided MD5 hash \"2nFylZiIuOQ02oLqT5xe3w==\" doesn't match calculated MD5 hash \"r1AFUjEbaLaHiMgoI8tZdg==\".",
        "domain": "global",
        "reason": "invalid"
      }
    ]
  }
}
 C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-14 16:40:08 --> Final output sent to browser
DEBUG - 2021-07-14 16:40:08 --> Total execution time: 218.5173
INFO - 2021-07-14 21:41:08 --> Config Class Initialized
INFO - 2021-07-14 21:41:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:41:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:41:08 --> Utf8 Class Initialized
INFO - 2021-07-14 21:41:08 --> URI Class Initialized
INFO - 2021-07-14 21:41:08 --> Router Class Initialized
INFO - 2021-07-14 21:41:08 --> Output Class Initialized
INFO - 2021-07-14 21:41:08 --> Security Class Initialized
DEBUG - 2021-07-14 21:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:41:08 --> Input Class Initialized
INFO - 2021-07-14 21:41:08 --> Language Class Initialized
INFO - 2021-07-14 21:41:08 --> Loader Class Initialized
INFO - 2021-07-14 21:41:08 --> Helper loaded: url_helper
INFO - 2021-07-14 21:41:08 --> Helper loaded: form_helper
INFO - 2021-07-14 21:41:08 --> Helper loaded: array_helper
INFO - 2021-07-14 21:41:08 --> Helper loaded: date_helper
INFO - 2021-07-14 21:41:08 --> Helper loaded: html_helper
INFO - 2021-07-14 21:41:08 --> Database Driver Class Initialized
INFO - 2021-07-14 21:41:08 --> Controller Class Initialized
INFO - 2021-07-14 21:41:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:41:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 21:41:08 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-14 21:41:11 --> Config Class Initialized
INFO - 2021-07-14 21:41:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:41:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:41:11 --> Utf8 Class Initialized
INFO - 2021-07-14 21:41:11 --> URI Class Initialized
INFO - 2021-07-14 21:41:11 --> Router Class Initialized
INFO - 2021-07-14 21:41:11 --> Output Class Initialized
INFO - 2021-07-14 21:41:11 --> Security Class Initialized
DEBUG - 2021-07-14 21:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:41:11 --> Input Class Initialized
INFO - 2021-07-14 21:41:11 --> Language Class Initialized
INFO - 2021-07-14 21:41:11 --> Loader Class Initialized
INFO - 2021-07-14 21:41:11 --> Helper loaded: url_helper
INFO - 2021-07-14 21:41:11 --> Helper loaded: form_helper
INFO - 2021-07-14 21:41:11 --> Helper loaded: array_helper
INFO - 2021-07-14 21:41:11 --> Helper loaded: date_helper
INFO - 2021-07-14 21:41:11 --> Helper loaded: html_helper
INFO - 2021-07-14 21:41:11 --> Database Driver Class Initialized
INFO - 2021-07-14 21:41:11 --> Controller Class Initialized
INFO - 2021-07-14 21:41:11 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:41:11 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 21:41:11 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-14 16:41:11 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:41:14 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:42:20 --> Final output sent to browser
DEBUG - 2021-07-14 16:42:20 --> Total execution time: 72.9206
INFO - 2021-07-14 16:42:24 --> Final output sent to browser
DEBUG - 2021-07-14 16:42:24 --> Total execution time: 73.5300
INFO - 2021-07-14 21:42:38 --> Config Class Initialized
INFO - 2021-07-14 21:42:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:42:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:42:38 --> Utf8 Class Initialized
INFO - 2021-07-14 21:42:38 --> URI Class Initialized
INFO - 2021-07-14 21:42:38 --> Router Class Initialized
INFO - 2021-07-14 21:42:38 --> Output Class Initialized
INFO - 2021-07-14 21:42:38 --> Security Class Initialized
DEBUG - 2021-07-14 21:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:42:38 --> Input Class Initialized
INFO - 2021-07-14 21:42:38 --> Language Class Initialized
INFO - 2021-07-14 21:42:38 --> Loader Class Initialized
INFO - 2021-07-14 21:42:38 --> Helper loaded: url_helper
INFO - 2021-07-14 21:42:38 --> Helper loaded: form_helper
INFO - 2021-07-14 21:42:38 --> Helper loaded: array_helper
INFO - 2021-07-14 21:42:38 --> Helper loaded: date_helper
INFO - 2021-07-14 21:42:38 --> Helper loaded: html_helper
INFO - 2021-07-14 21:42:38 --> Database Driver Class Initialized
INFO - 2021-07-14 21:42:38 --> Controller Class Initialized
DEBUG - 2021-07-14 21:42:38 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 21:42:38 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:42:38 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 21:42:38 --> Model "Dctf_model" initialized
INFO - 2021-07-14 16:42:41 --> Ecac Robo Class Initialized
INFO - 2021-07-14 21:43:22 --> Config Class Initialized
INFO - 2021-07-14 21:43:22 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:43:22 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:43:22 --> Utf8 Class Initialized
INFO - 2021-07-14 21:43:22 --> URI Class Initialized
INFO - 2021-07-14 21:43:22 --> Router Class Initialized
INFO - 2021-07-14 21:43:22 --> Output Class Initialized
INFO - 2021-07-14 21:43:22 --> Security Class Initialized
DEBUG - 2021-07-14 21:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:43:22 --> Input Class Initialized
INFO - 2021-07-14 21:43:22 --> Language Class Initialized
INFO - 2021-07-14 21:43:22 --> Loader Class Initialized
INFO - 2021-07-14 21:43:22 --> Helper loaded: url_helper
INFO - 2021-07-14 21:43:22 --> Helper loaded: form_helper
INFO - 2021-07-14 21:43:22 --> Helper loaded: array_helper
INFO - 2021-07-14 21:43:22 --> Helper loaded: date_helper
INFO - 2021-07-14 21:43:22 --> Helper loaded: html_helper
INFO - 2021-07-14 21:43:22 --> Database Driver Class Initialized
INFO - 2021-07-14 21:43:22 --> Controller Class Initialized
DEBUG - 2021-07-14 21:43:22 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 21:43:22 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:43:22 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 21:43:25 --> Config Class Initialized
INFO - 2021-07-14 21:43:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 21:43:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 21:43:25 --> Utf8 Class Initialized
INFO - 2021-07-14 21:43:25 --> URI Class Initialized
INFO - 2021-07-14 21:43:25 --> Router Class Initialized
INFO - 2021-07-14 21:43:25 --> Output Class Initialized
INFO - 2021-07-14 21:43:25 --> Security Class Initialized
DEBUG - 2021-07-14 21:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 21:43:25 --> Input Class Initialized
INFO - 2021-07-14 21:43:25 --> Language Class Initialized
INFO - 2021-07-14 21:43:25 --> Loader Class Initialized
INFO - 2021-07-14 21:43:25 --> Helper loaded: url_helper
INFO - 2021-07-14 21:43:25 --> Helper loaded: form_helper
INFO - 2021-07-14 21:43:25 --> Helper loaded: array_helper
INFO - 2021-07-14 21:43:25 --> Helper loaded: date_helper
INFO - 2021-07-14 21:43:25 --> Helper loaded: html_helper
INFO - 2021-07-14 21:43:25 --> Database Driver Class Initialized
INFO - 2021-07-14 21:43:25 --> Controller Class Initialized
DEBUG - 2021-07-14 21:43:25 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 21:43:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 21:43:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 16:43:25 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:43:28 --> Ecac Robo Class Initialized
INFO - 2021-07-14 16:43:38 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-14 16:43:38 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-14 16:43:41 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-14 16:43:41 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-14 16:43:54 --> Final output sent to browser
DEBUG - 2021-07-14 16:43:54 --> Total execution time: 76.4787
INFO - 2021-07-14 16:46:49 --> Final output sent to browser
DEBUG - 2021-07-14 16:46:49 --> Total execution time: 207.4586
INFO - 2021-07-14 16:46:55 --> Final output sent to browser
DEBUG - 2021-07-14 16:46:55 --> Total execution time: 210.4535
INFO - 2021-07-14 22:55:25 --> Config Class Initialized
INFO - 2021-07-14 22:55:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 22:55:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 22:55:25 --> Utf8 Class Initialized
INFO - 2021-07-14 22:55:25 --> URI Class Initialized
INFO - 2021-07-14 22:55:25 --> Router Class Initialized
INFO - 2021-07-14 22:55:25 --> Output Class Initialized
INFO - 2021-07-14 22:55:25 --> Security Class Initialized
DEBUG - 2021-07-14 22:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 22:55:25 --> Input Class Initialized
INFO - 2021-07-14 22:55:25 --> Language Class Initialized
INFO - 2021-07-14 22:55:25 --> Loader Class Initialized
INFO - 2021-07-14 22:55:25 --> Helper loaded: url_helper
INFO - 2021-07-14 22:55:25 --> Helper loaded: form_helper
INFO - 2021-07-14 22:55:25 --> Helper loaded: array_helper
INFO - 2021-07-14 22:55:25 --> Helper loaded: date_helper
INFO - 2021-07-14 22:55:25 --> Helper loaded: html_helper
INFO - 2021-07-14 22:55:25 --> Database Driver Class Initialized
INFO - 2021-07-14 22:55:25 --> Controller Class Initialized
DEBUG - 2021-07-14 22:55:25 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 22:55:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 22:55:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 22:55:25 --> Model "Dctf_model" initialized
INFO - 2021-07-14 17:55:29 --> Ecac Robo Class Initialized
INFO - 2021-07-14 22:55:32 --> Config Class Initialized
INFO - 2021-07-14 22:55:32 --> Hooks Class Initialized
INFO - 2021-07-14 17:55:32 --> Ecac Robo Class Initialized
DEBUG - 2021-07-14 22:55:32 --> UTF-8 Support Enabled
INFO - 2021-07-14 22:55:32 --> Utf8 Class Initialized
INFO - 2021-07-14 22:55:32 --> URI Class Initialized
INFO - 2021-07-14 22:55:32 --> Router Class Initialized
INFO - 2021-07-14 22:55:32 --> Output Class Initialized
INFO - 2021-07-14 22:55:32 --> Security Class Initialized
DEBUG - 2021-07-14 22:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 22:55:32 --> Input Class Initialized
INFO - 2021-07-14 22:55:32 --> Language Class Initialized
INFO - 2021-07-14 22:55:32 --> Loader Class Initialized
INFO - 2021-07-14 22:55:32 --> Helper loaded: url_helper
INFO - 2021-07-14 22:55:32 --> Helper loaded: form_helper
INFO - 2021-07-14 22:55:32 --> Helper loaded: array_helper
INFO - 2021-07-14 22:55:32 --> Helper loaded: date_helper
INFO - 2021-07-14 22:55:32 --> Helper loaded: html_helper
INFO - 2021-07-14 22:55:32 --> Database Driver Class Initialized
INFO - 2021-07-14 22:55:32 --> Controller Class Initialized
DEBUG - 2021-07-14 22:55:32 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 22:55:32 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 22:55:32 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 22:55:35 --> Config Class Initialized
INFO - 2021-07-14 22:55:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 22:55:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 22:55:35 --> Utf8 Class Initialized
INFO - 2021-07-14 22:55:35 --> URI Class Initialized
INFO - 2021-07-14 22:55:35 --> Router Class Initialized
INFO - 2021-07-14 22:55:35 --> Output Class Initialized
INFO - 2021-07-14 22:55:35 --> Security Class Initialized
DEBUG - 2021-07-14 22:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 22:55:35 --> Input Class Initialized
INFO - 2021-07-14 22:55:35 --> Language Class Initialized
INFO - 2021-07-14 22:55:35 --> Loader Class Initialized
INFO - 2021-07-14 22:55:35 --> Helper loaded: url_helper
INFO - 2021-07-14 22:55:35 --> Helper loaded: form_helper
INFO - 2021-07-14 22:55:35 --> Helper loaded: array_helper
INFO - 2021-07-14 22:55:35 --> Helper loaded: date_helper
INFO - 2021-07-14 22:55:35 --> Helper loaded: html_helper
INFO - 2021-07-14 22:55:35 --> Database Driver Class Initialized
INFO - 2021-07-14 22:55:35 --> Controller Class Initialized
DEBUG - 2021-07-14 22:55:35 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 22:55:35 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 22:55:35 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 17:55:35 --> Ecac Robo Class Initialized
INFO - 2021-07-14 17:55:38 --> Ecac Robo Class Initialized
INFO - 2021-07-14 17:55:39 --> Ecac Robo Class Initialized
INFO - 2021-07-14 17:55:41 --> Ecac Robo Class Initialized
INFO - 2021-07-14 17:55:42 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-14 17:55:42 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-14 17:55:45 --> Model "Caixa_postal_mensagem_model" initialized
INFO - 2021-07-14 17:55:45 --> Model "Caixa_postal_model" initialized
INFO - 2021-07-14 18:01:08 --> Final output sent to browser
DEBUG - 2021-07-14 18:01:08 --> Total execution time: 343.7331
ERROR - 2021-07-14 18:01:18 --> Severity: Notice --> Trying to get property 'plaintext' of non-object C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 466
INFO - 2021-07-14 18:11:06 --> Final output sent to browser
DEBUG - 2021-07-14 18:11:06 --> Total execution time: 930.7830
INFO - 2021-07-14 23:50:35 --> Config Class Initialized
INFO - 2021-07-14 23:50:35 --> Hooks Class Initialized
DEBUG - 2021-07-14 23:50:35 --> UTF-8 Support Enabled
INFO - 2021-07-14 23:50:35 --> Utf8 Class Initialized
INFO - 2021-07-14 23:50:35 --> URI Class Initialized
INFO - 2021-07-14 23:50:35 --> Router Class Initialized
INFO - 2021-07-14 23:50:35 --> Output Class Initialized
INFO - 2021-07-14 23:50:35 --> Security Class Initialized
DEBUG - 2021-07-14 23:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 23:50:35 --> Input Class Initialized
INFO - 2021-07-14 23:50:35 --> Language Class Initialized
INFO - 2021-07-14 23:50:35 --> Loader Class Initialized
INFO - 2021-07-14 23:50:35 --> Helper loaded: url_helper
INFO - 2021-07-14 23:50:35 --> Helper loaded: form_helper
INFO - 2021-07-14 23:50:35 --> Helper loaded: array_helper
INFO - 2021-07-14 23:50:35 --> Helper loaded: date_helper
INFO - 2021-07-14 23:50:35 --> Helper loaded: html_helper
INFO - 2021-07-14 23:50:35 --> Database Driver Class Initialized
INFO - 2021-07-14 23:50:35 --> Controller Class Initialized
DEBUG - 2021-07-14 23:50:35 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 23:50:35 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 23:50:35 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 23:50:35 --> Model "Dctf_model" initialized
INFO - 2021-07-14 23:50:38 --> Config Class Initialized
INFO - 2021-07-14 23:50:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 23:50:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 23:50:38 --> Utf8 Class Initialized
INFO - 2021-07-14 23:50:38 --> URI Class Initialized
INFO - 2021-07-14 23:50:38 --> Router Class Initialized
INFO - 2021-07-14 23:50:38 --> Output Class Initialized
INFO - 2021-07-14 23:50:38 --> Security Class Initialized
DEBUG - 2021-07-14 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 23:50:38 --> Input Class Initialized
INFO - 2021-07-14 23:50:38 --> Language Class Initialized
INFO - 2021-07-14 23:50:38 --> Loader Class Initialized
INFO - 2021-07-14 23:50:38 --> Helper loaded: url_helper
INFO - 2021-07-14 23:50:38 --> Helper loaded: form_helper
INFO - 2021-07-14 23:50:38 --> Helper loaded: array_helper
INFO - 2021-07-14 23:50:38 --> Helper loaded: date_helper
INFO - 2021-07-14 23:50:38 --> Helper loaded: html_helper
INFO - 2021-07-14 23:50:38 --> Database Driver Class Initialized
INFO - 2021-07-14 23:50:38 --> Controller Class Initialized
DEBUG - 2021-07-14 23:50:38 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-14 23:50:38 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 23:50:38 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 23:50:38 --> Model "Dctf_model" initialized
INFO - 2021-07-14 18:50:39 --> Ecac Robo Class Initialized
INFO - 2021-07-14 18:50:41 --> Ecac Robo Class Initialized
INFO - 2021-07-14 23:51:43 --> Config Class Initialized
INFO - 2021-07-14 23:51:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 23:51:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 23:51:43 --> Utf8 Class Initialized
INFO - 2021-07-14 23:51:43 --> URI Class Initialized
INFO - 2021-07-14 23:51:43 --> Router Class Initialized
INFO - 2021-07-14 23:51:43 --> Output Class Initialized
INFO - 2021-07-14 23:51:43 --> Security Class Initialized
DEBUG - 2021-07-14 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 23:51:43 --> Input Class Initialized
INFO - 2021-07-14 23:51:43 --> Language Class Initialized
INFO - 2021-07-14 23:51:43 --> Loader Class Initialized
INFO - 2021-07-14 23:51:43 --> Helper loaded: url_helper
INFO - 2021-07-14 23:51:43 --> Helper loaded: form_helper
INFO - 2021-07-14 23:51:43 --> Helper loaded: array_helper
INFO - 2021-07-14 23:51:43 --> Helper loaded: date_helper
INFO - 2021-07-14 23:51:43 --> Helper loaded: html_helper
INFO - 2021-07-14 23:51:43 --> Database Driver Class Initialized
INFO - 2021-07-14 23:51:43 --> Controller Class Initialized
INFO - 2021-07-14 23:51:43 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 23:51:43 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 23:51:43 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-14 23:51:46 --> Config Class Initialized
INFO - 2021-07-14 23:51:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 23:51:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 23:51:46 --> Utf8 Class Initialized
INFO - 2021-07-14 23:51:46 --> URI Class Initialized
INFO - 2021-07-14 23:51:46 --> Router Class Initialized
INFO - 2021-07-14 23:51:46 --> Output Class Initialized
INFO - 2021-07-14 23:51:46 --> Security Class Initialized
DEBUG - 2021-07-14 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 23:51:46 --> Input Class Initialized
INFO - 2021-07-14 23:51:46 --> Language Class Initialized
INFO - 2021-07-14 23:51:46 --> Loader Class Initialized
INFO - 2021-07-14 23:51:46 --> Helper loaded: url_helper
INFO - 2021-07-14 23:51:46 --> Helper loaded: form_helper
INFO - 2021-07-14 23:51:46 --> Helper loaded: array_helper
INFO - 2021-07-14 23:51:46 --> Helper loaded: date_helper
INFO - 2021-07-14 23:51:46 --> Helper loaded: html_helper
INFO - 2021-07-14 23:51:46 --> Database Driver Class Initialized
INFO - 2021-07-14 23:51:46 --> Controller Class Initialized
INFO - 2021-07-14 23:51:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-14 23:51:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-14 23:51:46 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-14 18:51:47 --> Ecac Robo Class Initialized
INFO - 2021-07-14 18:51:50 --> Ecac Robo Class Initialized
ERROR - 2021-07-14 18:53:08 --> Severity: error --> Exception: {
  "error": {
    "code": 400,
    "message": "Provided MD5 hash \"4TIQXrrAGHBHTQjE30Oh3A==\" doesn't match calculated MD5 hash \"1B2M2Y8AsgTpgAmY7PhCfg==\".",
    "errors": [
      {
        "message": "Provided MD5 hash \"4TIQXrrAGHBHTQjE30Oh3A==\" doesn't match calculated MD5 hash \"1B2M2Y8AsgTpgAmY7PhCfg==\".",
        "domain": "global",
        "reason": "invalid"
      }
    ]
  }
}
 C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-14 19:00:12 --> Final output sent to browser
DEBUG - 2021-07-14 19:00:12 --> Total execution time: 574.6888
INFO - 2021-07-14 19:00:33 --> Ecac Robo Class Initialized
INFO - 2021-07-14 19:00:36 --> Ecac Robo Class Initialized
INFO - 2021-07-14 19:06:53 --> Final output sent to browser
DEBUG - 2021-07-14 19:06:53 --> Total execution time: 907.0312
INFO - 2021-07-14 19:07:30 --> Final output sent to browser
DEBUG - 2021-07-14 19:07:30 --> Total execution time: 420.1269
INFO - 2021-07-14 19:07:30 --> Final output sent to browser
DEBUG - 2021-07-14 19:07:30 --> Total execution time: 417.1395
INFO - 2021-07-14 19:27:40 --> Ecac Robo Class Initialized
INFO - 2021-07-14 19:28:33 --> Final output sent to browser
DEBUG - 2021-07-14 19:28:33 --> Total execution time: 57.4135
INFO - 2021-07-14 19:28:52 --> Ecac Robo Class Initialized
INFO - 2021-07-14 19:29:00 --> Model "Situacao_fiscal_model" initialized
INFO - 2021-07-14 19:54:34 --> Final output sent to browser
DEBUG - 2021-07-14 19:54:34 --> Total execution time: 1,545.3487
INFO - 2021-07-14 20:35:39 --> Ecac Robo Class Initialized
INFO - 2021-07-14 20:35:44 --> Ecac Robo Class Initialized
INFO - 2021-07-14 20:38:09 --> Final output sent to browser
DEBUG - 2021-07-14 20:38:09 --> Total execution time: 152.3356
