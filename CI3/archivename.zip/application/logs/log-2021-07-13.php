<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-13 14:53:12 --> Config Class Initialized
INFO - 2021-07-13 14:53:12 --> Hooks Class Initialized
DEBUG - 2021-07-13 14:53:12 --> UTF-8 Support Enabled
INFO - 2021-07-13 14:53:12 --> Utf8 Class Initialized
INFO - 2021-07-13 14:53:12 --> URI Class Initialized
INFO - 2021-07-13 14:53:12 --> Router Class Initialized
INFO - 2021-07-13 14:53:12 --> Output Class Initialized
INFO - 2021-07-13 14:53:12 --> Security Class Initialized
DEBUG - 2021-07-13 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 14:53:12 --> Input Class Initialized
INFO - 2021-07-13 14:53:12 --> Language Class Initialized
INFO - 2021-07-13 14:53:12 --> Loader Class Initialized
INFO - 2021-07-13 14:53:12 --> Helper loaded: url_helper
INFO - 2021-07-13 14:53:12 --> Helper loaded: form_helper
INFO - 2021-07-13 14:53:12 --> Helper loaded: array_helper
INFO - 2021-07-13 14:53:12 --> Helper loaded: date_helper
INFO - 2021-07-13 14:53:12 --> Helper loaded: html_helper
INFO - 2021-07-13 14:53:12 --> Database Driver Class Initialized
INFO - 2021-07-13 14:53:12 --> Controller Class Initialized
DEBUG - 2021-07-13 14:53:12 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-13 14:53:12 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-13 14:53:12 --> Model "Procuracao_model" initialized
INFO - 2021-07-13 09:53:19 --> Ecac Robo Class Initialized
INFO - 2021-07-13 09:54:16 --> Final output sent to browser
DEBUG - 2021-07-13 09:54:16 --> Total execution time: 64.2012
INFO - 2021-07-13 22:50:54 --> Config Class Initialized
INFO - 2021-07-13 22:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-13 22:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-13 22:50:54 --> Utf8 Class Initialized
INFO - 2021-07-13 22:50:54 --> URI Class Initialized
INFO - 2021-07-13 22:50:54 --> Router Class Initialized
INFO - 2021-07-13 22:50:54 --> Output Class Initialized
INFO - 2021-07-13 22:50:54 --> Security Class Initialized
DEBUG - 2021-07-13 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 22:50:54 --> Input Class Initialized
INFO - 2021-07-13 22:50:54 --> Language Class Initialized
ERROR - 2021-07-13 22:50:54 --> 404 Page Not Found: SistemacronsCertificado/sp
INFO - 2021-07-13 22:51:15 --> Config Class Initialized
INFO - 2021-07-13 22:51:15 --> Hooks Class Initialized
DEBUG - 2021-07-13 22:51:15 --> UTF-8 Support Enabled
INFO - 2021-07-13 22:51:15 --> Utf8 Class Initialized
INFO - 2021-07-13 22:51:15 --> URI Class Initialized
INFO - 2021-07-13 22:51:15 --> Router Class Initialized
INFO - 2021-07-13 22:51:15 --> Output Class Initialized
INFO - 2021-07-13 22:51:15 --> Security Class Initialized
DEBUG - 2021-07-13 22:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-13 22:51:15 --> Input Class Initialized
INFO - 2021-07-13 22:51:15 --> Language Class Initialized
INFO - 2021-07-13 22:51:15 --> Loader Class Initialized
INFO - 2021-07-13 22:51:15 --> Helper loaded: url_helper
INFO - 2021-07-13 22:51:15 --> Helper loaded: form_helper
INFO - 2021-07-13 22:51:15 --> Helper loaded: array_helper
INFO - 2021-07-13 22:51:15 --> Helper loaded: date_helper
INFO - 2021-07-13 22:51:15 --> Helper loaded: html_helper
INFO - 2021-07-13 22:51:15 --> Database Driver Class Initialized
INFO - 2021-07-13 22:51:15 --> Controller Class Initialized
DEBUG - 2021-07-13 22:51:15 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-13 22:51:15 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-13 22:51:15 --> Model "Procuracao_model" initialized
INFO - 2021-07-13 17:51:20 --> Ecac Robo Class Initialized
INFO - 2021-07-13 17:52:04 --> Final output sent to browser
DEBUG - 2021-07-13 17:52:04 --> Total execution time: 49.2693
