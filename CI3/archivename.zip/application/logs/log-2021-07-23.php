<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-23 16:54:13 --> Config Class Initialized
INFO - 2021-07-23 16:54:13 --> Hooks Class Initialized
DEBUG - 2021-07-23 16:54:13 --> UTF-8 Support Enabled
INFO - 2021-07-23 16:54:13 --> Utf8 Class Initialized
INFO - 2021-07-23 16:54:13 --> URI Class Initialized
INFO - 2021-07-23 16:54:13 --> Router Class Initialized
INFO - 2021-07-23 16:54:13 --> Output Class Initialized
INFO - 2021-07-23 16:54:13 --> Security Class Initialized
DEBUG - 2021-07-23 16:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 16:54:13 --> Input Class Initialized
INFO - 2021-07-23 16:54:13 --> Language Class Initialized
INFO - 2021-07-23 16:54:13 --> Loader Class Initialized
INFO - 2021-07-23 16:54:13 --> Helper loaded: url_helper
INFO - 2021-07-23 16:54:13 --> Helper loaded: form_helper
INFO - 2021-07-23 16:54:13 --> Helper loaded: array_helper
INFO - 2021-07-23 16:54:13 --> Helper loaded: date_helper
INFO - 2021-07-23 16:54:13 --> Helper loaded: html_helper
INFO - 2021-07-23 16:54:13 --> Database Driver Class Initialized
INFO - 2021-07-23 16:54:13 --> Controller Class Initialized
DEBUG - 2021-07-23 16:54:13 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 16:54:13 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 16:54:13 --> Model "Procuracao_model" initialized
INFO - 2021-07-23 11:54:17 --> Ecac Robo Class Initialized
INFO - 2021-07-23 11:54:18 --> Final output sent to browser
DEBUG - 2021-07-23 11:54:18 --> Total execution time: 5.1722
INFO - 2021-07-23 16:55:04 --> Config Class Initialized
INFO - 2021-07-23 16:55:04 --> Hooks Class Initialized
DEBUG - 2021-07-23 16:55:04 --> UTF-8 Support Enabled
INFO - 2021-07-23 16:55:04 --> Utf8 Class Initialized
INFO - 2021-07-23 16:55:04 --> URI Class Initialized
INFO - 2021-07-23 16:55:04 --> Router Class Initialized
INFO - 2021-07-23 16:55:04 --> Output Class Initialized
INFO - 2021-07-23 16:55:04 --> Security Class Initialized
DEBUG - 2021-07-23 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 16:55:04 --> Input Class Initialized
INFO - 2021-07-23 16:55:04 --> Language Class Initialized
INFO - 2021-07-23 16:55:04 --> Loader Class Initialized
INFO - 2021-07-23 16:55:04 --> Helper loaded: url_helper
INFO - 2021-07-23 16:55:04 --> Helper loaded: form_helper
INFO - 2021-07-23 16:55:04 --> Helper loaded: array_helper
INFO - 2021-07-23 16:55:04 --> Helper loaded: date_helper
INFO - 2021-07-23 16:55:04 --> Helper loaded: html_helper
INFO - 2021-07-23 16:55:04 --> Database Driver Class Initialized
INFO - 2021-07-23 16:55:04 --> Controller Class Initialized
DEBUG - 2021-07-23 16:55:04 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 16:55:04 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 16:55:04 --> Model "Procuracao_model" initialized
INFO - 2021-07-23 11:55:08 --> Ecac Robo Class Initialized
INFO - 2021-07-23 16:58:54 --> Config Class Initialized
INFO - 2021-07-23 16:58:54 --> Hooks Class Initialized
DEBUG - 2021-07-23 16:58:54 --> UTF-8 Support Enabled
INFO - 2021-07-23 16:58:54 --> Utf8 Class Initialized
INFO - 2021-07-23 16:58:54 --> URI Class Initialized
INFO - 2021-07-23 16:58:54 --> Router Class Initialized
INFO - 2021-07-23 16:58:54 --> Output Class Initialized
INFO - 2021-07-23 16:58:54 --> Security Class Initialized
DEBUG - 2021-07-23 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 16:58:54 --> Input Class Initialized
INFO - 2021-07-23 16:58:54 --> Language Class Initialized
INFO - 2021-07-23 16:58:54 --> Loader Class Initialized
INFO - 2021-07-23 16:58:54 --> Helper loaded: url_helper
INFO - 2021-07-23 16:58:54 --> Helper loaded: form_helper
INFO - 2021-07-23 16:58:54 --> Helper loaded: array_helper
INFO - 2021-07-23 16:58:54 --> Helper loaded: date_helper
INFO - 2021-07-23 16:58:54 --> Helper loaded: html_helper
INFO - 2021-07-23 16:58:54 --> Database Driver Class Initialized
INFO - 2021-07-23 16:58:54 --> Controller Class Initialized
DEBUG - 2021-07-23 16:58:54 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 16:58:54 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 16:58:54 --> Model "Procuracao_model" initialized
INFO - 2021-07-23 11:58:58 --> Ecac Robo Class Initialized
INFO - 2021-07-23 16:59:59 --> Config Class Initialized
INFO - 2021-07-23 16:59:59 --> Hooks Class Initialized
DEBUG - 2021-07-23 16:59:59 --> UTF-8 Support Enabled
INFO - 2021-07-23 16:59:59 --> Utf8 Class Initialized
INFO - 2021-07-23 16:59:59 --> URI Class Initialized
INFO - 2021-07-23 16:59:59 --> Router Class Initialized
INFO - 2021-07-23 16:59:59 --> Output Class Initialized
INFO - 2021-07-23 16:59:59 --> Security Class Initialized
DEBUG - 2021-07-23 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 16:59:59 --> Input Class Initialized
INFO - 2021-07-23 16:59:59 --> Language Class Initialized
INFO - 2021-07-23 17:00:00 --> Loader Class Initialized
INFO - 2021-07-23 17:00:00 --> Helper loaded: url_helper
INFO - 2021-07-23 17:00:00 --> Helper loaded: form_helper
INFO - 2021-07-23 17:00:00 --> Helper loaded: array_helper
INFO - 2021-07-23 17:00:00 --> Helper loaded: date_helper
INFO - 2021-07-23 17:00:00 --> Helper loaded: html_helper
INFO - 2021-07-23 17:00:00 --> Database Driver Class Initialized
INFO - 2021-07-23 17:00:00 --> Controller Class Initialized
DEBUG - 2021-07-23 17:00:00 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 17:00:00 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 17:00:00 --> Model "Procuracao_model" initialized
INFO - 2021-07-23 12:00:04 --> Ecac Robo Class Initialized
INFO - 2021-07-23 12:00:17 --> Final output sent to browser
DEBUG - 2021-07-23 12:00:17 --> Total execution time: 18.1068
INFO - 2021-07-23 21:54:03 --> Config Class Initialized
INFO - 2021-07-23 21:54:03 --> Hooks Class Initialized
DEBUG - 2021-07-23 21:54:03 --> UTF-8 Support Enabled
INFO - 2021-07-23 21:54:03 --> Utf8 Class Initialized
INFO - 2021-07-23 21:54:03 --> URI Class Initialized
INFO - 2021-07-23 21:54:03 --> Router Class Initialized
INFO - 2021-07-23 21:54:03 --> Output Class Initialized
INFO - 2021-07-23 21:54:03 --> Security Class Initialized
DEBUG - 2021-07-23 21:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 21:54:03 --> Input Class Initialized
INFO - 2021-07-23 21:54:03 --> Language Class Initialized
INFO - 2021-07-23 21:54:03 --> Loader Class Initialized
INFO - 2021-07-23 21:54:03 --> Helper loaded: url_helper
INFO - 2021-07-23 21:54:03 --> Helper loaded: form_helper
INFO - 2021-07-23 21:54:03 --> Helper loaded: array_helper
INFO - 2021-07-23 21:54:03 --> Helper loaded: date_helper
INFO - 2021-07-23 21:54:03 --> Helper loaded: html_helper
INFO - 2021-07-23 21:54:04 --> Database Driver Class Initialized
INFO - 2021-07-23 21:54:04 --> Controller Class Initialized
ERROR - 2021-07-23 21:54:04 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 8
INFO - 2021-07-23 21:57:00 --> Config Class Initialized
INFO - 2021-07-23 21:57:00 --> Hooks Class Initialized
DEBUG - 2021-07-23 21:57:00 --> UTF-8 Support Enabled
INFO - 2021-07-23 21:57:00 --> Utf8 Class Initialized
INFO - 2021-07-23 21:57:00 --> URI Class Initialized
INFO - 2021-07-23 21:57:00 --> Router Class Initialized
INFO - 2021-07-23 21:57:00 --> Output Class Initialized
INFO - 2021-07-23 21:57:00 --> Security Class Initialized
DEBUG - 2021-07-23 21:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 21:57:00 --> Input Class Initialized
INFO - 2021-07-23 21:57:00 --> Language Class Initialized
INFO - 2021-07-23 21:57:00 --> Loader Class Initialized
INFO - 2021-07-23 21:57:00 --> Helper loaded: url_helper
INFO - 2021-07-23 21:57:00 --> Helper loaded: form_helper
INFO - 2021-07-23 21:57:00 --> Helper loaded: array_helper
INFO - 2021-07-23 21:57:00 --> Helper loaded: date_helper
INFO - 2021-07-23 21:57:00 --> Helper loaded: html_helper
INFO - 2021-07-23 21:57:00 --> Database Driver Class Initialized
INFO - 2021-07-23 21:57:00 --> Controller Class Initialized
ERROR - 2021-07-23 21:57:00 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 8
INFO - 2021-07-23 21:58:31 --> Config Class Initialized
INFO - 2021-07-23 21:58:31 --> Hooks Class Initialized
DEBUG - 2021-07-23 21:58:31 --> UTF-8 Support Enabled
INFO - 2021-07-23 21:58:31 --> Utf8 Class Initialized
INFO - 2021-07-23 21:58:31 --> URI Class Initialized
INFO - 2021-07-23 21:58:31 --> Router Class Initialized
INFO - 2021-07-23 21:58:31 --> Output Class Initialized
INFO - 2021-07-23 21:58:31 --> Security Class Initialized
DEBUG - 2021-07-23 21:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 21:58:31 --> Input Class Initialized
INFO - 2021-07-23 21:58:31 --> Language Class Initialized
INFO - 2021-07-23 21:58:31 --> Loader Class Initialized
INFO - 2021-07-23 21:58:31 --> Helper loaded: url_helper
INFO - 2021-07-23 21:58:31 --> Helper loaded: form_helper
INFO - 2021-07-23 21:58:31 --> Helper loaded: array_helper
INFO - 2021-07-23 21:58:31 --> Helper loaded: date_helper
INFO - 2021-07-23 21:58:31 --> Helper loaded: html_helper
INFO - 2021-07-23 21:58:31 --> Database Driver Class Initialized
INFO - 2021-07-23 21:58:31 --> Controller Class Initialized
INFO - 2021-07-23 21:58:31 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 21:58:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 21:58:32 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 21:58:32 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 21:58:32 --> Model "Das_model" initialized
INFO - 2021-07-23 16:58:36 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 16:58:36 --> Severity: Notice --> Undefined variable: ecac_robo_library C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
ERROR - 2021-07-23 16:58:36 --> Severity: error --> Exception: Call to a member function trocar_perfil() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
INFO - 2021-07-23 21:59:45 --> Config Class Initialized
INFO - 2021-07-23 21:59:45 --> Hooks Class Initialized
DEBUG - 2021-07-23 21:59:45 --> UTF-8 Support Enabled
INFO - 2021-07-23 21:59:45 --> Utf8 Class Initialized
INFO - 2021-07-23 21:59:45 --> URI Class Initialized
INFO - 2021-07-23 21:59:45 --> Router Class Initialized
INFO - 2021-07-23 21:59:45 --> Output Class Initialized
INFO - 2021-07-23 21:59:45 --> Security Class Initialized
DEBUG - 2021-07-23 21:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 21:59:45 --> Input Class Initialized
INFO - 2021-07-23 21:59:45 --> Language Class Initialized
INFO - 2021-07-23 21:59:45 --> Loader Class Initialized
INFO - 2021-07-23 21:59:45 --> Helper loaded: url_helper
INFO - 2021-07-23 21:59:45 --> Helper loaded: form_helper
INFO - 2021-07-23 21:59:45 --> Helper loaded: array_helper
INFO - 2021-07-23 21:59:45 --> Helper loaded: date_helper
INFO - 2021-07-23 21:59:45 --> Helper loaded: html_helper
INFO - 2021-07-23 21:59:45 --> Database Driver Class Initialized
INFO - 2021-07-23 21:59:46 --> Controller Class Initialized
INFO - 2021-07-23 21:59:46 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 21:59:46 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 21:59:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 21:59:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 21:59:46 --> Model "Das_model" initialized
INFO - 2021-07-23 16:59:49 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 16:59:49 --> Severity: Notice --> Undefined variable: ecac_robo_library_procuracao C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
ERROR - 2021-07-23 16:59:49 --> Severity: error --> Exception: Call to a member function trocar_perfil() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
INFO - 2021-07-23 22:00:40 --> Config Class Initialized
INFO - 2021-07-23 22:00:40 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:00:40 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:00:40 --> Utf8 Class Initialized
INFO - 2021-07-23 22:00:40 --> URI Class Initialized
INFO - 2021-07-23 22:00:40 --> Router Class Initialized
INFO - 2021-07-23 22:00:40 --> Output Class Initialized
INFO - 2021-07-23 22:00:40 --> Security Class Initialized
DEBUG - 2021-07-23 22:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:00:40 --> Input Class Initialized
INFO - 2021-07-23 22:00:40 --> Language Class Initialized
INFO - 2021-07-23 22:00:40 --> Loader Class Initialized
INFO - 2021-07-23 22:00:40 --> Helper loaded: url_helper
INFO - 2021-07-23 22:00:40 --> Helper loaded: form_helper
INFO - 2021-07-23 22:00:40 --> Helper loaded: array_helper
INFO - 2021-07-23 22:00:40 --> Helper loaded: date_helper
INFO - 2021-07-23 22:00:40 --> Helper loaded: html_helper
INFO - 2021-07-23 22:00:40 --> Database Driver Class Initialized
INFO - 2021-07-23 22:00:40 --> Controller Class Initialized
INFO - 2021-07-23 22:00:40 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:00:40 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:00:40 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:00:40 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:00:40 --> Model "Das_model" initialized
INFO - 2021-07-23 17:00:44 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:00:44 --> Severity: Notice --> Undefined variable: ecac_robo_library_procuracao C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
ERROR - 2021-07-23 17:00:44 --> Severity: Notice --> Undefined property: Das_ecac_procuracao::$ C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
ERROR - 2021-07-23 17:00:44 --> Severity: error --> Exception: Call to a member function trocar_perfil() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 50
INFO - 2021-07-23 22:01:16 --> Config Class Initialized
INFO - 2021-07-23 22:01:16 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:01:16 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:01:16 --> Utf8 Class Initialized
INFO - 2021-07-23 22:01:16 --> URI Class Initialized
INFO - 2021-07-23 22:01:16 --> Router Class Initialized
INFO - 2021-07-23 22:01:16 --> Output Class Initialized
INFO - 2021-07-23 22:01:16 --> Security Class Initialized
DEBUG - 2021-07-23 22:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:01:16 --> Input Class Initialized
INFO - 2021-07-23 22:01:16 --> Language Class Initialized
INFO - 2021-07-23 22:01:16 --> Loader Class Initialized
INFO - 2021-07-23 22:01:16 --> Helper loaded: url_helper
INFO - 2021-07-23 22:01:16 --> Helper loaded: form_helper
INFO - 2021-07-23 22:01:16 --> Helper loaded: array_helper
INFO - 2021-07-23 22:01:16 --> Helper loaded: date_helper
INFO - 2021-07-23 22:01:16 --> Helper loaded: html_helper
INFO - 2021-07-23 22:01:16 --> Database Driver Class Initialized
INFO - 2021-07-23 22:01:16 --> Controller Class Initialized
INFO - 2021-07-23 22:01:16 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:01:16 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:01:16 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:01:16 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:01:16 --> Model "Das_model" initialized
INFO - 2021-07-23 17:01:20 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:01:21 --> Severity: error --> Exception: Call to undefined method Das_model::get_numero_declaracoes() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 56
INFO - 2021-07-23 22:02:08 --> Config Class Initialized
INFO - 2021-07-23 22:02:08 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:02:08 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:02:08 --> Utf8 Class Initialized
INFO - 2021-07-23 22:02:08 --> URI Class Initialized
INFO - 2021-07-23 22:02:08 --> Router Class Initialized
INFO - 2021-07-23 22:02:08 --> Output Class Initialized
INFO - 2021-07-23 22:02:08 --> Security Class Initialized
DEBUG - 2021-07-23 22:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:02:08 --> Input Class Initialized
INFO - 2021-07-23 22:02:08 --> Language Class Initialized
INFO - 2021-07-23 22:02:08 --> Loader Class Initialized
INFO - 2021-07-23 22:02:08 --> Helper loaded: url_helper
INFO - 2021-07-23 22:02:08 --> Helper loaded: form_helper
INFO - 2021-07-23 22:02:08 --> Helper loaded: array_helper
INFO - 2021-07-23 22:02:08 --> Helper loaded: date_helper
INFO - 2021-07-23 22:02:08 --> Helper loaded: html_helper
INFO - 2021-07-23 22:02:08 --> Database Driver Class Initialized
INFO - 2021-07-23 22:02:08 --> Controller Class Initialized
INFO - 2021-07-23 22:02:08 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:02:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:02:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:02:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:02:08 --> Model "Das_model" initialized
INFO - 2021-07-23 17:02:12 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:02:14 --> Severity: error --> Exception: Too few arguments to function Das_model::get_numero_declaracoes(), 1 passed in C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php on line 56 and exactly 2 expected C:\xampp\htdocs\SistemaCronsCertificado\sp\application\models\Das_model.php 79
INFO - 2021-07-23 22:02:50 --> Config Class Initialized
INFO - 2021-07-23 22:02:50 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:02:50 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:02:50 --> Utf8 Class Initialized
INFO - 2021-07-23 22:02:50 --> URI Class Initialized
INFO - 2021-07-23 22:02:50 --> Router Class Initialized
INFO - 2021-07-23 22:02:50 --> Output Class Initialized
INFO - 2021-07-23 22:02:50 --> Security Class Initialized
DEBUG - 2021-07-23 22:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:02:50 --> Input Class Initialized
INFO - 2021-07-23 22:02:50 --> Language Class Initialized
INFO - 2021-07-23 22:02:50 --> Loader Class Initialized
INFO - 2021-07-23 22:02:50 --> Helper loaded: url_helper
INFO - 2021-07-23 22:02:50 --> Helper loaded: form_helper
INFO - 2021-07-23 22:02:50 --> Helper loaded: array_helper
INFO - 2021-07-23 22:02:50 --> Helper loaded: date_helper
INFO - 2021-07-23 22:02:50 --> Helper loaded: html_helper
INFO - 2021-07-23 22:02:50 --> Database Driver Class Initialized
INFO - 2021-07-23 22:02:50 --> Controller Class Initialized
INFO - 2021-07-23 22:02:50 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:02:50 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:02:50 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:02:50 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:02:50 --> Model "Das_model" initialized
INFO - 2021-07-23 17:02:54 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:03:01 --> Final output sent to browser
DEBUG - 2021-07-23 17:03:01 --> Total execution time: 10.9102
INFO - 2021-07-23 22:03:48 --> Config Class Initialized
INFO - 2021-07-23 22:03:48 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:03:48 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:03:48 --> Utf8 Class Initialized
INFO - 2021-07-23 22:03:48 --> URI Class Initialized
INFO - 2021-07-23 22:03:48 --> Router Class Initialized
INFO - 2021-07-23 22:03:48 --> Output Class Initialized
INFO - 2021-07-23 22:03:48 --> Security Class Initialized
DEBUG - 2021-07-23 22:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:03:48 --> Input Class Initialized
INFO - 2021-07-23 22:03:48 --> Language Class Initialized
INFO - 2021-07-23 22:03:48 --> Loader Class Initialized
INFO - 2021-07-23 22:03:48 --> Helper loaded: url_helper
INFO - 2021-07-23 22:03:48 --> Helper loaded: form_helper
INFO - 2021-07-23 22:03:48 --> Helper loaded: array_helper
INFO - 2021-07-23 22:03:48 --> Helper loaded: date_helper
INFO - 2021-07-23 22:03:48 --> Helper loaded: html_helper
INFO - 2021-07-23 22:03:48 --> Database Driver Class Initialized
INFO - 2021-07-23 22:03:48 --> Controller Class Initialized
INFO - 2021-07-23 22:03:48 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:03:48 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:03:48 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:03:48 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:03:48 --> Model "Das_model" initialized
ERROR - 2021-07-23 17:03:48 --> Severity: error --> Exception: syntax error, unexpected '"', expecting ',' or ';' C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1662
INFO - 2021-07-23 22:03:54 --> Config Class Initialized
INFO - 2021-07-23 22:03:54 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:03:54 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:03:54 --> Utf8 Class Initialized
INFO - 2021-07-23 22:03:54 --> URI Class Initialized
INFO - 2021-07-23 22:03:54 --> Router Class Initialized
INFO - 2021-07-23 22:03:54 --> Output Class Initialized
INFO - 2021-07-23 22:03:54 --> Security Class Initialized
DEBUG - 2021-07-23 22:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:03:54 --> Input Class Initialized
INFO - 2021-07-23 22:03:54 --> Language Class Initialized
INFO - 2021-07-23 22:03:54 --> Loader Class Initialized
INFO - 2021-07-23 22:03:54 --> Helper loaded: url_helper
INFO - 2021-07-23 22:03:54 --> Helper loaded: form_helper
INFO - 2021-07-23 22:03:54 --> Helper loaded: array_helper
INFO - 2021-07-23 22:03:54 --> Helper loaded: date_helper
INFO - 2021-07-23 22:03:54 --> Helper loaded: html_helper
INFO - 2021-07-23 22:03:54 --> Database Driver Class Initialized
INFO - 2021-07-23 22:03:54 --> Controller Class Initialized
INFO - 2021-07-23 22:03:54 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:03:54 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:03:54 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:03:54 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:03:54 --> Model "Das_model" initialized
INFO - 2021-07-23 17:03:59 --> Ecac Robo Class Initialized
INFO - 2021-07-23 22:05:27 --> Config Class Initialized
INFO - 2021-07-23 22:05:27 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:05:27 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:05:27 --> Utf8 Class Initialized
INFO - 2021-07-23 22:05:27 --> URI Class Initialized
INFO - 2021-07-23 22:05:27 --> Router Class Initialized
INFO - 2021-07-23 22:05:27 --> Output Class Initialized
INFO - 2021-07-23 22:05:27 --> Security Class Initialized
DEBUG - 2021-07-23 22:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:05:27 --> Input Class Initialized
INFO - 2021-07-23 22:05:27 --> Language Class Initialized
INFO - 2021-07-23 22:05:27 --> Loader Class Initialized
INFO - 2021-07-23 22:05:27 --> Helper loaded: url_helper
INFO - 2021-07-23 22:05:27 --> Helper loaded: form_helper
INFO - 2021-07-23 22:05:27 --> Helper loaded: array_helper
INFO - 2021-07-23 22:05:27 --> Helper loaded: date_helper
INFO - 2021-07-23 22:05:27 --> Helper loaded: html_helper
INFO - 2021-07-23 22:05:27 --> Database Driver Class Initialized
INFO - 2021-07-23 22:05:27 --> Controller Class Initialized
INFO - 2021-07-23 22:05:27 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:05:27 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:05:27 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:05:27 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:05:27 --> Model "Das_model" initialized
INFO - 2021-07-23 17:05:31 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:05:42 --> Final output sent to browser
DEBUG - 2021-07-23 17:05:42 --> Total execution time: 15.2741
INFO - 2021-07-23 22:06:10 --> Config Class Initialized
INFO - 2021-07-23 22:06:10 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:06:10 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:06:10 --> Utf8 Class Initialized
INFO - 2021-07-23 22:06:10 --> URI Class Initialized
INFO - 2021-07-23 22:06:10 --> Router Class Initialized
INFO - 2021-07-23 22:06:10 --> Output Class Initialized
INFO - 2021-07-23 22:06:10 --> Security Class Initialized
DEBUG - 2021-07-23 22:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:06:10 --> Input Class Initialized
INFO - 2021-07-23 22:06:10 --> Language Class Initialized
INFO - 2021-07-23 22:06:10 --> Loader Class Initialized
INFO - 2021-07-23 22:06:10 --> Helper loaded: url_helper
INFO - 2021-07-23 22:06:10 --> Helper loaded: form_helper
INFO - 2021-07-23 22:06:10 --> Helper loaded: array_helper
INFO - 2021-07-23 22:06:10 --> Helper loaded: date_helper
INFO - 2021-07-23 22:06:10 --> Helper loaded: html_helper
INFO - 2021-07-23 22:06:10 --> Database Driver Class Initialized
INFO - 2021-07-23 22:06:11 --> Controller Class Initialized
INFO - 2021-07-23 22:06:11 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:06:11 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:06:11 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:06:11 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:06:11 --> Model "Das_model" initialized
INFO - 2021-07-23 17:06:14 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:06:25 --> Final output sent to browser
DEBUG - 2021-07-23 17:06:25 --> Total execution time: 15.0493
INFO - 2021-07-23 22:08:30 --> Config Class Initialized
INFO - 2021-07-23 22:08:30 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:08:30 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:08:30 --> Utf8 Class Initialized
INFO - 2021-07-23 22:08:30 --> URI Class Initialized
INFO - 2021-07-23 22:08:30 --> Router Class Initialized
INFO - 2021-07-23 22:08:30 --> Output Class Initialized
INFO - 2021-07-23 22:08:30 --> Security Class Initialized
DEBUG - 2021-07-23 22:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:08:30 --> Input Class Initialized
INFO - 2021-07-23 22:08:30 --> Language Class Initialized
INFO - 2021-07-23 22:08:30 --> Loader Class Initialized
INFO - 2021-07-23 22:08:30 --> Helper loaded: url_helper
INFO - 2021-07-23 22:08:30 --> Helper loaded: form_helper
INFO - 2021-07-23 22:08:30 --> Helper loaded: array_helper
INFO - 2021-07-23 22:08:30 --> Helper loaded: date_helper
INFO - 2021-07-23 22:08:30 --> Helper loaded: html_helper
INFO - 2021-07-23 22:08:30 --> Database Driver Class Initialized
INFO - 2021-07-23 22:08:31 --> Controller Class Initialized
INFO - 2021-07-23 22:08:31 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:08:31 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:08:31 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:08:31 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:08:31 --> Model "Das_model" initialized
INFO - 2021-07-23 17:08:34 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:08:45 --> Final output sent to browser
DEBUG - 2021-07-23 17:08:45 --> Total execution time: 15.1037
INFO - 2021-07-23 22:09:16 --> Config Class Initialized
INFO - 2021-07-23 22:09:16 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:09:16 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:09:16 --> Utf8 Class Initialized
INFO - 2021-07-23 22:09:16 --> URI Class Initialized
INFO - 2021-07-23 22:09:16 --> Router Class Initialized
INFO - 2021-07-23 22:09:16 --> Output Class Initialized
INFO - 2021-07-23 22:09:16 --> Security Class Initialized
DEBUG - 2021-07-23 22:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:09:16 --> Input Class Initialized
INFO - 2021-07-23 22:09:16 --> Language Class Initialized
INFO - 2021-07-23 22:09:16 --> Loader Class Initialized
INFO - 2021-07-23 22:09:16 --> Helper loaded: url_helper
INFO - 2021-07-23 22:09:16 --> Helper loaded: form_helper
INFO - 2021-07-23 22:09:16 --> Helper loaded: array_helper
INFO - 2021-07-23 22:09:16 --> Helper loaded: date_helper
INFO - 2021-07-23 22:09:16 --> Helper loaded: html_helper
INFO - 2021-07-23 22:09:16 --> Database Driver Class Initialized
INFO - 2021-07-23 22:09:16 --> Controller Class Initialized
INFO - 2021-07-23 22:09:16 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:09:16 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:09:16 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:09:16 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:09:16 --> Model "Das_model" initialized
INFO - 2021-07-23 17:09:19 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:09:31 --> Final output sent to browser
DEBUG - 2021-07-23 17:09:31 --> Total execution time: 14.8800
INFO - 2021-07-23 22:11:35 --> Config Class Initialized
INFO - 2021-07-23 22:11:35 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:11:35 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:11:35 --> Utf8 Class Initialized
INFO - 2021-07-23 22:11:35 --> URI Class Initialized
INFO - 2021-07-23 22:11:35 --> Router Class Initialized
INFO - 2021-07-23 22:11:35 --> Output Class Initialized
INFO - 2021-07-23 22:11:35 --> Security Class Initialized
DEBUG - 2021-07-23 22:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:11:35 --> Input Class Initialized
INFO - 2021-07-23 22:11:35 --> Language Class Initialized
INFO - 2021-07-23 22:11:35 --> Loader Class Initialized
INFO - 2021-07-23 22:11:35 --> Helper loaded: url_helper
INFO - 2021-07-23 22:11:35 --> Helper loaded: form_helper
INFO - 2021-07-23 22:11:35 --> Helper loaded: array_helper
INFO - 2021-07-23 22:11:35 --> Helper loaded: date_helper
INFO - 2021-07-23 22:11:35 --> Helper loaded: html_helper
INFO - 2021-07-23 22:11:35 --> Database Driver Class Initialized
INFO - 2021-07-23 22:11:35 --> Controller Class Initialized
DEBUG - 2021-07-23 22:11:35 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:11:35 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:11:35 --> Model "Procuracao_model" initialized
INFO - 2021-07-23 17:11:38 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:11:52 --> Final output sent to browser
DEBUG - 2021-07-23 17:11:52 --> Total execution time: 17.2801
INFO - 2021-07-23 22:13:25 --> Config Class Initialized
INFO - 2021-07-23 22:13:25 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:13:25 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:13:25 --> Utf8 Class Initialized
INFO - 2021-07-23 22:13:25 --> URI Class Initialized
INFO - 2021-07-23 22:13:25 --> Router Class Initialized
INFO - 2021-07-23 22:13:25 --> Output Class Initialized
INFO - 2021-07-23 22:13:25 --> Security Class Initialized
DEBUG - 2021-07-23 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:13:25 --> Input Class Initialized
INFO - 2021-07-23 22:13:25 --> Language Class Initialized
INFO - 2021-07-23 22:13:25 --> Loader Class Initialized
INFO - 2021-07-23 22:13:25 --> Helper loaded: url_helper
INFO - 2021-07-23 22:13:25 --> Helper loaded: form_helper
INFO - 2021-07-23 22:13:25 --> Helper loaded: array_helper
INFO - 2021-07-23 22:13:25 --> Helper loaded: date_helper
INFO - 2021-07-23 22:13:25 --> Helper loaded: html_helper
INFO - 2021-07-23 22:13:25 --> Database Driver Class Initialized
INFO - 2021-07-23 22:13:25 --> Controller Class Initialized
INFO - 2021-07-23 22:13:25 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:13:25 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:13:25 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:13:25 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:13:25 --> Model "Das_model" initialized
INFO - 2021-07-23 17:13:29 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:13:40 --> Final output sent to browser
DEBUG - 2021-07-23 17:13:40 --> Total execution time: 14.9643
INFO - 2021-07-23 22:14:11 --> Config Class Initialized
INFO - 2021-07-23 22:14:11 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:14:11 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:14:11 --> Utf8 Class Initialized
INFO - 2021-07-23 22:14:11 --> URI Class Initialized
INFO - 2021-07-23 22:14:11 --> Router Class Initialized
INFO - 2021-07-23 22:14:11 --> Output Class Initialized
INFO - 2021-07-23 22:14:11 --> Security Class Initialized
DEBUG - 2021-07-23 22:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:14:11 --> Input Class Initialized
INFO - 2021-07-23 22:14:11 --> Language Class Initialized
INFO - 2021-07-23 22:14:11 --> Loader Class Initialized
INFO - 2021-07-23 22:14:11 --> Helper loaded: url_helper
INFO - 2021-07-23 22:14:11 --> Helper loaded: form_helper
INFO - 2021-07-23 22:14:11 --> Helper loaded: array_helper
INFO - 2021-07-23 22:14:11 --> Helper loaded: date_helper
INFO - 2021-07-23 22:14:11 --> Helper loaded: html_helper
INFO - 2021-07-23 22:14:11 --> Database Driver Class Initialized
INFO - 2021-07-23 22:14:11 --> Controller Class Initialized
INFO - 2021-07-23 22:14:11 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:14:11 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:14:11 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:14:11 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:14:11 --> Model "Das_model" initialized
INFO - 2021-07-23 17:14:14 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:14:26 --> Final output sent to browser
DEBUG - 2021-07-23 17:14:26 --> Total execution time: 14.8706
INFO - 2021-07-23 22:18:14 --> Config Class Initialized
INFO - 2021-07-23 22:18:14 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:18:14 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:18:14 --> Utf8 Class Initialized
INFO - 2021-07-23 22:18:14 --> URI Class Initialized
INFO - 2021-07-23 22:18:14 --> Router Class Initialized
INFO - 2021-07-23 22:18:14 --> Output Class Initialized
INFO - 2021-07-23 22:18:14 --> Security Class Initialized
DEBUG - 2021-07-23 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:18:14 --> Input Class Initialized
INFO - 2021-07-23 22:18:14 --> Language Class Initialized
INFO - 2021-07-23 22:18:14 --> Loader Class Initialized
INFO - 2021-07-23 22:18:14 --> Helper loaded: url_helper
INFO - 2021-07-23 22:18:14 --> Helper loaded: form_helper
INFO - 2021-07-23 22:18:14 --> Helper loaded: array_helper
INFO - 2021-07-23 22:18:14 --> Helper loaded: date_helper
INFO - 2021-07-23 22:18:14 --> Helper loaded: html_helper
INFO - 2021-07-23 22:18:14 --> Database Driver Class Initialized
INFO - 2021-07-23 22:18:14 --> Controller Class Initialized
INFO - 2021-07-23 22:18:14 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:18:14 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:18:14 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:18:14 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:18:14 --> Model "Das_model" initialized
INFO - 2021-07-23 17:18:18 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:18:26 --> Severity: error --> Exception: Call to undefined method Das_ecac_procuracao::upload_google() C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 78
ERROR - 2021-07-23 17:18:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php:1665) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:19:45 --> Config Class Initialized
INFO - 2021-07-23 22:19:45 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:19:46 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:19:46 --> Utf8 Class Initialized
INFO - 2021-07-23 22:19:46 --> URI Class Initialized
INFO - 2021-07-23 22:19:46 --> Router Class Initialized
INFO - 2021-07-23 22:19:46 --> Output Class Initialized
INFO - 2021-07-23 22:19:46 --> Security Class Initialized
DEBUG - 2021-07-23 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:19:46 --> Input Class Initialized
INFO - 2021-07-23 22:19:46 --> Language Class Initialized
INFO - 2021-07-23 22:19:46 --> Loader Class Initialized
INFO - 2021-07-23 22:19:46 --> Helper loaded: url_helper
INFO - 2021-07-23 22:19:46 --> Helper loaded: form_helper
INFO - 2021-07-23 22:19:46 --> Helper loaded: array_helper
INFO - 2021-07-23 22:19:46 --> Helper loaded: date_helper
INFO - 2021-07-23 22:19:46 --> Helper loaded: html_helper
INFO - 2021-07-23 22:19:46 --> Database Driver Class Initialized
INFO - 2021-07-23 22:19:46 --> Controller Class Initialized
INFO - 2021-07-23 22:19:46 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:19:46 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:19:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:19:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:19:46 --> Model "Das_model" initialized
INFO - 2021-07-23 17:19:49 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:20:14 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:20:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php:1665) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:21:26 --> Config Class Initialized
INFO - 2021-07-23 22:21:26 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:21:26 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:21:26 --> Utf8 Class Initialized
INFO - 2021-07-23 22:21:26 --> URI Class Initialized
INFO - 2021-07-23 22:21:26 --> Router Class Initialized
INFO - 2021-07-23 22:21:26 --> Output Class Initialized
INFO - 2021-07-23 22:21:26 --> Security Class Initialized
DEBUG - 2021-07-23 22:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:21:26 --> Input Class Initialized
INFO - 2021-07-23 22:21:26 --> Language Class Initialized
INFO - 2021-07-23 22:21:26 --> Loader Class Initialized
INFO - 2021-07-23 22:21:26 --> Helper loaded: url_helper
INFO - 2021-07-23 22:21:26 --> Helper loaded: form_helper
INFO - 2021-07-23 22:21:26 --> Helper loaded: array_helper
INFO - 2021-07-23 22:21:26 --> Helper loaded: date_helper
INFO - 2021-07-23 22:21:26 --> Helper loaded: html_helper
INFO - 2021-07-23 22:21:26 --> Database Driver Class Initialized
INFO - 2021-07-23 22:21:27 --> Controller Class Initialized
INFO - 2021-07-23 22:21:27 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:21:27 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:21:27 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:21:27 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:21:27 --> Model "Das_model" initialized
INFO - 2021-07-23 17:21:30 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:21:47 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:21:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php:1665) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:22:27 --> Config Class Initialized
INFO - 2021-07-23 22:22:27 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:22:27 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:22:27 --> Utf8 Class Initialized
INFO - 2021-07-23 22:22:27 --> URI Class Initialized
INFO - 2021-07-23 22:22:27 --> Router Class Initialized
INFO - 2021-07-23 22:22:27 --> Output Class Initialized
INFO - 2021-07-23 22:22:27 --> Security Class Initialized
DEBUG - 2021-07-23 22:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:22:27 --> Input Class Initialized
INFO - 2021-07-23 22:22:27 --> Language Class Initialized
INFO - 2021-07-23 22:22:27 --> Loader Class Initialized
INFO - 2021-07-23 22:22:27 --> Helper loaded: url_helper
INFO - 2021-07-23 22:22:27 --> Helper loaded: form_helper
INFO - 2021-07-23 22:22:27 --> Helper loaded: array_helper
INFO - 2021-07-23 22:22:27 --> Helper loaded: date_helper
INFO - 2021-07-23 22:22:27 --> Helper loaded: html_helper
INFO - 2021-07-23 22:22:27 --> Database Driver Class Initialized
INFO - 2021-07-23 22:22:27 --> Controller Class Initialized
INFO - 2021-07-23 22:22:27 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:22:27 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:22:27 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:22:27 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:22:27 --> Model "Das_model" initialized
INFO - 2021-07-23 17:22:30 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:22:48 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:22:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:23:28 --> Config Class Initialized
INFO - 2021-07-23 22:23:28 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:23:28 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:23:28 --> Utf8 Class Initialized
INFO - 2021-07-23 22:23:28 --> URI Class Initialized
INFO - 2021-07-23 22:23:28 --> Router Class Initialized
INFO - 2021-07-23 22:23:28 --> Output Class Initialized
INFO - 2021-07-23 22:23:28 --> Security Class Initialized
DEBUG - 2021-07-23 22:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:23:28 --> Input Class Initialized
INFO - 2021-07-23 22:23:28 --> Language Class Initialized
INFO - 2021-07-23 22:23:28 --> Loader Class Initialized
INFO - 2021-07-23 22:23:28 --> Helper loaded: url_helper
INFO - 2021-07-23 22:23:28 --> Helper loaded: form_helper
INFO - 2021-07-23 22:23:28 --> Helper loaded: array_helper
INFO - 2021-07-23 22:23:28 --> Helper loaded: date_helper
INFO - 2021-07-23 22:23:28 --> Helper loaded: html_helper
INFO - 2021-07-23 22:23:28 --> Database Driver Class Initialized
INFO - 2021-07-23 22:23:28 --> Controller Class Initialized
INFO - 2021-07-23 22:23:28 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:23:28 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:23:28 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:23:28 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:23:28 --> Model "Das_model" initialized
INFO - 2021-07-23 17:23:32 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:23:55 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:23:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:24:41 --> Config Class Initialized
INFO - 2021-07-23 22:24:41 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:24:41 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:24:41 --> Utf8 Class Initialized
INFO - 2021-07-23 22:24:41 --> URI Class Initialized
INFO - 2021-07-23 22:24:41 --> Router Class Initialized
INFO - 2021-07-23 22:24:41 --> Output Class Initialized
INFO - 2021-07-23 22:24:41 --> Security Class Initialized
DEBUG - 2021-07-23 22:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:24:41 --> Input Class Initialized
INFO - 2021-07-23 22:24:41 --> Language Class Initialized
INFO - 2021-07-23 22:24:41 --> Loader Class Initialized
INFO - 2021-07-23 22:24:41 --> Helper loaded: url_helper
INFO - 2021-07-23 22:24:41 --> Helper loaded: form_helper
INFO - 2021-07-23 22:24:41 --> Helper loaded: array_helper
INFO - 2021-07-23 22:24:41 --> Helper loaded: date_helper
INFO - 2021-07-23 22:24:41 --> Helper loaded: html_helper
INFO - 2021-07-23 22:24:41 --> Database Driver Class Initialized
INFO - 2021-07-23 22:24:41 --> Controller Class Initialized
INFO - 2021-07-23 22:24:41 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:24:41 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:24:41 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:24:41 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:24:41 --> Model "Das_model" initialized
INFO - 2021-07-23 17:24:45 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:25:02 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:25:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:30:08 --> Config Class Initialized
INFO - 2021-07-23 22:30:08 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:30:08 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:30:08 --> Utf8 Class Initialized
INFO - 2021-07-23 22:30:08 --> URI Class Initialized
INFO - 2021-07-23 22:30:08 --> Router Class Initialized
INFO - 2021-07-23 22:30:08 --> Output Class Initialized
INFO - 2021-07-23 22:30:08 --> Security Class Initialized
DEBUG - 2021-07-23 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:30:08 --> Input Class Initialized
INFO - 2021-07-23 22:30:08 --> Language Class Initialized
INFO - 2021-07-23 22:30:08 --> Loader Class Initialized
INFO - 2021-07-23 22:30:08 --> Helper loaded: url_helper
INFO - 2021-07-23 22:30:08 --> Helper loaded: form_helper
INFO - 2021-07-23 22:30:08 --> Helper loaded: array_helper
INFO - 2021-07-23 22:30:08 --> Helper loaded: date_helper
INFO - 2021-07-23 22:30:08 --> Helper loaded: html_helper
INFO - 2021-07-23 22:30:08 --> Database Driver Class Initialized
INFO - 2021-07-23 22:30:08 --> Controller Class Initialized
INFO - 2021-07-23 22:30:08 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:30:08 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:30:08 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:30:08 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:30:08 --> Model "Das_model" initialized
INFO - 2021-07-23 17:30:12 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:30:37 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:30:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:32:48 --> Config Class Initialized
INFO - 2021-07-23 22:32:48 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:32:48 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:32:48 --> Utf8 Class Initialized
INFO - 2021-07-23 22:32:48 --> URI Class Initialized
INFO - 2021-07-23 22:32:48 --> Router Class Initialized
INFO - 2021-07-23 22:32:48 --> Output Class Initialized
INFO - 2021-07-23 22:32:48 --> Security Class Initialized
DEBUG - 2021-07-23 22:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:32:48 --> Input Class Initialized
INFO - 2021-07-23 22:32:48 --> Language Class Initialized
INFO - 2021-07-23 22:32:48 --> Loader Class Initialized
INFO - 2021-07-23 22:32:48 --> Helper loaded: url_helper
INFO - 2021-07-23 22:32:48 --> Helper loaded: form_helper
INFO - 2021-07-23 22:32:48 --> Helper loaded: array_helper
INFO - 2021-07-23 22:32:48 --> Helper loaded: date_helper
INFO - 2021-07-23 22:32:48 --> Helper loaded: html_helper
INFO - 2021-07-23 22:32:48 --> Database Driver Class Initialized
INFO - 2021-07-23 22:32:48 --> Controller Class Initialized
INFO - 2021-07-23 22:32:48 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:32:48 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:32:48 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:32:48 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:32:48 --> Model "Das_model" initialized
ERROR - 2021-07-23 17:32:48 --> Severity: Compile Error --> 'continue' not in the 'loop' or 'switch' context C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1009
INFO - 2021-07-23 22:33:09 --> Config Class Initialized
INFO - 2021-07-23 22:33:09 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:33:09 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:33:09 --> Utf8 Class Initialized
INFO - 2021-07-23 22:33:09 --> URI Class Initialized
INFO - 2021-07-23 22:33:09 --> Router Class Initialized
INFO - 2021-07-23 22:33:09 --> Output Class Initialized
INFO - 2021-07-23 22:33:09 --> Security Class Initialized
DEBUG - 2021-07-23 22:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:33:09 --> Input Class Initialized
INFO - 2021-07-23 22:33:09 --> Language Class Initialized
INFO - 2021-07-23 22:33:09 --> Loader Class Initialized
INFO - 2021-07-23 22:33:09 --> Helper loaded: url_helper
INFO - 2021-07-23 22:33:09 --> Helper loaded: form_helper
INFO - 2021-07-23 22:33:09 --> Helper loaded: array_helper
INFO - 2021-07-23 22:33:09 --> Helper loaded: date_helper
INFO - 2021-07-23 22:33:09 --> Helper loaded: html_helper
INFO - 2021-07-23 22:33:09 --> Database Driver Class Initialized
INFO - 2021-07-23 22:33:09 --> Controller Class Initialized
INFO - 2021-07-23 22:33:09 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:33:09 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:33:09 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:33:09 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:33:09 --> Model "Das_model" initialized
INFO - 2021-07-23 17:33:12 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:33:31 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
INFO - 2021-07-23 17:33:31 --> Final output sent to browser
DEBUG - 2021-07-23 17:33:31 --> Total execution time: 22.2420
INFO - 2021-07-23 22:34:46 --> Config Class Initialized
INFO - 2021-07-23 22:34:46 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:34:46 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:34:46 --> Utf8 Class Initialized
INFO - 2021-07-23 22:34:46 --> URI Class Initialized
INFO - 2021-07-23 22:34:46 --> Router Class Initialized
INFO - 2021-07-23 22:34:46 --> Output Class Initialized
INFO - 2021-07-23 22:34:46 --> Security Class Initialized
DEBUG - 2021-07-23 22:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:34:46 --> Input Class Initialized
INFO - 2021-07-23 22:34:46 --> Language Class Initialized
INFO - 2021-07-23 22:34:46 --> Loader Class Initialized
INFO - 2021-07-23 22:34:46 --> Helper loaded: url_helper
INFO - 2021-07-23 22:34:46 --> Helper loaded: form_helper
INFO - 2021-07-23 22:34:46 --> Helper loaded: array_helper
INFO - 2021-07-23 22:34:46 --> Helper loaded: date_helper
INFO - 2021-07-23 22:34:46 --> Helper loaded: html_helper
INFO - 2021-07-23 22:34:46 --> Database Driver Class Initialized
INFO - 2021-07-23 22:34:46 --> Controller Class Initialized
INFO - 2021-07-23 22:34:46 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:34:46 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:34:46 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:34:46 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:34:46 --> Model "Das_model" initialized
INFO - 2021-07-23 17:34:49 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:35:12 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
INFO - 2021-07-23 17:35:12 --> Final output sent to browser
DEBUG - 2021-07-23 17:35:12 --> Total execution time: 26.5712
INFO - 2021-07-23 22:36:54 --> Config Class Initialized
INFO - 2021-07-23 22:36:54 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:36:54 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:36:54 --> Utf8 Class Initialized
INFO - 2021-07-23 22:36:54 --> URI Class Initialized
INFO - 2021-07-23 22:36:54 --> Router Class Initialized
INFO - 2021-07-23 22:36:54 --> Output Class Initialized
INFO - 2021-07-23 22:36:54 --> Security Class Initialized
DEBUG - 2021-07-23 22:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:36:54 --> Input Class Initialized
INFO - 2021-07-23 22:36:54 --> Language Class Initialized
INFO - 2021-07-23 22:36:54 --> Loader Class Initialized
INFO - 2021-07-23 22:36:54 --> Helper loaded: url_helper
INFO - 2021-07-23 22:36:54 --> Helper loaded: form_helper
INFO - 2021-07-23 22:36:54 --> Helper loaded: array_helper
INFO - 2021-07-23 22:36:54 --> Helper loaded: date_helper
INFO - 2021-07-23 22:36:54 --> Helper loaded: html_helper
INFO - 2021-07-23 22:36:54 --> Database Driver Class Initialized
INFO - 2021-07-23 22:36:54 --> Controller Class Initialized
INFO - 2021-07-23 22:36:54 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:36:54 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:36:54 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:36:54 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:36:54 --> Model "Das_model" initialized
INFO - 2021-07-23 17:36:58 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 981
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 982
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 983
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 984
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 986
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 991
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 992
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 994
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 996
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 997
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 601
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 602
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 603
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 608
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 609
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 610
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 611
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 612
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 613
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 614
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 615
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 616
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> curl_errno() expects parameter 1 to be resource, null given C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 617
ERROR - 2021-07-23 17:37:16 --> Severity: error --> Exception: Call to a member function find() on null C:\xampp\htdocs\SistemaCronsCertificado\sp\application\libraries\Ecac_robo_library_eprocessos_procuracao.php 1008
ERROR - 2021-07-23 17:37:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Exceptions.php:271) C:\xampp\htdocs\SistemaCronsCertificado\sp\system\core\Common.php 570
INFO - 2021-07-23 22:41:28 --> Config Class Initialized
INFO - 2021-07-23 22:41:28 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:41:28 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:41:28 --> Utf8 Class Initialized
INFO - 2021-07-23 22:41:28 --> URI Class Initialized
INFO - 2021-07-23 22:41:28 --> Router Class Initialized
INFO - 2021-07-23 22:41:28 --> Output Class Initialized
INFO - 2021-07-23 22:41:28 --> Security Class Initialized
DEBUG - 2021-07-23 22:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:41:28 --> Input Class Initialized
INFO - 2021-07-23 22:41:28 --> Language Class Initialized
INFO - 2021-07-23 22:41:28 --> Loader Class Initialized
INFO - 2021-07-23 22:41:28 --> Helper loaded: url_helper
INFO - 2021-07-23 22:41:28 --> Helper loaded: form_helper
INFO - 2021-07-23 22:41:28 --> Helper loaded: array_helper
INFO - 2021-07-23 22:41:28 --> Helper loaded: date_helper
INFO - 2021-07-23 22:41:28 --> Helper loaded: html_helper
INFO - 2021-07-23 22:41:28 --> Database Driver Class Initialized
INFO - 2021-07-23 22:41:29 --> Controller Class Initialized
INFO - 2021-07-23 22:41:29 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:41:29 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:41:29 --> Model "Situacao_cadin_model" initialized
INFO - 2021-07-23 17:41:33 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:42:01 --> Final output sent to browser
DEBUG - 2021-07-23 17:42:01 --> Total execution time: 33.0912
INFO - 2021-07-23 22:54:53 --> Config Class Initialized
INFO - 2021-07-23 22:54:53 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:54:53 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:54:53 --> Utf8 Class Initialized
INFO - 2021-07-23 22:54:53 --> URI Class Initialized
INFO - 2021-07-23 22:54:53 --> Router Class Initialized
INFO - 2021-07-23 22:54:53 --> Output Class Initialized
INFO - 2021-07-23 22:54:53 --> Security Class Initialized
DEBUG - 2021-07-23 22:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:54:53 --> Input Class Initialized
INFO - 2021-07-23 22:54:53 --> Language Class Initialized
INFO - 2021-07-23 22:54:53 --> Loader Class Initialized
INFO - 2021-07-23 22:54:53 --> Helper loaded: url_helper
INFO - 2021-07-23 22:54:53 --> Helper loaded: form_helper
INFO - 2021-07-23 22:54:53 --> Helper loaded: array_helper
INFO - 2021-07-23 22:54:53 --> Helper loaded: date_helper
INFO - 2021-07-23 22:54:53 --> Helper loaded: html_helper
INFO - 2021-07-23 22:54:53 --> Database Driver Class Initialized
INFO - 2021-07-23 22:54:53 --> Controller Class Initialized
INFO - 2021-07-23 22:54:53 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:54:53 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:54:53 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:54:53 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:54:53 --> Model "Das_model" initialized
INFO - 2021-07-23 17:54:57 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 17:54:57 --> Severity: Notice --> Undefined variable: cnpj C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 66
ERROR - 2021-07-23 17:54:57 --> Severity: Notice --> Undefined variable: cnpj C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 66
ERROR - 2021-07-23 17:54:57 --> Severity: Notice --> Undefined variable: cnpj C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 66
ERROR - 2021-07-23 17:54:57 --> Severity: Notice --> Undefined variable: cnpj C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 66
ERROR - 2021-07-23 17:54:58 --> Severity: Notice --> Undefined variable: cnpj C:\xampp\htdocs\SistemaCronsCertificado\sp\application\controllers\Das_ecac_procuracao.php 66
INFO - 2021-07-23 17:54:58 --> Final output sent to browser
DEBUG - 2021-07-23 17:54:58 --> Total execution time: 4.4785
INFO - 2021-07-23 22:56:23 --> Config Class Initialized
INFO - 2021-07-23 22:56:23 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:56:23 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:56:23 --> Utf8 Class Initialized
INFO - 2021-07-23 22:56:23 --> URI Class Initialized
INFO - 2021-07-23 22:56:23 --> Router Class Initialized
INFO - 2021-07-23 22:56:23 --> Output Class Initialized
INFO - 2021-07-23 22:56:23 --> Security Class Initialized
DEBUG - 2021-07-23 22:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:56:23 --> Input Class Initialized
INFO - 2021-07-23 22:56:23 --> Language Class Initialized
INFO - 2021-07-23 22:56:23 --> Loader Class Initialized
INFO - 2021-07-23 22:56:23 --> Helper loaded: url_helper
INFO - 2021-07-23 22:56:23 --> Helper loaded: form_helper
INFO - 2021-07-23 22:56:23 --> Helper loaded: array_helper
INFO - 2021-07-23 22:56:23 --> Helper loaded: date_helper
INFO - 2021-07-23 22:56:23 --> Helper loaded: html_helper
INFO - 2021-07-23 22:56:23 --> Database Driver Class Initialized
INFO - 2021-07-23 22:56:24 --> Controller Class Initialized
INFO - 2021-07-23 22:56:24 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:56:24 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:56:24 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:56:24 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:56:24 --> Model "Das_model" initialized
INFO - 2021-07-23 17:56:27 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:56:28 --> Final output sent to browser
DEBUG - 2021-07-23 17:56:28 --> Total execution time: 4.3478
INFO - 2021-07-23 22:57:43 --> Config Class Initialized
INFO - 2021-07-23 22:57:43 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:57:43 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:57:43 --> Utf8 Class Initialized
INFO - 2021-07-23 22:57:43 --> URI Class Initialized
INFO - 2021-07-23 22:57:43 --> Router Class Initialized
INFO - 2021-07-23 22:57:43 --> Output Class Initialized
INFO - 2021-07-23 22:57:43 --> Security Class Initialized
DEBUG - 2021-07-23 22:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:57:43 --> Input Class Initialized
INFO - 2021-07-23 22:57:43 --> Language Class Initialized
INFO - 2021-07-23 22:57:43 --> Loader Class Initialized
INFO - 2021-07-23 22:57:43 --> Helper loaded: url_helper
INFO - 2021-07-23 22:57:43 --> Helper loaded: form_helper
INFO - 2021-07-23 22:57:43 --> Helper loaded: array_helper
INFO - 2021-07-23 22:57:43 --> Helper loaded: date_helper
INFO - 2021-07-23 22:57:43 --> Helper loaded: html_helper
INFO - 2021-07-23 22:57:43 --> Database Driver Class Initialized
INFO - 2021-07-23 22:57:43 --> Controller Class Initialized
INFO - 2021-07-23 22:57:43 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:57:43 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:57:43 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:57:43 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:57:43 --> Model "Das_model" initialized
INFO - 2021-07-23 17:57:47 --> Ecac Robo Class Initialized
INFO - 2021-07-23 17:57:47 --> Final output sent to browser
DEBUG - 2021-07-23 17:57:47 --> Total execution time: 4.4836
INFO - 2021-07-23 22:58:16 --> Config Class Initialized
INFO - 2021-07-23 22:58:16 --> Hooks Class Initialized
DEBUG - 2021-07-23 22:58:16 --> UTF-8 Support Enabled
INFO - 2021-07-23 22:58:16 --> Utf8 Class Initialized
INFO - 2021-07-23 22:58:16 --> URI Class Initialized
INFO - 2021-07-23 22:58:16 --> Router Class Initialized
INFO - 2021-07-23 22:58:16 --> Output Class Initialized
INFO - 2021-07-23 22:58:16 --> Security Class Initialized
DEBUG - 2021-07-23 22:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 22:58:16 --> Input Class Initialized
INFO - 2021-07-23 22:58:16 --> Language Class Initialized
INFO - 2021-07-23 22:58:16 --> Loader Class Initialized
INFO - 2021-07-23 22:58:16 --> Helper loaded: url_helper
INFO - 2021-07-23 22:58:16 --> Helper loaded: form_helper
INFO - 2021-07-23 22:58:16 --> Helper loaded: array_helper
INFO - 2021-07-23 22:58:16 --> Helper loaded: date_helper
INFO - 2021-07-23 22:58:16 --> Helper loaded: html_helper
INFO - 2021-07-23 22:58:16 --> Database Driver Class Initialized
INFO - 2021-07-23 22:58:16 --> Controller Class Initialized
INFO - 2021-07-23 22:58:16 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 22:58:16 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 22:58:16 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 22:58:16 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 22:58:16 --> Model "Das_model" initialized
INFO - 2021-07-23 17:58:19 --> Ecac Robo Class Initialized
INFO - 2021-07-23 23:02:54 --> Config Class Initialized
INFO - 2021-07-23 23:02:54 --> Hooks Class Initialized
DEBUG - 2021-07-23 23:02:54 --> UTF-8 Support Enabled
INFO - 2021-07-23 23:02:54 --> Utf8 Class Initialized
INFO - 2021-07-23 23:02:54 --> URI Class Initialized
INFO - 2021-07-23 23:02:54 --> Router Class Initialized
INFO - 2021-07-23 23:02:54 --> Output Class Initialized
INFO - 2021-07-23 23:02:54 --> Security Class Initialized
DEBUG - 2021-07-23 23:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 23:02:54 --> Input Class Initialized
INFO - 2021-07-23 23:02:54 --> Language Class Initialized
INFO - 2021-07-23 23:02:54 --> Loader Class Initialized
INFO - 2021-07-23 23:02:54 --> Helper loaded: url_helper
INFO - 2021-07-23 23:02:54 --> Helper loaded: form_helper
INFO - 2021-07-23 23:02:54 --> Helper loaded: array_helper
INFO - 2021-07-23 23:02:54 --> Helper loaded: date_helper
INFO - 2021-07-23 23:02:54 --> Helper loaded: html_helper
INFO - 2021-07-23 23:02:54 --> Database Driver Class Initialized
INFO - 2021-07-23 23:02:54 --> Controller Class Initialized
INFO - 2021-07-23 23:02:54 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 23:02:54 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 23:02:54 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 23:02:54 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 23:02:54 --> Model "Das_model" initialized
INFO - 2021-07-23 18:02:58 --> Ecac Robo Class Initialized
INFO - 2021-07-23 18:03:06 --> Final output sent to browser
DEBUG - 2021-07-23 18:03:06 --> Total execution time: 12.3834
INFO - 2021-07-23 23:12:30 --> Config Class Initialized
INFO - 2021-07-23 23:12:30 --> Hooks Class Initialized
DEBUG - 2021-07-23 23:12:30 --> UTF-8 Support Enabled
INFO - 2021-07-23 23:12:30 --> Utf8 Class Initialized
INFO - 2021-07-23 23:12:30 --> URI Class Initialized
INFO - 2021-07-23 23:12:30 --> Router Class Initialized
INFO - 2021-07-23 23:12:30 --> Output Class Initialized
INFO - 2021-07-23 23:12:30 --> Security Class Initialized
DEBUG - 2021-07-23 23:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 23:12:30 --> Input Class Initialized
INFO - 2021-07-23 23:12:30 --> Language Class Initialized
INFO - 2021-07-23 23:12:30 --> Loader Class Initialized
INFO - 2021-07-23 23:12:30 --> Helper loaded: url_helper
INFO - 2021-07-23 23:12:30 --> Helper loaded: form_helper
INFO - 2021-07-23 23:12:30 --> Helper loaded: array_helper
INFO - 2021-07-23 23:12:30 --> Helper loaded: date_helper
INFO - 2021-07-23 23:12:30 --> Helper loaded: html_helper
INFO - 2021-07-23 23:12:30 --> Database Driver Class Initialized
INFO - 2021-07-23 23:12:30 --> Controller Class Initialized
INFO - 2021-07-23 23:12:30 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 23:12:30 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 23:12:30 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 23:12:30 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 23:12:30 --> Model "Das_model" initialized
INFO - 2021-07-23 18:12:34 --> Ecac Robo Class Initialized
INFO - 2021-07-23 18:14:30 --> Final output sent to browser
DEBUG - 2021-07-23 18:14:30 --> Total execution time: 120.0790
INFO - 2021-07-23 23:25:09 --> Config Class Initialized
INFO - 2021-07-23 23:25:09 --> Hooks Class Initialized
DEBUG - 2021-07-23 23:25:09 --> UTF-8 Support Enabled
INFO - 2021-07-23 23:25:09 --> Utf8 Class Initialized
INFO - 2021-07-23 23:25:09 --> URI Class Initialized
INFO - 2021-07-23 23:25:09 --> Router Class Initialized
INFO - 2021-07-23 23:25:09 --> Output Class Initialized
INFO - 2021-07-23 23:25:09 --> Security Class Initialized
DEBUG - 2021-07-23 23:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-23 23:25:09 --> Input Class Initialized
INFO - 2021-07-23 23:25:09 --> Language Class Initialized
INFO - 2021-07-23 23:25:09 --> Loader Class Initialized
INFO - 2021-07-23 23:25:09 --> Helper loaded: url_helper
INFO - 2021-07-23 23:25:09 --> Helper loaded: form_helper
INFO - 2021-07-23 23:25:09 --> Helper loaded: array_helper
INFO - 2021-07-23 23:25:09 --> Helper loaded: date_helper
INFO - 2021-07-23 23:25:09 --> Helper loaded: html_helper
INFO - 2021-07-23 23:25:09 --> Database Driver Class Initialized
INFO - 2021-07-23 23:25:09 --> Controller Class Initialized
INFO - 2021-07-23 23:25:09 --> Helper loaded: googlestorage_helper
DEBUG - 2021-07-23 23:25:09 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-23 23:25:09 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-23 23:25:09 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-23 23:25:09 --> Model "Das_model" initialized
INFO - 2021-07-23 18:25:13 --> Ecac Robo Class Initialized
INFO - 2021-07-23 18:26:08 --> Ecac Robo Class Initialized
INFO - 2021-07-23 18:45:09 --> Final output sent to browser
DEBUG - 2021-07-23 18:45:09 --> Total execution time: 1,200.2165
INFO - 2021-07-23 19:53:17 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 19:54:38 --> Severity: error --> Exception: cURL error 52: Empty reply from server (see https://curl.haxx.se/libcurl/c/libcurl-errors.html) C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-23 19:55:53 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 19:58:36 --> Severity: error --> Exception: cURL error 28: Failed to connect to oauth2.googleapis.com port 443: Timed out (see https://curl.haxx.se/libcurl/c/libcurl-errors.html) C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-23 20:10:36 --> Ecac Robo Class Initialized
INFO - 2021-07-23 20:47:53 --> Final output sent to browser
DEBUG - 2021-07-23 20:47:53 --> Total execution time: 2,240.9033
INFO - 2021-07-23 20:52:04 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 20:53:01 --> Severity: error --> Exception: cURL error 52: Empty reply from server (see https://curl.haxx.se/libcurl/c/libcurl-errors.html) C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
INFO - 2021-07-23 20:53:20 --> Ecac Robo Class Initialized
INFO - 2021-07-23 20:58:42 --> Ecac Robo Class Initialized
ERROR - 2021-07-23 21:01:19 --> Severity: error --> Exception: cURL error 28: Operation timed out after 150013 milliseconds with 0 out of 0 bytes received (see https://curl.haxx.se/libcurl/c/libcurl-errors.html) C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
ERROR - 2021-07-23 21:15:05 --> Severity: error --> Exception: cURL error 56: OpenSSL SSL_read: Connection was reset, errno 10054 (see https://curl.haxx.se/libcurl/c/libcurl-errors.html) C:\xampp\htdocs\SistemaCronsCertificado\sp\vendor\google\cloud-core\src\RequestWrapper.php 368
