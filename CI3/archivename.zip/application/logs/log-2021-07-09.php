<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-09 19:28:40 --> Config Class Initialized
INFO - 2021-07-09 19:28:40 --> Hooks Class Initialized
DEBUG - 2021-07-09 19:28:40 --> UTF-8 Support Enabled
INFO - 2021-07-09 19:28:40 --> Utf8 Class Initialized
INFO - 2021-07-09 19:28:40 --> URI Class Initialized
INFO - 2021-07-09 19:28:40 --> Router Class Initialized
INFO - 2021-07-09 19:28:40 --> Output Class Initialized
INFO - 2021-07-09 19:28:40 --> Security Class Initialized
DEBUG - 2021-07-09 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-09 19:28:40 --> Input Class Initialized
INFO - 2021-07-09 19:28:40 --> Language Class Initialized
INFO - 2021-07-09 19:28:40 --> Loader Class Initialized
INFO - 2021-07-09 19:28:40 --> Helper loaded: url_helper
INFO - 2021-07-09 19:28:40 --> Helper loaded: form_helper
INFO - 2021-07-09 19:28:40 --> Helper loaded: array_helper
INFO - 2021-07-09 19:28:40 --> Helper loaded: date_helper
INFO - 2021-07-09 19:28:40 --> Helper loaded: html_helper
INFO - 2021-07-09 19:28:40 --> Database Driver Class Initialized
INFO - 2021-07-09 19:28:41 --> Controller Class Initialized
DEBUG - 2021-07-09 19:28:41 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-09 19:28:41 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-09 19:28:41 --> Model "Procuracao_model" initialized
INFO - 2021-07-09 14:28:45 --> Ecac Robo Class Initialized
INFO - 2021-07-09 14:28:58 --> Final output sent to browser
DEBUG - 2021-07-09 14:28:58 --> Total execution time: 17.7850
INFO - 2021-07-09 19:36:01 --> Config Class Initialized
INFO - 2021-07-09 19:36:01 --> Hooks Class Initialized
DEBUG - 2021-07-09 19:36:01 --> UTF-8 Support Enabled
INFO - 2021-07-09 19:36:01 --> Utf8 Class Initialized
INFO - 2021-07-09 19:36:01 --> URI Class Initialized
INFO - 2021-07-09 19:36:01 --> Router Class Initialized
INFO - 2021-07-09 19:36:01 --> Output Class Initialized
INFO - 2021-07-09 19:36:01 --> Security Class Initialized
DEBUG - 2021-07-09 19:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-09 19:36:01 --> Input Class Initialized
INFO - 2021-07-09 19:36:01 --> Language Class Initialized
INFO - 2021-07-09 19:36:01 --> Loader Class Initialized
INFO - 2021-07-09 19:36:01 --> Helper loaded: url_helper
INFO - 2021-07-09 19:36:01 --> Helper loaded: form_helper
INFO - 2021-07-09 19:36:01 --> Helper loaded: array_helper
INFO - 2021-07-09 19:36:01 --> Helper loaded: date_helper
INFO - 2021-07-09 19:36:01 --> Helper loaded: html_helper
INFO - 2021-07-09 19:36:01 --> Database Driver Class Initialized
INFO - 2021-07-09 19:36:01 --> Controller Class Initialized
DEBUG - 2021-07-09 19:36:01 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-09 19:36:01 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-09 19:36:01 --> Model "Procuracao_model" initialized
INFO - 2021-07-09 19:36:04 --> Config Class Initialized
INFO - 2021-07-09 19:36:04 --> Hooks Class Initialized
DEBUG - 2021-07-09 19:36:04 --> UTF-8 Support Enabled
INFO - 2021-07-09 19:36:04 --> Utf8 Class Initialized
INFO - 2021-07-09 19:36:04 --> URI Class Initialized
INFO - 2021-07-09 19:36:04 --> Router Class Initialized
INFO - 2021-07-09 19:36:04 --> Output Class Initialized
INFO - 2021-07-09 19:36:04 --> Security Class Initialized
DEBUG - 2021-07-09 19:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-09 19:36:04 --> Input Class Initialized
INFO - 2021-07-09 19:36:04 --> Language Class Initialized
INFO - 2021-07-09 19:36:04 --> Loader Class Initialized
INFO - 2021-07-09 19:36:04 --> Helper loaded: url_helper
INFO - 2021-07-09 19:36:04 --> Helper loaded: form_helper
INFO - 2021-07-09 19:36:04 --> Helper loaded: array_helper
INFO - 2021-07-09 19:36:04 --> Helper loaded: date_helper
INFO - 2021-07-09 19:36:04 --> Helper loaded: html_helper
INFO - 2021-07-09 19:36:04 --> Database Driver Class Initialized
INFO - 2021-07-09 19:36:04 --> Controller Class Initialized
DEBUG - 2021-07-09 19:36:04 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-09 19:36:04 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-09 19:36:04 --> Model "Procuracao_model" initialized
INFO - 2021-07-09 14:36:04 --> Ecac Robo Class Initialized
INFO - 2021-07-09 14:36:07 --> Ecac Robo Class Initialized
INFO - 2021-07-09 14:37:48 --> Final output sent to browser
DEBUG - 2021-07-09 14:37:48 --> Total execution time: 104.7674
