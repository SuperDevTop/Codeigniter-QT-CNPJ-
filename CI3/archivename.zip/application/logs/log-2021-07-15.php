<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-15 00:00:29 --> Config Class Initialized
INFO - 2021-07-15 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-07-15 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-07-15 00:00:29 --> Utf8 Class Initialized
INFO - 2021-07-15 00:00:29 --> URI Class Initialized
INFO - 2021-07-15 00:00:29 --> Router Class Initialized
INFO - 2021-07-15 00:00:29 --> Output Class Initialized
INFO - 2021-07-15 00:00:29 --> Security Class Initialized
DEBUG - 2021-07-15 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 00:00:29 --> Input Class Initialized
INFO - 2021-07-15 00:00:29 --> Language Class Initialized
INFO - 2021-07-15 00:00:29 --> Loader Class Initialized
INFO - 2021-07-15 00:00:29 --> Helper loaded: url_helper
INFO - 2021-07-15 00:00:29 --> Helper loaded: form_helper
INFO - 2021-07-15 00:00:29 --> Helper loaded: array_helper
INFO - 2021-07-15 00:00:29 --> Helper loaded: date_helper
INFO - 2021-07-15 00:00:29 --> Helper loaded: html_helper
INFO - 2021-07-15 00:00:29 --> Database Driver Class Initialized
INFO - 2021-07-15 00:00:30 --> Controller Class Initialized
DEBUG - 2021-07-15 00:00:30 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 00:00:30 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 00:00:30 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-15 00:00:30 --> Model "Dctf_model" initialized
INFO - 2021-07-15 00:00:32 --> Config Class Initialized
INFO - 2021-07-15 00:00:32 --> Hooks Class Initialized
DEBUG - 2021-07-15 00:00:32 --> UTF-8 Support Enabled
INFO - 2021-07-15 00:00:32 --> Utf8 Class Initialized
INFO - 2021-07-15 00:00:32 --> URI Class Initialized
INFO - 2021-07-15 00:00:32 --> Router Class Initialized
INFO - 2021-07-15 00:00:32 --> Output Class Initialized
INFO - 2021-07-15 00:00:32 --> Security Class Initialized
DEBUG - 2021-07-15 00:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 00:00:32 --> Input Class Initialized
INFO - 2021-07-15 00:00:32 --> Language Class Initialized
INFO - 2021-07-15 00:00:32 --> Loader Class Initialized
INFO - 2021-07-15 00:00:32 --> Helper loaded: url_helper
INFO - 2021-07-15 00:00:32 --> Helper loaded: form_helper
INFO - 2021-07-15 00:00:32 --> Helper loaded: array_helper
INFO - 2021-07-15 00:00:32 --> Helper loaded: date_helper
INFO - 2021-07-15 00:00:32 --> Helper loaded: html_helper
INFO - 2021-07-15 00:00:32 --> Database Driver Class Initialized
INFO - 2021-07-15 00:00:33 --> Controller Class Initialized
DEBUG - 2021-07-15 00:00:33 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 00:00:33 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 00:00:33 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-15 00:00:33 --> Model "Dctf_model" initialized
INFO - 2021-07-15 00:27:36 --> Config Class Initialized
INFO - 2021-07-15 00:27:36 --> Hooks Class Initialized
DEBUG - 2021-07-15 00:27:36 --> UTF-8 Support Enabled
INFO - 2021-07-15 00:27:36 --> Utf8 Class Initialized
INFO - 2021-07-15 00:27:36 --> URI Class Initialized
INFO - 2021-07-15 00:27:36 --> Router Class Initialized
INFO - 2021-07-15 00:27:36 --> Output Class Initialized
INFO - 2021-07-15 00:27:36 --> Security Class Initialized
DEBUG - 2021-07-15 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 00:27:36 --> Input Class Initialized
INFO - 2021-07-15 00:27:36 --> Language Class Initialized
INFO - 2021-07-15 00:27:36 --> Loader Class Initialized
INFO - 2021-07-15 00:27:36 --> Helper loaded: url_helper
INFO - 2021-07-15 00:27:36 --> Helper loaded: form_helper
INFO - 2021-07-15 00:27:36 --> Helper loaded: array_helper
INFO - 2021-07-15 00:27:36 --> Helper loaded: date_helper
INFO - 2021-07-15 00:27:36 --> Helper loaded: html_helper
INFO - 2021-07-15 00:27:36 --> Database Driver Class Initialized
INFO - 2021-07-15 00:27:36 --> Controller Class Initialized
DEBUG - 2021-07-15 00:27:36 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 00:27:36 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 00:27:36 --> Model "Procuracao_model" initialized
INFO - 2021-07-15 00:28:48 --> Config Class Initialized
INFO - 2021-07-15 00:28:48 --> Hooks Class Initialized
DEBUG - 2021-07-15 00:28:48 --> UTF-8 Support Enabled
INFO - 2021-07-15 00:28:48 --> Utf8 Class Initialized
INFO - 2021-07-15 00:28:48 --> URI Class Initialized
INFO - 2021-07-15 00:28:48 --> Router Class Initialized
INFO - 2021-07-15 00:28:48 --> Output Class Initialized
INFO - 2021-07-15 00:28:48 --> Security Class Initialized
DEBUG - 2021-07-15 00:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 00:28:48 --> Input Class Initialized
INFO - 2021-07-15 00:28:48 --> Language Class Initialized
INFO - 2021-07-15 00:28:48 --> Loader Class Initialized
INFO - 2021-07-15 00:28:48 --> Helper loaded: url_helper
INFO - 2021-07-15 00:28:48 --> Helper loaded: form_helper
INFO - 2021-07-15 00:28:48 --> Helper loaded: array_helper
INFO - 2021-07-15 00:28:48 --> Helper loaded: date_helper
INFO - 2021-07-15 00:28:48 --> Helper loaded: html_helper
INFO - 2021-07-15 00:28:48 --> Database Driver Class Initialized
INFO - 2021-07-15 00:28:49 --> Controller Class Initialized
DEBUG - 2021-07-15 00:28:49 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 00:28:49 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 00:28:49 --> Model "Contadorprocuracao_model" initialized
INFO - 2021-07-15 01:35:34 --> Config Class Initialized
INFO - 2021-07-15 01:35:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 01:35:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 01:35:34 --> Utf8 Class Initialized
INFO - 2021-07-15 01:35:34 --> URI Class Initialized
INFO - 2021-07-15 01:35:34 --> Router Class Initialized
INFO - 2021-07-15 01:35:34 --> Output Class Initialized
INFO - 2021-07-15 01:35:34 --> Security Class Initialized
DEBUG - 2021-07-15 01:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 01:35:34 --> Input Class Initialized
INFO - 2021-07-15 01:35:34 --> Language Class Initialized
INFO - 2021-07-15 01:35:34 --> Loader Class Initialized
INFO - 2021-07-15 01:35:34 --> Helper loaded: url_helper
INFO - 2021-07-15 01:35:34 --> Helper loaded: form_helper
INFO - 2021-07-15 01:35:34 --> Helper loaded: array_helper
INFO - 2021-07-15 01:35:34 --> Helper loaded: date_helper
INFO - 2021-07-15 01:35:34 --> Helper loaded: html_helper
INFO - 2021-07-15 01:35:34 --> Database Driver Class Initialized
INFO - 2021-07-15 01:35:34 --> Controller Class Initialized
DEBUG - 2021-07-15 01:35:34 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 01:35:34 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 01:35:34 --> Model "Procuracao_model" initialized
INFO - 2021-07-15 01:35:37 --> Config Class Initialized
INFO - 2021-07-15 01:35:37 --> Hooks Class Initialized
DEBUG - 2021-07-15 01:35:37 --> UTF-8 Support Enabled
INFO - 2021-07-15 01:35:37 --> Utf8 Class Initialized
INFO - 2021-07-15 01:35:37 --> URI Class Initialized
INFO - 2021-07-15 01:35:37 --> Router Class Initialized
INFO - 2021-07-15 01:35:37 --> Output Class Initialized
INFO - 2021-07-15 01:35:37 --> Security Class Initialized
DEBUG - 2021-07-15 01:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 01:35:37 --> Input Class Initialized
INFO - 2021-07-15 01:35:37 --> Language Class Initialized
INFO - 2021-07-15 01:35:37 --> Loader Class Initialized
INFO - 2021-07-15 01:35:37 --> Helper loaded: url_helper
INFO - 2021-07-15 01:35:37 --> Helper loaded: form_helper
INFO - 2021-07-15 01:35:37 --> Helper loaded: array_helper
INFO - 2021-07-15 01:35:37 --> Helper loaded: date_helper
INFO - 2021-07-15 01:35:37 --> Helper loaded: html_helper
INFO - 2021-07-15 01:35:37 --> Database Driver Class Initialized
INFO - 2021-07-15 01:35:37 --> Controller Class Initialized
DEBUG - 2021-07-15 01:35:37 --> Config file loaded: C:\xampp\htdocs\SistemaCronsCertificado\sp\application\config/ecac_robo_config.php
INFO - 2021-07-15 01:35:37 --> Model "Certificadocontador_model" initialized
INFO - 2021-07-15 01:35:37 --> Model "Procuracao_model" initialized
