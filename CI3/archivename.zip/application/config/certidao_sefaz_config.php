<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Caminho pasta pdfs
|--------------------------------------------------------------------------
|
| Caminho da pasta para salvar os pdfs
|
*/
$config['caminho_pasta_pdf'] = "/var/www/html/pdf-certidao/certidaosefaz";